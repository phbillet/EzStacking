echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 326.1512694122793,
   "BlastFurnaceSlag": 256.0727255535259,
   "FlyAsh": 101.26815057731274,
   "Water": 178.58204766290712,
   "Superplasticizer": 18.703382363655507,
   "CoarseAggregate": 992.158190257473,
   "FineAggregate": 934.8439413739798,
   "Age": 118.58655733714406
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 207.80210739189852,
   "BlastFurnaceSlag": 1.5185151606220384,
   "FlyAsh": 180.65133232011817,
   "Water": 245.2349014397508,
   "Superplasticizer": 21.94956331060422,
   "CoarseAggregate": 1143.57579981154,
   "FineAggregate": 720.3321290376133,
   "Age": 117.42696189063545
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 117.99393404997916,
   "BlastFurnaceSlag": 316.28815804468815,
   "FlyAsh": 110.70945746447711,
   "Water": 194.28755014681508,
   "Superplasticizer": 8.270537776959324,
   "CoarseAggregate": 964.6696884022574,
   "FineAggregate": 596.059079859575,
   "Age": 149.00039130731287
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 324.9867117184571,
   "BlastFurnaceSlag": 171.27814664333613,
   "FlyAsh": 158.34603169479848,
   "Water": 230.96361390972987,
   "Superplasticizer": 16.46777972936209,
   "CoarseAggregate": 941.6384066506737,
   "FineAggregate": 935.5848956948673,
   "Age": 209.3060269412345
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 531.6802885126255,
   "BlastFurnaceSlag": 323.3617475063423,
   "FlyAsh": 13.380950889951393,
   "Water": 219.88026292264033,
   "Superplasticizer": 19.192403277993787,
   "CoarseAggregate": 811.8741645171118,
   "FineAggregate": 984.8879229651513,
   "Age": 186.87727556216717
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 342.96331137062083,
   "BlastFurnaceSlag": 170.45201569479485,
   "FlyAsh": 18.20838558210339,
   "Water": 148.6685457654038,
   "Superplasticizer": 32.06845498809842,
   "CoarseAggregate": 814.5686642467704,
   "FineAggregate": 801.012270280392,
   "Age": 53.082617398329155
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 393.485706434101,
   "BlastFurnaceSlag": 84.14697262483234,
   "FlyAsh": 171.4542868434891,
   "Water": 161.4676596109779,
   "Superplasticizer": 28.599861049349816,
   "CoarseAggregate": 817.9525312396731,
   "FineAggregate": 931.2634488355931,
   "Age": 98.32916049393259
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 340.28143625004157,
   "BlastFurnaceSlag": 347.20372427333115,
   "FlyAsh": 94.68613829181143,
   "Water": 241.59257006354485,
   "Superplasticizer": 18.416066420840117,
   "CoarseAggregate": 1041.0245616066577,
   "FineAggregate": 859.7286926817908,
   "Age": 110.0725602389349
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 293.8802074389625,
   "BlastFurnaceSlag": 260.1616454434865,
   "FlyAsh": 13.254010332027256,
   "Water": 150.84856906164737,
   "Superplasticizer": 24.434230231491494,
   "CoarseAggregate": 882.6327116224857,
   "FineAggregate": 649.7077408389231,
   "Age": 204.2691057370777
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 281.89691727071477,
   "BlastFurnaceSlag": 121.103422704193,
   "FlyAsh": 2.0805340139999884,
   "Water": 173.83200868490246,
   "Superplasticizer": 8.484106095132937,
   "CoarseAggregate": 1010.882489383609,
   "FineAggregate": 713.1978136163171,
   "Age": 155.89567483355322
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 261.29088736478025,
   "BlastFurnaceSlag": 97.55431132875624,
   "FlyAsh": 9.614275169568895,
   "Water": 164.88010709293286,
   "Superplasticizer": 11.333700009652143,
   "CoarseAggregate": 943.5624127129192,
   "FineAggregate": 658.7343035566306,
   "Age": 55.502905549696685
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 180.49166375716214,
   "BlastFurnaceSlag": 283.5108457855134,
   "FlyAsh": 79.40414425107505,
   "Water": 139.05017687386047,
   "Superplasticizer": 5.9472517731604,
   "CoarseAggregate": 950.6651435400763,
   "FineAggregate": 986.9737205760667,
   "Age": 209.72492228670288
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 420.3057765416331,
   "BlastFurnaceSlag": 278.2146903726531,
   "FlyAsh": 198.658320995227,
   "Water": 178.45064273040867,
   "Superplasticizer": 21.085082712680336,
   "CoarseAggregate": 936.4099755796075,
   "FineAggregate": 932.5930577619829,
   "Age": 265.4895334178312
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 396.251711540505,
   "BlastFurnaceSlag": 281.8289937271367,
   "FlyAsh": 180.9176546250482,
   "Water": 172.0276007395484,
   "Superplasticizer": 0.4649054936882683,
   "CoarseAggregate": 1118.4191774510355,
   "FineAggregate": 863.1113716359836,
   "Age": 173.35085348509625
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 425.69608235136593,
   "BlastFurnaceSlag": 7.75773407652591,
   "FlyAsh": 115.64457034540114,
   "Water": 192.62619759380465,
   "Superplasticizer": 11.730107980104652,
   "CoarseAggregate": 994.4760484625955,
   "FineAggregate": 828.0478750372184,
   "Age": 126.71979470019734
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 377.30356075715014,
   "BlastFurnaceSlag": 216.3345109448981,
   "FlyAsh": 9.828067922319661,
   "Water": 132.55448157729762,
   "Superplasticizer": 16.117203123237832,
   "CoarseAggregate": 1103.9313493505733,
   "FineAggregate": 803.7636109511429,
   "Age": 276.42785747350916
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 259.0568004834787,
   "BlastFurnaceSlag": 225.78708697081936,
   "FlyAsh": 140.19318922641023,
   "Water": 220.3483495262611,
   "Superplasticizer": 3.673444121678425,
   "CoarseAggregate": 924.5210487207878,
   "FineAggregate": 954.6059988576073,
   "Age": 38.56468990746665
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 287.4674217238836,
   "BlastFurnaceSlag": 335.96388965188635,
   "FlyAsh": 100.56140500174446,
   "Water": 144.9747829024742,
   "Superplasticizer": 25.210826551732552,
   "CoarseAggregate": 873.8508965868516,
   "FineAggregate": 902.0985967889881,
   "Age": 145.51259292087633
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 531.6441676880576,
   "BlastFurnaceSlag": 208.43200523000706,
   "FlyAsh": 83.9172255913418,
   "Water": 201.43510220332206,
   "Superplasticizer": 13.871378927935671,
   "CoarseAggregate": 981.7328731386289,
   "FineAggregate": 702.1443978190139,
   "Age": 299.9119718467499
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 498.1108336305633,
   "BlastFurnaceSlag": 137.49095896787662,
   "FlyAsh": 128.58766386491686,
   "Water": 177.8834957234944,
   "Superplasticizer": 9.748212780118418,
   "CoarseAggregate": 1084.0951969462753,
   "FineAggregate": 873.0258336660593,
   "Age": 149.14663882190618
}'
echo -e ""
echo -e "Test OK: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 113.53300833584852,
   "BlastFurnaceSlag": 123.11946291144076,
   "FlyAsh": 157.47343846582308,
   "Water": 148.76084584874926,
   "Superplasticizer": 4.1568946156936555,
   "CoarseAggregate": 994.3675454836335,
   "FineAggregate": 747.8652805425672,
   "Age": 275.0539157813984
}'
echo -e ""
echo -e "Test OK: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 365.5987000116574,
   "BlastFurnaceSlag": 100.73694145017221,
   "FlyAsh": 128.21763002149638,
   "Water": 231.52516978957695,
   "Superplasticizer": 3.6642781923027274,
   "CoarseAggregate": 940.2058389648817,
   "FineAggregate": 861.2881786171274,
   "Age": 120.2749617270698
}'
echo -e ""
echo -e "Test OK: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 241.42429342766465,
   "BlastFurnaceSlag": 339.4379686546744,
   "FlyAsh": 199.86964764729058,
   "Water": 131.15132143334097,
   "Superplasticizer": 27.470244404362127,
   "CoarseAggregate": 1113.7333986485223,
   "FineAggregate": 932.0318781176607,
   "Age": 293.20568821590376
}'
echo -e ""
echo -e "Test OK: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 283.3303352266888,
   "BlastFurnaceSlag": 95.5488167360983,
   "FlyAsh": 192.2340289386643,
   "Water": 223.62365245239954,
   "Superplasticizer": 13.876234896271004,
   "CoarseAggregate": 1069.3545583643843,
   "FineAggregate": 807.579274942148,
   "Age": 210.59584686377383
}'
echo -e ""
echo -e "Test OK: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 506.1119128388758,
   "BlastFurnaceSlag": 152.42175045287215,
   "FlyAsh": 149.8666699278541,
   "Water": 171.84185640324492,
   "Superplasticizer": 12.89940198310699,
   "CoarseAggregate": 937.6907772808247,
   "FineAggregate": 702.489369164096,
   "Age": 351.509306948921
}'
echo -e ""
echo -e "Test OK: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 221.83549782004917,
   "BlastFurnaceSlag": 69.99104166242913,
   "FlyAsh": 17.413579526112,
   "Water": 227.38014227674134,
   "Superplasticizer": 8.60633682420555,
   "CoarseAggregate": 1098.5124736172736,
   "FineAggregate": 985.6666842847903,
   "Age": 150.56066931078215
}'
echo -e ""
echo -e "Test OK: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 409.60950786624636,
   "BlastFurnaceSlag": 65.11913360741364,
   "FlyAsh": 55.25930437040202,
   "Water": 151.38241591124364,
   "Superplasticizer": 31.058038702531018,
   "CoarseAggregate": 1053.2083687780666,
   "FineAggregate": 884.4342354070012,
   "Age": 239.50801895062682
}'
echo -e ""
echo -e "Test OK: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 264.52786151375255,
   "BlastFurnaceSlag": 86.23278931362195,
   "FlyAsh": 2.406511772710009,
   "Water": 138.6688230467868,
   "Superplasticizer": 25.392420719980606,
   "CoarseAggregate": 993.6178479355948,
   "FineAggregate": 753.3471039097178,
   "Age": 231.15207352721563
}'
echo -e ""
echo -e "Test OK: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 424.5582721308424,
   "BlastFurnaceSlag": 145.63452088010794,
   "FlyAsh": 117.59126440348592,
   "Water": 179.39982764573892,
   "Superplasticizer": 2.6622368938465013,
   "CoarseAggregate": 1098.2616191138393,
   "FineAggregate": 859.0136289624018,
   "Age": 328.79174451905794
}'
echo -e ""
echo -e "Test OK: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 529.9624193441073,
   "BlastFurnaceSlag": 134.74314481038581,
   "FlyAsh": 106.65836711276341,
   "Water": 207.6441841335979,
   "Superplasticizer": 19.82022671022784,
   "CoarseAggregate": 1071.2011123892817,
   "FineAggregate": 645.6903436161838,
   "Age": 220.788322135387
}'
echo -e ""
echo -e "Test OK: 30"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 103.67888374628224,
   "BlastFurnaceSlag": 35.22771984419583,
   "FlyAsh": 174.43645375385748,
   "Water": 133.08128720686946,
   "Superplasticizer": 7.430738412978713,
   "CoarseAggregate": 854.992193382335,
   "FineAggregate": 934.5404557828936,
   "Age": 254.78933589900026
}'
echo -e ""
echo -e "Test OK: 31"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 176.92886815231577,
   "BlastFurnaceSlag": 185.20890108720042,
   "FlyAsh": 86.90700806171391,
   "Water": 199.69670604448697,
   "Superplasticizer": 20.460726580175038,
   "CoarseAggregate": 872.647864008764,
   "FineAggregate": 729.7605512172822,
   "Age": 60.87534921216715
}'
echo -e ""
echo -e "Test OK: 32"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 338.8080892336594,
   "BlastFurnaceSlag": 46.70867476943296,
   "FlyAsh": 184.49564625051718,
   "Water": 238.2827126548447,
   "Superplasticizer": 11.751354159626072,
   "CoarseAggregate": 1064.7242888415624,
   "FineAggregate": 618.1585971763255,
   "Age": 110.609501432281
}'
echo -e ""
echo -e "Test OK: 33"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 355.7018477794341,
   "BlastFurnaceSlag": 47.69223920914254,
   "FlyAsh": 15.310314591877818,
   "Water": 210.08864068876952,
   "Superplasticizer": 30.126702984349148,
   "CoarseAggregate": 1130.7038659593202,
   "FineAggregate": 642.8967123924809,
   "Age": 355.0775151082121
}'
echo -e ""
echo -e "Test OK: 34"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 388.8371708627593,
   "BlastFurnaceSlag": 62.483038570977975,
   "FlyAsh": 144.9801374450556,
   "Water": 173.08028793191815,
   "Superplasticizer": 16.287419942880728,
   "CoarseAggregate": 1130.370246833322,
   "FineAggregate": 755.0537862227663,
   "Age": 103.74197219045574
}'
echo -e ""
echo -e "Test OK: 35"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 290.802695074267,
   "BlastFurnaceSlag": 136.12031082397849,
   "FlyAsh": 141.1748627219047,
   "Water": 134.16667731310588,
   "Superplasticizer": 4.674649498247533,
   "CoarseAggregate": 889.9881938915414,
   "FineAggregate": 661.2349179814532,
   "Age": 294.3520633018904
}'
echo -e ""
echo -e "Test OK: 36"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 443.5013929515886,
   "BlastFurnaceSlag": 218.90047019954278,
   "FlyAsh": 27.050650199848,
   "Water": 157.37065073345755,
   "Superplasticizer": 22.498022343791444,
   "CoarseAggregate": 1101.8228501628464,
   "FineAggregate": 720.0470915040752,
   "Age": 305.256394853136
}'
echo -e ""
echo -e "Test OK: 37"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 344.32018857628054,
   "BlastFurnaceSlag": 202.57395437850863,
   "FlyAsh": 81.99231278528012,
   "Water": 220.71409812718684,
   "Superplasticizer": 26.542877256460024,
   "CoarseAggregate": 901.05361497951,
   "FineAggregate": 766.5875574121361,
   "Age": 288.34336342965946
}'
echo -e ""
echo -e "Test OK: 38"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 388.1676460041626,
   "BlastFurnaceSlag": 58.36961761841754,
   "FlyAsh": 65.48521196128662,
   "Water": 130.4249906150411,
   "Superplasticizer": 17.203383709276746,
   "CoarseAggregate": 1123.2116969234762,
   "FineAggregate": 696.3004095656113,
   "Age": 121.5658605185008
}'
echo -e ""
echo -e "Test OK: 39"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 407.6257872909061,
   "BlastFurnaceSlag": 273.05393548313884,
   "FlyAsh": 142.32499941996312,
   "Water": 124.66791408829707,
   "Superplasticizer": 10.05740424345384,
   "CoarseAggregate": 831.3956670783555,
   "FineAggregate": 796.8806074780111,
   "Age": 28.94933798108227
}'
echo -e ""
echo -e "Test OK: 40"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 418.4107848374082,
   "BlastFurnaceSlag": 1.5239885179225516,
   "FlyAsh": 83.91738467256623,
   "Water": 127.18163085028345,
   "Superplasticizer": 20.336293423923657,
   "CoarseAggregate": 1056.9664249640177,
   "FineAggregate": 706.0809132012738,
   "Age": 89.79143254058495
}'
echo -e ""
echo -e "Test OK: 41"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 362.4745816383511,
   "BlastFurnaceSlag": 28.990694785598077,
   "FlyAsh": 102.8126193769518,
   "Water": 181.23709584065955,
   "Superplasticizer": 13.105541308730121,
   "CoarseAggregate": 953.6224002085103,
   "FineAggregate": 734.7982501590827,
   "Age": 338.0755334689966
}'
echo -e ""
echo -e "Test OK: 42"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 141.92826687036887,
   "BlastFurnaceSlag": 217.71835509155574,
   "FlyAsh": 91.7631728488323,
   "Water": 190.94410741789756,
   "Superplasticizer": 21.2396540332631,
   "CoarseAggregate": 1002.5730065666874,
   "FineAggregate": 789.916292337044,
   "Age": 180.6746200377421
}'
echo -e ""
echo -e "Test OK: 43"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 103.50740740000492,
   "BlastFurnaceSlag": 305.15132293709786,
   "FlyAsh": 52.71942684643502,
   "Water": 130.92494211837592,
   "Superplasticizer": 23.98936393667619,
   "CoarseAggregate": 849.9815792359411,
   "FineAggregate": 913.7958479926001,
   "Age": 198.84471415553284
}'
echo -e ""
echo -e "Test OK: 44"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 456.9718350998713,
   "BlastFurnaceSlag": 207.60058832692653,
   "FlyAsh": 134.31621091538437,
   "Water": 227.28082300977385,
   "Superplasticizer": 21.249703422486256,
   "CoarseAggregate": 1049.1447195210042,
   "FineAggregate": 668.3259715445361,
   "Age": 340.2738348041738
}'
echo -e ""
echo -e "Test OK: 45"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 139.21203609920164,
   "BlastFurnaceSlag": 248.00169420213157,
   "FlyAsh": 1.4001209716735428,
   "Water": 201.9616112140344,
   "Superplasticizer": 19.36074158751362,
   "CoarseAggregate": 1003.3290157103729,
   "FineAggregate": 610.0808266144618,
   "Age": 164.90987502399705
}'
echo -e ""
echo -e "Test OK: 46"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 231.12461145125994,
   "BlastFurnaceSlag": 16.162167195727026,
   "FlyAsh": 50.71494173818665,
   "Water": 201.7980999198016,
   "Superplasticizer": 19.391997780249593,
   "CoarseAggregate": 832.7452181874273,
   "FineAggregate": 805.1006716495687,
   "Age": 301.7419818044742
}'
echo -e ""
echo -e "Test OK: 47"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 340.775030221408,
   "BlastFurnaceSlag": 82.2238671387381,
   "FlyAsh": 42.27330602546189,
   "Water": 246.27223984789458,
   "Superplasticizer": 4.515864571210495,
   "CoarseAggregate": 881.0370698627446,
   "FineAggregate": 640.5680841317078,
   "Age": 99.06867832561403
}'
echo -e ""
echo -e "Test OK: 48"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 229.61468280380183,
   "BlastFurnaceSlag": 115.82128494764213,
   "FlyAsh": 65.00711904483776,
   "Water": 246.8074783209588,
   "Superplasticizer": 1.906021312008924,
   "CoarseAggregate": 1023.5824275201536,
   "FineAggregate": 595.5328488129799,
   "Age": 361.34283391569943
}'
echo -e ""
echo -e "Test OK: 49"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 465.8659481275804,
   "BlastFurnaceSlag": 356.94307258217424,
   "FlyAsh": 144.48572247487394,
   "Water": 171.47721791287933,
   "Superplasticizer": 22.620832909587566,
   "CoarseAggregate": 1046.1470597721334,
   "FineAggregate": 934.5845807826269,
   "Age": 310.9799284296277
}'
echo -e ""
echo -e "Test OK: 50"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 353.4127482952334,
   "BlastFurnaceSlag": 160.35885788868487,
   "FlyAsh": 31.045158730908184,
   "Water": 124.89581678408848,
   "Superplasticizer": 30.892764250236883,
   "CoarseAggregate": 994.1521108264403,
   "FineAggregate": 809.847345380035,
   "Age": 104.72318353762948
}'
echo -e ""
echo -e "Test OK: 51"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 369.62549461738547,
   "BlastFurnaceSlag": 277.48780390656486,
   "FlyAsh": 154.15908118191146,
   "Water": 194.18223365662783,
   "Superplasticizer": 9.974598507281565,
   "CoarseAggregate": 803.5204731624169,
   "FineAggregate": 746.8719398108523,
   "Age": 323.2218668968788
}'
echo -e ""
echo -e "Test OK: 52"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 532.4512532639803,
   "BlastFurnaceSlag": 55.28358600746223,
   "FlyAsh": 113.92723279844519,
   "Water": 189.64073200877235,
   "Superplasticizer": 30.84055405062876,
   "CoarseAggregate": 859.3034475431922,
   "FineAggregate": 876.0906637823978,
   "Age": 361.1252299090664
}'
echo -e ""
echo -e "Test OK: 53"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 523.678322852154,
   "BlastFurnaceSlag": 297.0144453010315,
   "FlyAsh": 117.74499268189722,
   "Water": 162.73893636345923,
   "Superplasticizer": 25.63234772544181,
   "CoarseAggregate": 1009.2783734125294,
   "FineAggregate": 981.1884194099173,
   "Age": 148.1112967206383
}'
echo -e ""
echo -e "Test OK: 54"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 213.27021490128158,
   "BlastFurnaceSlag": 100.8543938814179,
   "FlyAsh": 11.426689300089677,
   "Water": 168.97998894525776,
   "Superplasticizer": 10.966775204189833,
   "CoarseAggregate": 941.5903854266681,
   "FineAggregate": 722.2874988904263,
   "Age": 257.5655407512586
}'
echo -e ""
echo -e "Test OK: 55"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 206.57365303376264,
   "BlastFurnaceSlag": 106.9012037858079,
   "FlyAsh": 178.34707568259225,
   "Water": 141.17278800192167,
   "Superplasticizer": 6.470407640587347,
   "CoarseAggregate": 855.544926562892,
   "FineAggregate": 799.2597362199884,
   "Age": 333.844062026218
}'
echo -e ""
echo -e "Test OK: 56"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 523.4518339394226,
   "BlastFurnaceSlag": 174.71546392114973,
   "FlyAsh": 20.752910040068024,
   "Water": 246.53053183009052,
   "Superplasticizer": 28.50165190017674,
   "CoarseAggregate": 1137.6229601275409,
   "FineAggregate": 724.2658973833128,
   "Age": 310.3987750333841
}'
echo -e ""
echo -e "Test OK: 57"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 142.21994439426834,
   "BlastFurnaceSlag": 131.83380188898954,
   "FlyAsh": 55.801533993917225,
   "Water": 156.75065459049804,
   "Superplasticizer": 24.091894151554488,
   "CoarseAggregate": 1052.6907689286406,
   "FineAggregate": 613.6222846098277,
   "Age": 190.18662271660554
}'
echo -e ""
echo -e "Test OK: 58"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 299.4329753358613,
   "BlastFurnaceSlag": 222.5551448646164,
   "FlyAsh": 194.9995877961561,
   "Water": 191.73555419621405,
   "Superplasticizer": 31.890752013409195,
   "CoarseAggregate": 956.3016601918143,
   "FineAggregate": 904.1786583065832,
   "Age": 234.89133698483826
}'
echo -e ""
echo -e "Test OK: 59"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 335.55256802043374,
   "BlastFurnaceSlag": 111.60536916533529,
   "FlyAsh": 14.046981418544645,
   "Water": 159.96058493338847,
   "Superplasticizer": 1.861420999883733,
   "CoarseAggregate": 1022.2244506447221,
   "FineAggregate": 619.7739439564383,
   "Age": 220.188315056821
}'
echo -e ""
echo -e "Test OK: 60"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 478.6314349631416,
   "BlastFurnaceSlag": 216.28685386522298,
   "FlyAsh": 140.37424977742393,
   "Water": 216.50723756504394,
   "Superplasticizer": 6.544331750874555,
   "CoarseAggregate": 1022.655949815452,
   "FineAggregate": 802.301987943223,
   "Age": 235.04592680434314
}'
echo -e ""
echo -e "Test OK: 61"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 508.27755050813863,
   "BlastFurnaceSlag": 33.730329409295244,
   "FlyAsh": 181.21318313772935,
   "Water": 178.38361460695467,
   "Superplasticizer": 10.891230221192963,
   "CoarseAggregate": 1144.0901107351667,
   "FineAggregate": 659.0589079700113,
   "Age": 294.36377634561865
}'
echo -e ""
echo -e "Test OK: 62"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 262.5755156354749,
   "BlastFurnaceSlag": 351.3218934071836,
   "FlyAsh": 106.46982267542687,
   "Water": 166.96042095985166,
   "Superplasticizer": 21.610541474495133,
   "CoarseAggregate": 937.2534301289164,
   "FineAggregate": 728.0150094511384,
   "Age": 360.16887378883007
}'
echo -e ""
echo -e "Test OK: 63"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 465.59412399522716,
   "BlastFurnaceSlag": 118.05918951947325,
   "FlyAsh": 10.19384593909146,
   "Water": 208.2291135172853,
   "Superplasticizer": 18.669384547160593,
   "CoarseAggregate": 1004.1737357502461,
   "FineAggregate": 793.7868293456282,
   "Age": 90.06418623735921
}'
echo -e ""
echo -e "Test OK: 64"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 458.3159322856767,
   "BlastFurnaceSlag": 84.39591712518265,
   "FlyAsh": 38.01681849909938,
   "Water": 231.2100812246492,
   "Superplasticizer": 20.59822916384006,
   "CoarseAggregate": 1033.0711965045434,
   "FineAggregate": 725.9987091106083,
   "Age": 89.85221806685709
}'
echo -e ""
echo -e "Test OK: 65"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 264.3993626404143,
   "BlastFurnaceSlag": 305.30943418606284,
   "FlyAsh": 124.79364929332772,
   "Water": 155.41424804977325,
   "Superplasticizer": 1.3268691711854241,
   "CoarseAggregate": 855.1706078382396,
   "FineAggregate": 881.9244067497596,
   "Age": 162.60385736359146
}'
echo -e ""
echo -e "Test OK: 66"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 213.58270233277958,
   "BlastFurnaceSlag": 57.50554330230279,
   "FlyAsh": 123.32570298467739,
   "Water": 178.30311454456236,
   "Superplasticizer": 0.6979626829078962,
   "CoarseAggregate": 1118.579301660352,
   "FineAggregate": 895.5771253435106,
   "Age": 316.31195132039187
}'
echo -e ""
echo -e "Test OK: 67"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 510.0628780961249,
   "BlastFurnaceSlag": 172.8249534986693,
   "FlyAsh": 113.90278771007276,
   "Water": 181.68976791850915,
   "Superplasticizer": 32.153285043617835,
   "CoarseAggregate": 924.5638863377676,
   "FineAggregate": 943.7995481822502,
   "Age": 38.41134690080119
}'
echo -e ""
echo -e "Test OK: 68"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 408.02522032379363,
   "BlastFurnaceSlag": 39.376450120653026,
   "FlyAsh": 117.05536957118515,
   "Water": 243.51681434021202,
   "Superplasticizer": 11.962867720839997,
   "CoarseAggregate": 809.5847685784267,
   "FineAggregate": 646.1730093300783,
   "Age": 193.37097392314521
}'
echo -e ""
echo -e "Test OK: 69"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 267.71089533490795,
   "BlastFurnaceSlag": 55.5789951059841,
   "FlyAsh": 181.11317380170516,
   "Water": 153.42863828464132,
   "Superplasticizer": 26.124490849035613,
   "CoarseAggregate": 833.1584461640628,
   "FineAggregate": 622.2245939932404,
   "Age": 236.46937625175406
}'
echo -e ""
echo -e "Test OK: 70"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 297.5041494770365,
   "BlastFurnaceSlag": 287.9690583710157,
   "FlyAsh": 49.54706228456887,
   "Water": 159.03490315672573,
   "Superplasticizer": 22.565090823246056,
   "CoarseAggregate": 1079.1782270919177,
   "FineAggregate": 733.480623467015,
   "Age": 183.91734144137328
}'
echo -e ""
echo -e "Test OK: 71"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 334.39589323895837,
   "BlastFurnaceSlag": 357.6794742903811,
   "FlyAsh": 138.21002397973086,
   "Water": 179.71133052183922,
   "Superplasticizer": 4.570995005212733,
   "CoarseAggregate": 935.5755975896334,
   "FineAggregate": 603.6714580605625,
   "Age": 126.46254715680331
}'
echo -e ""
echo -e "Test OK: 72"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 230.99101438940139,
   "BlastFurnaceSlag": 232.79227308034834,
   "FlyAsh": 136.1579101098689,
   "Water": 172.14030375166243,
   "Superplasticizer": 25.964494854188196,
   "CoarseAggregate": 913.1170979200608,
   "FineAggregate": 808.7910157267193,
   "Age": 71.00548070297727
}'
echo -e ""
echo -e "Test OK: 73"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 301.5559475050415,
   "BlastFurnaceSlag": 7.661502713631608,
   "FlyAsh": 94.76841062574152,
   "Water": 171.3001296749489,
   "Superplasticizer": 19.706133255346565,
   "CoarseAggregate": 884.0115884410407,
   "FineAggregate": 625.9489809649222,
   "Age": 72.46577635931192
}'
echo -e ""
echo -e "Test OK: 74"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 380.4562227834585,
   "BlastFurnaceSlag": 242.76228192516896,
   "FlyAsh": 71.59126718281134,
   "Water": 237.8859126242923,
   "Superplasticizer": 27.787054981938393,
   "CoarseAggregate": 838.054681505096,
   "FineAggregate": 874.2793469059218,
   "Age": 134.1691556252432
}'
echo -e ""
echo -e "Test OK: 75"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 187.7691423747015,
   "BlastFurnaceSlag": 246.23569205277508,
   "FlyAsh": 133.19899581181102,
   "Water": 186.72425591310292,
   "Superplasticizer": 17.780021558702046,
   "CoarseAggregate": 962.3003662717174,
   "FineAggregate": 780.7779107708255,
   "Age": 269.38540655921594
}'
echo -e ""
echo -e "Test OK: 76"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 183.29752097524295,
   "BlastFurnaceSlag": 0.1924326675427642,
   "FlyAsh": 81.29447191879368,
   "Water": 236.21576430474977,
   "Superplasticizer": 27.76613639977849,
   "CoarseAggregate": 897.2944831171448,
   "FineAggregate": 616.6940648505503,
   "Age": 172.8080880584656
}'
echo -e ""
echo -e "Test OK: 77"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 209.39214134869871,
   "BlastFurnaceSlag": 110.32072676738672,
   "FlyAsh": 106.90876110723502,
   "Water": 216.52501290736427,
   "Superplasticizer": 19.734736391799466,
   "CoarseAggregate": 1081.9993535968706,
   "FineAggregate": 731.8668686947271,
   "Age": 188.66588869245177
}'
echo -e ""
echo -e "Test OK: 78"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 259.8801182895992,
   "BlastFurnaceSlag": 101.72707761683762,
   "FlyAsh": 81.35023904108226,
   "Water": 152.40617653969883,
   "Superplasticizer": 10.484707909415343,
   "CoarseAggregate": 960.0231883449983,
   "FineAggregate": 693.6497942870287,
   "Age": 70.32437823194832
}'
echo -e ""
echo -e "Test OK: 79"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 388.046526733064,
   "BlastFurnaceSlag": 263.7395948713043,
   "FlyAsh": 29.076062065956794,
   "Water": 161.7649074287771,
   "Superplasticizer": 10.861160876996747,
   "CoarseAggregate": 885.0293650019697,
   "FineAggregate": 949.7887549092206,
   "Age": 316.7018992639652
}'
echo -e ""
echo -e "Test OK: 80"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 374.50775444201525,
   "BlastFurnaceSlag": 330.40288024330323,
   "FlyAsh": 113.0384044661802,
   "Water": 236.2238487455436,
   "Superplasticizer": 7.269825646043497,
   "CoarseAggregate": 1095.8899223966646,
   "FineAggregate": 956.3705442967672,
   "Age": 53.01331952890603
}'
echo -e ""
echo -e "Test OK: 81"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 538.6921586858025,
   "BlastFurnaceSlag": 60.87280533839395,
   "FlyAsh": 30.7418540046153,
   "Water": 166.73023409450417,
   "Superplasticizer": 24.465366883962574,
   "CoarseAggregate": 998.081340648695,
   "FineAggregate": 730.831802840803,
   "Age": 208.14767760305702
}'
echo -e ""
echo -e "Test OK: 82"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 282.5809498240932,
   "BlastFurnaceSlag": 295.3388799908488,
   "FlyAsh": 66.88864752359699,
   "Water": 165.2064081238151,
   "Superplasticizer": 30.422085675972486,
   "CoarseAggregate": 1139.3406017656798,
   "FineAggregate": 800.9867413613672,
   "Age": 324.7771342309062
}'
echo -e ""
echo -e "Test OK: 83"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 366.7393869786332,
   "BlastFurnaceSlag": 132.78588386013905,
   "FlyAsh": 5.614339861343881,
   "Water": 162.3994167402936,
   "Superplasticizer": 20.18082477195778,
   "CoarseAggregate": 992.1091028468908,
   "FineAggregate": 696.5970132041537,
   "Age": 221.16291240954163
}'
echo -e ""
echo -e "Test OK: 84"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 142.12644663976587,
   "BlastFurnaceSlag": 11.30327958715228,
   "FlyAsh": 89.8201558856826,
   "Water": 234.09976935704339,
   "Superplasticizer": 9.492867383352566,
   "CoarseAggregate": 899.4713704850546,
   "FineAggregate": 714.0877567233847,
   "Age": 147.61323771190052
}'
echo -e ""
echo -e "Test OK: 85"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 488.50160766368646,
   "BlastFurnaceSlag": 14.991616820468348,
   "FlyAsh": 52.81939599581607,
   "Water": 231.09811837366163,
   "Superplasticizer": 30.42887927802004,
   "CoarseAggregate": 858.5205802802011,
   "FineAggregate": 610.7238914307067,
   "Age": 326.4910301886735
}'
echo -e ""
echo -e "Test OK: 86"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 306.71872397637753,
   "BlastFurnaceSlag": 148.20814406114064,
   "FlyAsh": 128.17097052131538,
   "Water": 158.67243296404985,
   "Superplasticizer": 18.99920020161649,
   "CoarseAggregate": 961.0133761218758,
   "FineAggregate": 955.8779236368473,
   "Age": 175.10711188189387
}'
echo -e ""
echo -e "Test OK: 87"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 147.4441431515637,
   "BlastFurnaceSlag": 301.609165869712,
   "FlyAsh": 68.95316230366119,
   "Water": 232.44040412725474,
   "Superplasticizer": 15.423836679248156,
   "CoarseAggregate": 942.6525388870735,
   "FineAggregate": 954.5692667858293,
   "Age": 344.7122935866425
}'
echo -e ""
echo -e "Test OK: 88"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 431.0240461440832,
   "BlastFurnaceSlag": 107.7283575047988,
   "FlyAsh": 57.68082177021125,
   "Water": 226.06459966927218,
   "Superplasticizer": 0.542222678177332,
   "CoarseAggregate": 947.2231619528982,
   "FineAggregate": 749.8321801246036,
   "Age": 262.4083700810692
}'
echo -e ""
echo -e "Test OK: 89"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 512.9875339543869,
   "BlastFurnaceSlag": 143.29303618767676,
   "FlyAsh": 56.34438777982726,
   "Water": 192.79388696315752,
   "Superplasticizer": 9.63090032621836,
   "CoarseAggregate": 868.1983583878605,
   "FineAggregate": 837.0814739309778,
   "Age": 105.06657170253513
}'
echo -e ""
echo -e "Test OK: 90"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 111.64898439163838,
   "BlastFurnaceSlag": 272.5686331760937,
   "FlyAsh": 160.2593135331837,
   "Water": 130.9716267450137,
   "Superplasticizer": 4.365420667068605,
   "CoarseAggregate": 843.2770488050925,
   "FineAggregate": 714.7905926352054,
   "Age": 290.66994563303064
}'
echo -e ""
echo -e "Test OK: 91"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 198.8703303654315,
   "BlastFurnaceSlag": 325.5736678426753,
   "FlyAsh": 77.76436438995438,
   "Water": 207.28926405938108,
   "Superplasticizer": 9.131389525781831,
   "CoarseAggregate": 996.5882310854776,
   "FineAggregate": 820.6945229026998,
   "Age": 35.042243309772786
}'
echo -e ""
echo -e "Test OK: 92"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 207.09186536495224,
   "BlastFurnaceSlag": 113.87354255784122,
   "FlyAsh": 193.43253850182393,
   "Water": 217.97550000031544,
   "Superplasticizer": 12.252448870173534,
   "CoarseAggregate": 1006.9182657748428,
   "FineAggregate": 827.7832390718356,
   "Age": 168.57332230957502
}'
echo -e ""
echo -e "Test OK: 93"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 484.75917456177933,
   "BlastFurnaceSlag": 45.52038332071054,
   "FlyAsh": 100.04882947920122,
   "Water": 158.39719267050222,
   "Superplasticizer": 16.63287291825264,
   "CoarseAggregate": 842.8415624504969,
   "FineAggregate": 665.9868921347646,
   "Age": 212.9496619324355
}'
echo -e ""
echo -e "Test OK: 94"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 507.9461461746414,
   "BlastFurnaceSlag": 270.1058404595672,
   "FlyAsh": 53.26975168946625,
   "Water": 173.98998817317016,
   "Superplasticizer": 2.0143921122668678,
   "CoarseAggregate": 1092.6815058364368,
   "FineAggregate": 911.7305803810145,
   "Age": 218.7706282634073
}'
echo -e ""
echo -e "Test OK: 95"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 514.059186071144,
   "BlastFurnaceSlag": 283.90959129891235,
   "FlyAsh": 170.18184078606544,
   "Water": 132.11770495873347,
   "Superplasticizer": 1.5792565202127913,
   "CoarseAggregate": 1045.2099773093498,
   "FineAggregate": 680.2423667724286,
   "Age": 111.69055610348394
}'
echo -e ""
echo -e "Test OK: 96"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 369.3186813810921,
   "BlastFurnaceSlag": 122.47040876079302,
   "FlyAsh": 85.38586162426975,
   "Water": 201.76554362803876,
   "Superplasticizer": 29.31033013020365,
   "CoarseAggregate": 1072.5576637539377,
   "FineAggregate": 979.4744531454792,
   "Age": 54.84264923988277
}'
echo -e ""
echo -e "Test OK: 97"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 163.30621340902496,
   "BlastFurnaceSlag": 176.04713951418796,
   "FlyAsh": 50.78925402632182,
   "Water": 209.81289785104525,
   "Superplasticizer": 26.867752230542845,
   "CoarseAggregate": 998.5355174728844,
   "FineAggregate": 913.4881214112393,
   "Age": 298.2470603874948
}'
echo -e ""
echo -e "Test OK: 98"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 427.26603916794323,
   "BlastFurnaceSlag": 117.61998939933268,
   "FlyAsh": 165.25782348400693,
   "Water": 127.39785607119586,
   "Superplasticizer": 20.662690540842014,
   "CoarseAggregate": 1108.7589974288544,
   "FineAggregate": 600.3064783706947,
   "Age": 158.80170650818908
}'
echo -e ""
echo -e "Test OK: 99"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 128.36781790089236,
   "BlastFurnaceSlag": 238.86800135016088,
   "FlyAsh": 118.02392186284811,
   "Water": 133.17751704089287,
   "Superplasticizer": 12.644188614357754,
   "CoarseAggregate": 867.2227039112142,
   "FineAggregate": 734.0288495985176,
   "Age": 27.242639101901307
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 542.0,
   "BlastFurnaceSlag": 255.80739162217796,
   "FlyAsh": 134.7394264552124,
   "Water": 253.0,
   "Superplasticizer": 10.966484364378978,
   "CoarseAggregate": 1151.0,
   "FineAggregate": 929.8365624162657,
   "Age": 275.892747478501
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 549.0,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 65.1251618585444,
   "Water": 254.0,
   "Superplasticizer": 10.581676313710089,
   "CoarseAggregate": 1154.0,
   "FineAggregate": 998.6,
   "Age": 83.22343681995314
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 370.790115591441,
   "BlastFurnaceSlag": 362.4,
   "FlyAsh": 202.1,
   "Water": 190.93837458917795,
   "Superplasticizer": 37.2,
   "CoarseAggregate": 1146.0,
   "FineAggregate": 627.1360494014526,
   "Age": 374
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 508.915126203264,
   "BlastFurnaceSlag": 368.4,
   "FlyAsh": 15.812953649796365,
   "Water": 252.0,
   "Superplasticizer": 23.18853607014456,
   "CoarseAggregate": 1154.0,
   "FineAggregate": 988.0119968983372,
   "Age": 283.0769140209971
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 318.39474196283663,
   "BlastFurnaceSlag": 361.4,
   "FlyAsh": 162.92979281292267,
   "Water": 256.0,
   "Superplasticizer": 26.651298767227296,
   "CoarseAggregate": 1154.0,
   "FineAggregate": 916.302871870141,
   "Age": 313.2443678546618
}'
echo -e ""
echo -e "Test KO: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 507.81734210453646,
   "BlastFurnaceSlag": 369.4,
   "FlyAsh": 112.53898820913321,
   "Water": 247.0,
   "Superplasticizer": 34.2,
   "CoarseAggregate": 982.943687017403,
   "FineAggregate": 1002.6,
   "Age": 268.1124477587726
}'
echo -e ""
echo -e "Test KO: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 547.0,
   "BlastFurnaceSlag": 201.21890899958467,
   "FlyAsh": 208.1,
   "Water": 195.74679367798376,
   "Superplasticizer": 30.842930594882432,
   "CoarseAggregate": 1145.0,
   "FineAggregate": 846.7792752318666,
   "Age": 32.4774716351917
}'
echo -e ""
echo -e "Test KO: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 545.0,
   "BlastFurnaceSlag": 351.8906287275795,
   "FlyAsh": 208.1,
   "Water": 223.54979671427537,
   "Superplasticizer": 1.9041982764810803,
   "CoarseAggregate": 1155.0,
   "FineAggregate": 746.4320084134806,
   "Age": 176.07273670046825
}'
echo -e ""
echo -e "Test KO: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 544.0,
   "BlastFurnaceSlag": 311.1794647935231,
   "FlyAsh": 202.1,
   "Water": 254.0,
   "Superplasticizer": 18.389876796069167,
   "CoarseAggregate": 1148.0,
   "FineAggregate": 977.1229378944333,
   "Age": 374
}'
echo -e ""
echo -e "Test KO: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 546.0,
   "BlastFurnaceSlag": 270.9270221385869,
   "FlyAsh": 112.10615660905364,
   "Water": 151.23197271549256,
   "Superplasticizer": 33.2,
   "CoarseAggregate": 957.4558796898555,
   "FineAggregate": 997.6,
   "Age": 315.504544894219
}'
echo -e ""
echo -e "Test KO: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 224.28480942171697,
   "BlastFurnaceSlag": 288.8878626910066,
   "FlyAsh": 208.1,
   "Water": 241.51904024948794,
   "Superplasticizer": 35.2,
   "CoarseAggregate": 1135.0078056298973,
   "FineAggregate": 993.6,
   "Age": 179.3286282516515
}'
echo -e ""
echo -e "Test KO: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 546.0,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 192.52043430679936,
   "Water": 248.0,
   "Superplasticizer": 39.2,
   "CoarseAggregate": 981.1352493723236,
   "FineAggregate": 704.0666545410226,
   "Age": 328.05963445212944
}'
echo -e ""
echo -e "Test KO: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 390.231384909772,
   "BlastFurnaceSlag": 360.4,
   "FlyAsh": 207.1,
   "Water": 250.0,
   "Superplasticizer": 12.457153360353194,
   "CoarseAggregate": 1151.0,
   "FineAggregate": 660.8800610682347,
   "Age": 365
}'
echo -e ""
echo -e "Test KO: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 394.6065086608338,
   "BlastFurnaceSlag": 290.12543807066066,
   "FlyAsh": 180.65709699795084,
   "Water": 239.32417744938306,
   "Superplasticizer": 33.2,
   "CoarseAggregate": 953.1295562473194,
   "FineAggregate": 996.6,
   "Age": 371
}'
echo -e ""
echo -e "Test KO: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 549.0,
   "BlastFurnaceSlag": 172.39611385923715,
   "FlyAsh": 184.07861393778,
   "Water": 253.0,
   "Superplasticizer": 3.0255668287817064,
   "CoarseAggregate": 982.9914907581517,
   "FineAggregate": 993.6,
   "Age": 112.33758161804515
}'
echo -e ""
echo -e "Test KO: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 106.45374050534937,
   "BlastFurnaceSlag": 368.4,
   "FlyAsh": 206.1,
   "Water": 178.38167979265899,
   "Superplasticizer": 40.2,
   "CoarseAggregate": 1133.2232936114983,
   "FineAggregate": 1002.6,
   "Age": 371
}'
echo -e ""
echo -e "Test KO: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 387.09713028795534,
   "BlastFurnaceSlag": 359.4,
   "FlyAsh": 7.966222278938219,
   "Water": 253.0,
   "Superplasticizer": 7.8976948492239885,
   "CoarseAggregate": 1149.0,
   "FineAggregate": 992.6,
   "Age": 249.51060683759542
}'
echo -e ""
echo -e "Test KO: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 541.0,
   "BlastFurnaceSlag": 12.591421190813358,
   "FlyAsh": 202.1,
   "Water": 252.0,
   "Superplasticizer": 35.2,
   "CoarseAggregate": 915.2224537141798,
   "FineAggregate": 998.6,
   "Age": 370
}'
echo -e ""
echo -e "Test KO: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 545.0,
   "BlastFurnaceSlag": 115.72207216662065,
   "FlyAsh": 204.1,
   "Water": 190.90159684496663,
   "Superplasticizer": 35.2,
   "CoarseAggregate": 1069.2878846544102,
   "FineAggregate": 681.2398294051869,
   "Age": 371
}'
echo -e ""
echo -e "Test KO: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 230.3348931933074,
   "BlastFurnaceSlag": 366.4,
   "FlyAsh": 202.1,
   "Water": 181.99704602914088,
   "Superplasticizer": 27.07463237155535,
   "CoarseAggregate": 1149.0,
   "FineAggregate": 799.6919379815993,
   "Age": 365
}'
echo -e ""
echo -e "Test KO: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 317.564372013793,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 71.42868281455189,
   "Water": 247.0,
   "Superplasticizer": 20.014138829048715,
   "CoarseAggregate": 1145.0,
   "FineAggregate": 999.6,
   "Age": 351.61939523904414
}'
echo -e ""
echo -e "Test KO: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 542.0,
   "BlastFurnaceSlag": 369.4,
   "FlyAsh": 205.1,
   "Water": 240.2203339844583,
   "Superplasticizer": 42.2,
   "CoarseAggregate": 842.5729107047409,
   "FineAggregate": 994.6,
   "Age": 28.286908191175364
}'
echo -e ""
echo -e "Test KO: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 541.0,
   "BlastFurnaceSlag": 118.79207664513821,
   "FlyAsh": 209.1,
   "Water": 199.03391041147296,
   "Superplasticizer": 34.2,
   "CoarseAggregate": 826.6191257291555,
   "FineAggregate": 1000.6,
   "Age": 321.36421579791306
}'
echo -e ""
echo -e "Test KO: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 151.55162791227477,
   "BlastFurnaceSlag": 359.4,
   "FlyAsh": 120.7428693033528,
   "Water": 254.0,
   "Superplasticizer": 15.672230611836486,
   "CoarseAggregate": 1155.0,
   "FineAggregate": 894.8824086815912,
   "Age": 369
}'
echo -e ""
echo -e "Test KO: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 549.0,
   "BlastFurnaceSlag": 66.79609566006522,
   "FlyAsh": 206.1,
   "Water": 191.14701152844458,
   "Superplasticizer": 34.2,
   "CoarseAggregate": 893.6860821916129,
   "FineAggregate": 998.6,
   "Age": 262.79218181426046
}'
echo -e ""
echo -e "Test KO: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 127.9649753455868,
   "BlastFurnaceSlag": 362.4,
   "FlyAsh": 159.10096723121347,
   "Water": 254.0,
   "Superplasticizer": 1.1435218795494195,
   "CoarseAggregate": 1155.0,
   "FineAggregate": 828.103855682407,
   "Age": 372
}'
echo -e ""
echo -e "Test KO: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 383.370561860472,
   "BlastFurnaceSlag": 298.4928163932335,
   "FlyAsh": 163.0766071822426,
   "Water": 255.0,
   "Superplasticizer": 26.402730601692806,
   "CoarseAggregate": 915.1890782040343,
   "FineAggregate": 938.0599987423137,
   "Age": 375
}'
echo -e ""
echo -e "Test KO: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 404.42757579046105,
   "BlastFurnaceSlag": 368.4,
   "FlyAsh": 121.13980180546191,
   "Water": 257.0,
   "Superplasticizer": 13.70121296967052,
   "CoarseAggregate": 1053.9467348200242,
   "FineAggregate": 707.1496297835691,
   "Age": 367
}'
echo -e ""
echo -e "Test KO: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 545.0,
   "BlastFurnaceSlag": 85.81940008197513,
   "FlyAsh": 19.419508480896084,
   "Water": 249.0,
   "Superplasticizer": 40.2,
   "CoarseAggregate": 867.3347793254651,
   "FineAggregate": 1000.6,
   "Age": 295.9992631430569
}'
echo -e ""
echo -e "Test KO: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 548.0,
   "BlastFurnaceSlag": 320.0773718174017,
   "FlyAsh": 203.1,
   "Water": 223.8102157017819,
   "Superplasticizer": 37.2,
   "CoarseAggregate": 1150.0,
   "FineAggregate": 758.8951561141802,
   "Age": 375
}'
echo -e ""
echo -e "Test KO: 30"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 119.94377684223255,
   "BlastFurnaceSlag": 364.4,
   "FlyAsh": 33.07718267628441,
   "Water": 252.0,
   "Superplasticizer": 12.530347859372661,
   "CoarseAggregate": 1152.0,
   "FineAggregate": 669.4657058429231,
   "Age": 367
}'
echo -e ""
echo -e "Test KO: 31"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 546.0,
   "BlastFurnaceSlag": 37.692916369826996,
   "FlyAsh": 204.1,
   "Water": 179.61455310756395,
   "Superplasticizer": 31.075177292523627,
   "CoarseAggregate": 1149.0,
   "FineAggregate": 624.9979259005393,
   "Age": 202.21895233620495
}'
echo -e ""
echo -e "Test KO: 32"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 544.0,
   "BlastFurnaceSlag": 331.22111691992325,
   "FlyAsh": 173.5953817020571,
   "Water": 250.0,
   "Superplasticizer": 22.732513293350895,
   "CoarseAggregate": 978.021287349189,
   "FineAggregate": 919.173445345788,
   "Age": 43.333283405219625
}'
echo -e ""
echo -e "Test KO: 33"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 545.0,
   "BlastFurnaceSlag": 361.4,
   "FlyAsh": 95.22114347731802,
   "Water": 253.0,
   "Superplasticizer": 42.2,
   "CoarseAggregate": 1146.0,
   "FineAggregate": 642.5789469209323,
   "Age": 375
}'
echo -e ""
echo -e "Test KO: 34"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 376.88183894110625,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 208.1,
   "Water": 145.78599750901267,
   "Superplasticizer": 8.714732405655745,
   "CoarseAggregate": 1148.0,
   "FineAggregate": 1000.6,
   "Age": 135.38812547621043
}'
echo -e ""
echo -e "Test KO: 35"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 540.0,
   "BlastFurnaceSlag": 29.321158080949974,
   "FlyAsh": 204.1,
   "Water": 218.55873446093017,
   "Superplasticizer": 34.2,
   "CoarseAggregate": 1078.0423599676128,
   "FineAggregate": 996.6,
   "Age": 85.75273514940147
}'
echo -e ""
echo -e "Test KO: 36"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 550.0,
   "BlastFurnaceSlag": 83.6955700496019,
   "FlyAsh": 209.1,
   "Water": 241.00424315396617,
   "Superplasticizer": 36.2,
   "CoarseAggregate": 976.2313288800619,
   "FineAggregate": 630.4059358905106,
   "Age": 295.90565780298675
}'
echo -e ""
echo -e "Test KO: 37"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 543.0,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 115.42522444089478,
   "Water": 256.0,
   "Superplasticizer": 31.166668538502527,
   "CoarseAggregate": 1153.0,
   "FineAggregate": 805.0966289550406,
   "Age": 370
}'
echo -e ""
echo -e "Test KO: 38"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 330.9629525150348,
   "BlastFurnaceSlag": 368.4,
   "FlyAsh": 133.06736954147019,
   "Water": 257.0,
   "Superplasticizer": 32.2,
   "CoarseAggregate": 1151.0,
   "FineAggregate": 804.2729257259747,
   "Age": 369
}'
echo -e ""
echo -e "Test KO: 39"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 418.7233696150262,
   "BlastFurnaceSlag": 366.4,
   "FlyAsh": 72.73050461914714,
   "Water": 251.0,
   "Superplasticizer": 17.537608988814096,
   "CoarseAggregate": 1071.0977689382964,
   "FineAggregate": 1001.6,
   "Age": 307.5841803050995
}'
echo -e ""
echo -e "Test KO: 40"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 354.63222039006797,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 153.25882118375688,
   "Water": 253.0,
   "Superplasticizer": 25.73492526324429,
   "CoarseAggregate": 1146.0,
   "FineAggregate": 730.9728027138959,
   "Age": 82.14260073758996
}'
echo -e ""
echo -e "Test KO: 41"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 316.09428616532085,
   "BlastFurnaceSlag": 362.4,
   "FlyAsh": 84.39273481653704,
   "Water": 208.93312805503018,
   "Superplasticizer": 35.2,
   "CoarseAggregate": 1155.0,
   "FineAggregate": 722.1194767364705,
   "Age": 374
}'
echo -e ""
echo -e "Test KO: 42"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 542.0,
   "BlastFurnaceSlag": 19.262311902909705,
   "FlyAsh": 201.1,
   "Water": 220.9266844626876,
   "Superplasticizer": 34.2,
   "CoarseAggregate": 1153.0,
   "FineAggregate": 993.6,
   "Age": 175.13266519134064
}'
echo -e ""
echo -e "Test KO: 43"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 542.0,
   "BlastFurnaceSlag": 62.09542190858757,
   "FlyAsh": 71.88765912223977,
   "Water": 188.69767262897184,
   "Superplasticizer": 41.2,
   "CoarseAggregate": 1148.0,
   "FineAggregate": 997.6,
   "Age": 237.1405620844613
}'
echo -e ""
echo -e "Test KO: 44"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 550.0,
   "BlastFurnaceSlag": 360.4,
   "FlyAsh": 178.87790140494835,
   "Water": 256.0,
   "Superplasticizer": 35.2,
   "CoarseAggregate": 1124.198896351306,
   "FineAggregate": 1000.6,
   "Age": 311.30891995527674
}'
echo -e ""
echo -e "Test KO: 45"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 186.2243821744033,
   "BlastFurnaceSlag": 364.4,
   "FlyAsh": 6.661282773244833,
   "Water": 203.15229972978779,
   "Superplasticizer": 33.2,
   "CoarseAggregate": 1097.4713328610046,
   "FineAggregate": 1002.6,
   "Age": 57.991049343802935
}'
echo -e ""
echo -e "Test KO: 46"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 163.75098968424402,
   "BlastFurnaceSlag": 359.4,
   "FlyAsh": 184.56530384729788,
   "Water": 254.0,
   "Superplasticizer": 17.871395850698576,
   "CoarseAggregate": 1154.0,
   "FineAggregate": 776.7063863235968,
   "Age": 303.2973301753285
}'
echo -e ""
echo -e "Test KO: 47"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 548.0,
   "BlastFurnaceSlag": 10.992635591221283,
   "FlyAsh": 205.1,
   "Water": 148.55226693003925,
   "Superplasticizer": 41.2,
   "CoarseAggregate": 1104.8418061895707,
   "FineAggregate": 745.1810093001154,
   "Age": 372
}'
echo -e ""
echo -e "Test KO: 48"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 204.40921380557015,
   "BlastFurnaceSlag": 368.4,
   "FlyAsh": 172.48415081766547,
   "Water": 255.0,
   "Superplasticizer": 3.3593083740375937,
   "CoarseAggregate": 1151.0,
   "FineAggregate": 986.1927755539168,
   "Age": 369
}'
echo -e ""
echo -e "Test KO: 49"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 545.0,
   "BlastFurnaceSlag": 363.4,
   "FlyAsh": 53.88190009306784,
   "Water": 248.0,
   "Superplasticizer": 23.897909778409865,
   "CoarseAggregate": 1155.0,
   "FineAggregate": 862.8981396086434,
   "Age": 373
}'
echo -e ""
echo -e "Test KO: 50"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 408.8223891484005,
   "BlastFurnaceSlag": 360.4,
   "FlyAsh": 174.18408103521563,
   "Water": 207.24996416067376,
   "Superplasticizer": 42.2,
   "CoarseAggregate": 968.5060273493093,
   "FineAggregate": 843.1003457594444,
   "Age": 368
}'
echo -e ""
echo -e "Test KO: 51"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 271.1534207651519,
   "BlastFurnaceSlag": 366.4,
   "FlyAsh": 201.1,
   "Water": 250.0,
   "Superplasticizer": 33.2,
   "CoarseAggregate": 879.6050736194203,
   "FineAggregate": 995.6,
   "Age": 94.72134732692078
}'
echo -e ""
echo -e "Test KO: 52"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 545.0,
   "BlastFurnaceSlag": 28.23470278420596,
   "FlyAsh": 172.4132360646002,
   "Water": 257.0,
   "Superplasticizer": 30.084815410960456,
   "CoarseAggregate": 1154.0,
   "FineAggregate": 865.3963836429433,
   "Age": 370
}'
echo -e ""
echo -e "Test KO: 53"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 359.527954385723,
   "BlastFurnaceSlag": 364.4,
   "FlyAsh": 17.701819575118446,
   "Water": 236.00212022299326,
   "Superplasticizer": 35.2,
   "CoarseAggregate": 1154.0,
   "FineAggregate": 992.6,
   "Age": 98.7301129860164
}'
echo -e ""
echo -e "Test KO: 54"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 435.67515432707177,
   "BlastFurnaceSlag": 364.4,
   "FlyAsh": 204.1,
   "Water": 160.2277896409882,
   "Superplasticizer": 33.2,
   "CoarseAggregate": 810.4011879120319,
   "FineAggregate": 1001.6,
   "Age": 266.4684195091499
}'
echo -e ""
echo -e "Test KO: 55"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 160.64561557211633,
   "BlastFurnaceSlag": 359.4,
   "FlyAsh": 184.42866710645347,
   "Water": 256.0,
   "Superplasticizer": 11.74279800268015,
   "CoarseAggregate": 1154.0,
   "FineAggregate": 999.6,
   "Age": 215.3159243560636
}'
echo -e ""
echo -e "Test KO: 56"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 462.38134559770975,
   "BlastFurnaceSlag": 364.4,
   "FlyAsh": 49.51365479761216,
   "Water": 250.0,
   "Superplasticizer": 0.7421150627512334,
   "CoarseAggregate": 1155.0,
   "FineAggregate": 917.5847799761652,
   "Age": 367
}'
echo -e ""
echo -e "Test KO: 57"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 275.95448284874715,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 203.1,
   "Water": 228.19731028580924,
   "Superplasticizer": 40.2,
   "CoarseAggregate": 932.4423500280384,
   "FineAggregate": 997.6,
   "Age": 184.45821639447513
}'
echo -e ""
echo -e "Test KO: 58"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 540.0,
   "BlastFurnaceSlag": 369.4,
   "FlyAsh": 75.69070125165202,
   "Water": 221.10621853444957,
   "Superplasticizer": 4.407511186700151,
   "CoarseAggregate": 1147.0,
   "FineAggregate": 644.654233663225,
   "Age": 368
}'
echo -e ""
echo -e "Test KO: 59"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 544.0,
   "BlastFurnaceSlag": 39.04348622478889,
   "FlyAsh": 205.1,
   "Water": 207.09463603968982,
   "Superplasticizer": 1.054243480781024,
   "CoarseAggregate": 1155.0,
   "FineAggregate": 993.6,
   "Age": 173.25272029198067
}'
echo -e ""
echo -e "Test KO: 60"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 181.6804186305502,
   "BlastFurnaceSlag": 361.4,
   "FlyAsh": 167.45946223893523,
   "Water": 247.0,
   "Superplasticizer": 13.923251493111186,
   "CoarseAggregate": 1149.0,
   "FineAggregate": 829.0571977878544,
   "Age": 372
}'
echo -e ""
echo -e "Test KO: 61"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 344.325128457015,
   "BlastFurnaceSlag": 359.4,
   "FlyAsh": 54.13544881939163,
   "Water": 250.0,
   "Superplasticizer": 25.74041685015288,
   "CoarseAggregate": 1155.0,
   "FineAggregate": 868.7975017838249,
   "Age": 368
}'
echo -e ""
echo -e "Test KO: 62"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 541.0,
   "BlastFurnaceSlag": 90.18493771633183,
   "FlyAsh": 204.1,
   "Water": 191.48392596636273,
   "Superplasticizer": 37.2,
   "CoarseAggregate": 1121.4345577606991,
   "FineAggregate": 1000.6,
   "Age": 372
}'
echo -e ""
echo -e "Test KO: 63"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 484.707246831656,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 30.818031828151938,
   "Water": 253.0,
   "Superplasticizer": 40.2,
   "CoarseAggregate": 1114.859484888456,
   "FineAggregate": 771.1126069631173,
   "Age": 57.7222425359141
}'
echo -e ""
echo -e "Test KO: 64"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 542.0,
   "BlastFurnaceSlag": 41.9858330440271,
   "FlyAsh": 200.1,
   "Water": 212.48581849113413,
   "Superplasticizer": 32.2,
   "CoarseAggregate": 1057.9702725269508,
   "FineAggregate": 736.6696630234601,
   "Age": 373
}'
echo -e ""
echo -e "Test KO: 65"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 541.0,
   "BlastFurnaceSlag": 204.34484627629857,
   "FlyAsh": 210.1,
   "Water": 179.98813883231273,
   "Superplasticizer": 39.2,
   "CoarseAggregate": 817.9171883867836,
   "FineAggregate": 1000.6,
   "Age": 152.29398889201664
}'
echo -e ""
echo -e "Test KO: 66"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 412.7655762251307,
   "BlastFurnaceSlag": 360.4,
   "FlyAsh": 143.8284300082722,
   "Water": 253.0,
   "Superplasticizer": 5.72996771379994,
   "CoarseAggregate": 1145.0,
   "FineAggregate": 1001.6,
   "Age": 275.1087322224545
}'
echo -e ""
echo -e "Test KO: 67"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 541.0,
   "BlastFurnaceSlag": 363.4,
   "FlyAsh": 206.1,
   "Water": 239.66198116632245,
   "Superplasticizer": 12.986754396242043,
   "CoarseAggregate": 916.667931868464,
   "FineAggregate": 997.6,
   "Age": 78.9751691717699
}'
echo -e ""
echo -e "Test KO: 68"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 543.0,
   "BlastFurnaceSlag": 259.1771089637175,
   "FlyAsh": 201.1,
   "Water": 143.3014744794778,
   "Superplasticizer": 39.2,
   "CoarseAggregate": 959.0825007448741,
   "FineAggregate": 778.7814647089243,
   "Age": 366
}'
echo -e ""
echo -e "Test KO: 69"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 322.6272293573383,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 181.76416891639923,
   "Water": 257.0,
   "Superplasticizer": 28.210375741624265,
   "CoarseAggregate": 1152.0,
   "FineAggregate": 1002.6,
   "Age": 59.94028369820268
}'
echo -e ""
echo -e "Test KO: 70"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 451.36842918494835,
   "BlastFurnaceSlag": 364.4,
   "FlyAsh": 107.5212645784499,
   "Water": 133.60832150688364,
   "Superplasticizer": 33.2,
   "CoarseAggregate": 1129.2983632561113,
   "FineAggregate": 641.1046284864447,
   "Age": 367
}'
echo -e ""
echo -e "Test KO: 71"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 545.0,
   "BlastFurnaceSlag": 368.4,
   "FlyAsh": 81.61977209316503,
   "Water": 256.0,
   "Superplasticizer": 22.53531832060922,
   "CoarseAggregate": 1152.0,
   "FineAggregate": 1000.6,
   "Age": 47.91774572525459
}'
echo -e ""
echo -e "Test KO: 72"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 477.4750244630902,
   "BlastFurnaceSlag": 361.4,
   "FlyAsh": 135.16617722488792,
   "Water": 253.0,
   "Superplasticizer": 11.76468433127844,
   "CoarseAggregate": 1148.0,
   "FineAggregate": 869.1128704977551,
   "Age": 368
}'
echo -e ""
echo -e "Test KO: 73"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 262.38657829028983,
   "BlastFurnaceSlag": 367.4,
   "FlyAsh": 210.1,
   "Water": 241.47153441598857,
   "Superplasticizer": 38.2,
   "CoarseAggregate": 1153.0,
   "FineAggregate": 786.2095154673111,
   "Age": 373
}'
echo -e ""
echo -e "Test KO: 74"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 543.0,
   "BlastFurnaceSlag": 361.4,
   "FlyAsh": 210.1,
   "Water": 245.35894260465813,
   "Superplasticizer": 7.375802596732209,
   "CoarseAggregate": 1021.618811555678,
   "FineAggregate": 992.6,
   "Age": 90.79189697683819
}'
echo -e ""
echo -e "Test KO: 75"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 264.24670413283246,
   "BlastFurnaceSlag": 359.4,
   "FlyAsh": 210.1,
   "Water": 196.5976830925526,
   "Superplasticizer": 37.2,
   "CoarseAggregate": 862.8146652454346,
   "FineAggregate": 995.6,
   "Age": 89.54143057885231
}'
echo -e ""
echo -e "Test KO: 76"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 540.0,
   "BlastFurnaceSlag": 229.26778988889814,
   "FlyAsh": 51.191461928849264,
   "Water": 247.0,
   "Superplasticizer": 8.264359242153871,
   "CoarseAggregate": 898.4888659689254,
   "FineAggregate": 998.6,
   "Age": 371
}'
echo -e ""
echo -e "Test KO: 77"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 398.6764630517567,
   "BlastFurnaceSlag": 365.4,
   "FlyAsh": 206.1,
   "Water": 134.34788579389976,
   "Superplasticizer": 34.2,
   "CoarseAggregate": 1063.3314973615984,
   "FineAggregate": 998.6,
   "Age": 294.73794559653106
}'
echo -e ""
echo -e "Test KO: 78"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 548.0,
   "BlastFurnaceSlag": 359.4,
   "FlyAsh": 110.04082896203995,
   "Water": 248.0,
   "Superplasticizer": 10.340360213739531,
   "CoarseAggregate": 1150.0,
   "FineAggregate": 995.6,
   "Age": 254.9305667345402
}'
echo -e ""
echo -e "Test KO: 79"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 245.9798337180979,
   "BlastFurnaceSlag": 362.4,
   "FlyAsh": 65.24103533020599,
   "Water": 156.82023783252762,
   "Superplasticizer": 37.2,
   "CoarseAggregate": 982.4818613424868,
   "FineAggregate": 996.6,
   "Age": 160.89390399015824
}'
echo -e ""
echo -e "Test KO: 80"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 549.0,
   "BlastFurnaceSlag": 216.38367596545572,
   "FlyAsh": 202.1,
   "Water": 210.18540369351302,
   "Superplasticizer": 32.2,
   "CoarseAggregate": 1101.6334797749519,
   "FineAggregate": 1001.6,
   "Age": 188.97434681209936
}'
echo -e ""
echo -e "Test KO: 81"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 160.78117460153342,
   "BlastFurnaceSlag": 361.4,
   "FlyAsh": 61.642899714494014,
   "Water": 255.0,
   "Superplasticizer": 0.25545309913712544,
   "CoarseAggregate": 1146.0,
   "FineAggregate": 687.1880726594707,
   "Age": 207.16517124438386
}'
echo -e ""
echo -e "Test KO: 82"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 550.0,
   "BlastFurnaceSlag": 171.56066863525976,
   "FlyAsh": 16.145858539354006,
   "Water": 170.74393153346787,
   "Superplasticizer": 39.2,
   "CoarseAggregate": 995.6850140113548,
   "FineAggregate": 1002.6,
   "Age": 188.22083691763825
}'
echo -e ""
echo -e "Test KO: 83"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 542.0,
   "BlastFurnaceSlag": 186.79941941734893,
   "FlyAsh": 203.1,
   "Water": 208.43323168697032,
   "Superplasticizer": 33.2,
   "CoarseAggregate": 1149.0,
   "FineAggregate": 909.9873735846875,
   "Age": 373
}'
echo -e ""
echo -e "Test KO: 84"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 485.3948466195503,
   "BlastFurnaceSlag": 105.72196402487396,
   "FlyAsh": 118.65838490098002,
   "Water": 250.0,
   "Superplasticizer": 14.137299395741032,
   "CoarseAggregate": 1145.0,
   "FineAggregate": 823.3993036898056,
   "Age": 375
}'
echo -e ""
echo -e "Test KO: 85"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 542.0,
   "BlastFurnaceSlag": 286.0571218805627,
   "FlyAsh": 203.1,
   "Water": 255.0,
   "Superplasticizer": 16.630911263370663,
   "CoarseAggregate": 975.2935174519943,
   "FineAggregate": 994.6,
   "Age": 80.36817143545184
}'
echo -e ""
echo -e "Test KO: 86"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 541.0,
   "BlastFurnaceSlag": 19.391190241268788,
   "FlyAsh": 205.1,
   "Water": 122.11958640565709,
   "Superplasticizer": 33.2,
   "CoarseAggregate": 1113.977252768572,
   "FineAggregate": 998.6,
   "Age": 254.52070033960055
}'
echo -e ""
echo -e "Test KO: 87"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 547.0,
   "BlastFurnaceSlag": 209.62631252979435,
   "FlyAsh": 204.1,
   "Water": 188.0100167839388,
   "Superplasticizer": 37.2,
   "CoarseAggregate": 838.2057076100468,
   "FineAggregate": 1000.6,
   "Age": 352.13943219204805
}'
echo -e ""
echo -e "Test KO: 88"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 546.0,
   "BlastFurnaceSlag": 240.16125337894118,
   "FlyAsh": 210.1,
   "Water": 189.21135772753297,
   "Superplasticizer": 12.532341607047634,
   "CoarseAggregate": 1008.548664837755,
   "FineAggregate": 992.6,
   "Age": 193.09783829136927
}'
echo -e ""
echo -e "Test KO: 89"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 250.95892667765955,
   "BlastFurnaceSlag": 284.087126085013,
   "FlyAsh": 209.1,
   "Water": 205.40268406037472,
   "Superplasticizer": 32.2,
   "CoarseAggregate": 806.9065517135798,
   "FineAggregate": 919.1439663554917,
   "Age": 75.6381912346144
}'
echo -e ""
echo -e "Test KO: 90"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 306.07679984658444,
   "BlastFurnaceSlag": 341.4038643101516,
   "FlyAsh": 44.90137617086209,
   "Water": 257.0,
   "Superplasticizer": 36.2,
   "CoarseAggregate": 1145.0,
   "FineAggregate": 694.3431366818857,
   "Age": 375
}'
echo -e ""
echo -e "Test KO: 91"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 132.6536154193017,
   "BlastFurnaceSlag": 189.5802703159993,
   "FlyAsh": 49.64929978782116,
   "Water": 145.73386455718776,
   "Superplasticizer": 32.2,
   "CoarseAggregate": 857.5639442546386,
   "FineAggregate": 1000.6,
   "Age": 115.41227311022523
}'
echo -e ""
echo -e "Test KO: 92"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 545.0,
   "BlastFurnaceSlag": 150.9308572606823,
   "FlyAsh": 94.34566299151057,
   "Water": 194.87196619181537,
   "Superplasticizer": 42.2,
   "CoarseAggregate": 1146.0,
   "FineAggregate": 998.6,
   "Age": 166.28328841624108
}'
echo -e ""
echo -e "Test KO: 93"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 121.24594446234597,
   "BlastFurnaceSlag": 368.4,
   "FlyAsh": 192.06217731191015,
   "Water": 248.0,
   "Superplasticizer": 39.2,
   "CoarseAggregate": 859.8346264216303,
   "FineAggregate": 992.6,
   "Age": 9.258953397279235
}'
echo -e ""
echo -e "Test KO: 94"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 548.0,
   "BlastFurnaceSlag": 196.6092679153716,
   "FlyAsh": 27.944325833643436,
   "Water": 255.0,
   "Superplasticizer": 14.772430715020656,
   "CoarseAggregate": 1151.0,
   "FineAggregate": 620.1438543388688,
   "Age": 366
}'
echo -e ""
echo -e "Test KO: 95"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 549.0,
   "BlastFurnaceSlag": 309.19962441405653,
   "FlyAsh": 109.79738182878998,
   "Water": 136.37758363634606,
   "Superplasticizer": 39.2,
   "CoarseAggregate": 1021.159985002568,
   "FineAggregate": 1001.6,
   "Age": 4.776216678047576
}'
echo -e ""
echo -e "Test KO: 96"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 138.98109902677112,
   "BlastFurnaceSlag": 360.4,
   "FlyAsh": 13.495284243456638,
   "Water": 254.0,
   "Superplasticizer": 6.101122971763164,
   "CoarseAggregate": 1150.0,
   "FineAggregate": 727.7316554242288,
   "Age": 371
}'
echo -e ""
echo -e "Test KO: 97"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 218.9412100694041,
   "BlastFurnaceSlag": 72.61423760794688,
   "FlyAsh": 207.1,
   "Water": 173.77452692146016,
   "Superplasticizer": 39.2,
   "CoarseAggregate": 855.0476971199182,
   "FineAggregate": 992.6,
   "Age": 367
}'
echo -e ""
echo -e "Test KO: 98"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 544.0,
   "BlastFurnaceSlag": 60.626145907162574,
   "FlyAsh": 203.1,
   "Water": 183.6916392664101,
   "Superplasticizer": 34.2,
   "CoarseAggregate": 1097.7693297013016,
   "FineAggregate": 843.667909000631,
   "Age": 371
}'
echo -e ""
echo -e "Test KO: 99"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 385.940234361943,
   "BlastFurnaceSlag": 366.4,
   "FlyAsh": 196.01523142914758,
   "Water": 253.0,
   "Superplasticizer": 32.2,
   "CoarseAggregate": 1079.1270473115433,
   "FineAggregate": 995.6,
   "Age": 370
}'
echo -e ""
