echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 437.2783902962867,
   "Blast_Furnace_Slag": 256.33250525822,
   "Fly_Ash": 142.05462789638696,
   "Water": 217.07212725517653,
   "Superplasticizer": 7.49139578501844,
   "Coarse_Aggregate": 979.4747771491824,
   "Fine_Aggregate": 806.0417745039974,
   "Age": 198.68734507340722
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 289.50278853287506,
   "Blast_Furnace_Slag": 44.152836224522346,
   "Fly_Ash": 101.52645212992071,
   "Water": 157.6932086523256,
   "Superplasticizer": 16.007560020941092,
   "Coarse_Aggregate": 877.8582593359639,
   "Fine_Aggregate": 835.3802323601551,
   "Age": 213.26854441861266
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 517.1904056102524,
   "Blast_Furnace_Slag": 300.47502444464425,
   "Fly_Ash": 120.99165610202397,
   "Water": 178.33241317187276,
   "Superplasticizer": 10.206898157447974,
   "Coarse_Aggregate": 925.7412228167784,
   "Fine_Aggregate": 938.6321648767546,
   "Age": 51.612682497577666
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 543.0,
   "Blast_Furnace_Slag": 102.17440839081627,
   "Fly_Ash": 208.1,
   "Water": 250.0,
   "Superplasticizer": 9.476630976881848,
   "Coarse_Aggregate": 1150.0,
   "Fine_Aggregate": 994.6,
   "Age": 125.83906609088442
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 398.2105986862312,
   "Blast_Furnace_Slag": 363.4,
   "Fly_Ash": 132.8101853678175,
   "Water": 254.0,
   "Superplasticizer": 20.66824973148047,
   "Coarse_Aggregate": 1154.0,
   "Fine_Aggregate": 848.7143783474603,
   "Age": 371
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 237.03488174993092,
   "Blast_Furnace_Slag": 364.4,
   "Fly_Ash": 105.20282033628996,
   "Water": 234.71074374640887,
   "Superplasticizer": 36.2,
   "Coarse_Aggregate": 847.4351241861177,
   "Fine_Aggregate": 997.6,
   "Age": 60.52462122024629
}'
echo -e ""
