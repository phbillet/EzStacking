echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 2.1457070619567356,
   "Passive_Smoker": 1.0952781823640851,
   "Wheezing": 2.1844552990398296,
   "Clubbing_of_Finger_Nails": 8.515503705660539,
   "Snoring": 6.074552935416482
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 1.7622901792777985,
   "Passive_Smoker": 7.621326953426591,
   "Wheezing": 4.90070968456874,
   "Clubbing_of_Finger_Nails": 6.90231309414329,
   "Snoring": 6.508620996652812
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 4.63688959714416,
   "Passive_Smoker": 5.543809720816359,
   "Wheezing": 5.973202447987075,
   "Clubbing_of_Finger_Nails": 4.652898640517279,
   "Snoring": 4.850334983664815
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 1.9183026204166944,
   "Passive_Smoker": 3.8158302871797005,
   "Wheezing": 4.788777036596143,
   "Clubbing_of_Finger_Nails": 4.245250532554546,
   "Snoring": 2.5510023083409368
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 1.255517563524923,
   "Passive_Smoker": 6.822395756761997,
   "Wheezing": 3.632900080900962,
   "Clubbing_of_Finger_Nails": 1.564237712907091,
   "Snoring": 5.063297222193287
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 2.8016256978904224,
   "Passive_Smoker": 5.1650794834189675,
   "Wheezing": 7.401848584221337,
   "Clubbing_of_Finger_Nails": 5.46059739735083,
   "Snoring": 6.04944433279362
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 1.409758964842233,
   "Passive_Smoker": 2.987457305016603,
   "Wheezing": 5.93885653972745,
   "Clubbing_of_Finger_Nails": 2.583014315271626,
   "Snoring": 6.882671197183234
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 3.3535280442438147,
   "Passive_Smoker": 5.118457746992079,
   "Wheezing": 6.544243571050805,
   "Clubbing_of_Finger_Nails": 1.9994933867926026,
   "Snoring": 1.1694146940331516
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 6.674537707089063,
   "Passive_Smoker": 2.151124087791403,
   "Wheezing": 4.172558751526646,
   "Clubbing_of_Finger_Nails": 1.1965040151884967,
   "Snoring": 1.3521184037572753
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 5.887042721096687,
   "Passive_Smoker": 7.847371992771194,
   "Wheezing": 1.0037920898032544,
   "Clubbing_of_Finger_Nails": 6.851551995602595,
   "Snoring": 2.8126574491272427
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 1.4388078701913316,
   "Passive_Smoker": 4.508193495162807,
   "Wheezing": 1.904047366045072,
   "Clubbing_of_Finger_Nails": 8.953583215176819,
   "Snoring": 4.531788579639942
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 4.254758032589666,
   "Passive_Smoker": 2.59345371103198,
   "Wheezing": 3.0134965760741452,
   "Clubbing_of_Finger_Nails": 8.703232624806693,
   "Snoring": 2.6110863134201114
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 1.7778439636246484,
   "Passive_Smoker": 4.447429254179167,
   "Wheezing": 3.2149335320238155,
   "Clubbing_of_Finger_Nails": 7.368978012559924,
   "Snoring": 2.593785728389011
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 3.135851078064918,
   "Passive_Smoker": 7.150085312317011,
   "Wheezing": 4.666626065488815,
   "Clubbing_of_Finger_Nails": 5.472066644924975,
   "Snoring": 1.161547459810174
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 3.147226002698816,
   "Passive_Smoker": 6.52629911086813,
   "Wheezing": 4.682689017021255,
   "Clubbing_of_Finger_Nails": 3.6239033825689493,
   "Snoring": 2.495401122857513
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 4.161440311656056,
   "Passive_Smoker": 3.040001816806682,
   "Wheezing": 7.490448463227942,
   "Clubbing_of_Finger_Nails": 3.364071102614954,
   "Snoring": 1.815690342354957
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 4.231237284465528,
   "Passive_Smoker": 5.167998172396755,
   "Wheezing": 6.178934821922961,
   "Clubbing_of_Finger_Nails": 2.45793060215399,
   "Snoring": 2.596008475156931
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 4.300004230099942,
   "Passive_Smoker": 2.001863178765375,
   "Wheezing": 7.104533636873255,
   "Clubbing_of_Finger_Nails": 3.5803052157227446,
   "Snoring": 4.024070254636156
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 6.010411627350544,
   "Passive_Smoker": 5.625729900663707,
   "Wheezing": 3.3307104255648317,
   "Clubbing_of_Finger_Nails": 2.8239181840574235,
   "Snoring": 5.570447306935783
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 4.14608975572135,
   "Passive_Smoker": 4.756985376742165,
   "Wheezing": 6.463721749387492,
   "Clubbing_of_Finger_Nails": 6.366711513041782,
   "Snoring": 3.0501081145763376
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 13,
   "Passive_Smoker": 1.2622981033475824,
   "Wheezing": 13,
   "Clubbing_of_Finger_Nails": 6.035372994602493,
   "Snoring": 5.443063384931637
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 6.896897112870635,
   "Passive_Smoker": 18,
   "Wheezing": 5.5842030930165265,
   "Clubbing_of_Finger_Nails": 15,
   "Snoring": 8
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Balanced_Diet": 5.070947623035399,
   "Passive_Smoker": 10,
   "Wheezing": 14,
   "Clubbing_of_Finger_Nails": 6.96298144713257,
   "Snoring": 17
}'
echo -e ""
