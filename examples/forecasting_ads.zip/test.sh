echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 80475.27937975137,
   "Ads_t_5": 72768.84843683899,
   "Ads_t_4": 75609.65713083353,
   "Ads_t_2": 165426.7075218568,
   "Ads_t_1": 161475.1823597169
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 117071.44623719034,
   "Ads_t_5": 106726.84329132875,
   "Ads_t_4": 89189.47462036791,
   "Ads_t_2": 76474.67663166008,
   "Ads_t_1": 162610.16925439792
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 136165.28113474045,
   "Ads_t_5": 152587.12463875965,
   "Ads_t_4": 149002.44667253146,
   "Ads_t_2": 154856.67528407628,
   "Ads_t_1": 120681.5164059264
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 164288.2942285793,
   "Ads_t_5": 147913.78058848597,
   "Ads_t_4": 120382.44295973632,
   "Ads_t_2": 92406.26602208891,
   "Ads_t_1": 97523.57410930589
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 75356.3716723632,
   "Ads_t_5": 88923.31540839383,
   "Ads_t_4": 112535.08814679158,
   "Ads_t_2": 145139.73813294206,
   "Ads_t_1": 146563.58339048715
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 106728.12064836746,
   "Ads_t_5": 96392.22706475978,
   "Ads_t_4": 75677.07556797596,
   "Ads_t_2": 84503.31065305078,
   "Ads_t_1": 131894.19381319743
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 148862.79101689483,
   "Ads_t_5": 155673.59938111712,
   "Ads_t_4": 135934.37076966223,
   "Ads_t_2": 106084.0798471329,
   "Ads_t_1": 80931.77131942016
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 73854.34044376882,
   "Ads_t_5": 73635.64004016465,
   "Ads_t_4": 155418.63318135153,
   "Ads_t_2": 137875.4844088375,
   "Ads_t_1": 107902.36146038526
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 103710.78790910478,
   "Ads_t_5": 105365.31091244597,
   "Ads_t_4": 138099.78819588985,
   "Ads_t_2": 158740.45318364,
   "Ads_t_1": 91690.75140960535
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 105409.33068168841,
   "Ads_t_5": 100109.92672710388,
   "Ads_t_4": 122261.52275475457,
   "Ads_t_2": 79414.42217598394,
   "Ads_t_1": 146238.85664605015
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 169904.0,
   "Ads_t_5": 113467.82484026828,
   "Ads_t_4": 118502.14598969865,
   "Ads_t_2": 169907.0,
   "Ads_t_1": 169903.0
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 169902.0,
   "Ads_t_5": 100066.04603042931,
   "Ads_t_4": 169907.0,
   "Ads_t_2": 150928.37526407163,
   "Ads_t_1": 169903.0
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ads_t_6": 138215.53788539834,
   "Ads_t_5": 100222.25077780228,
   "Ads_t_4": 95880.21781513466,
   "Ads_t_2": 169910.0,
   "Ads_t_1": 169910.0
}'
echo -e ""
