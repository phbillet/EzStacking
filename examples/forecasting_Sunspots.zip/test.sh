echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 369.8177722278062,
   "Total_Sunspot_Number_t_4": 19.146615549010313,
   "Total_Sunspot_Number_t_3": 255.24795664468266,
   "Total_Sunspot_Number_t_2": 379.9769412793689,
   "Total_Sunspot_Number_t_1": 280.77545083540593
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 208.09082059327616,
   "Total_Sunspot_Number_t_4": 164.30875492986405,
   "Total_Sunspot_Number_t_3": 236.59013160675627,
   "Total_Sunspot_Number_t_2": 293.54036584199144,
   "Total_Sunspot_Number_t_1": 220.43518040588467
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 139.796543201551,
   "Total_Sunspot_Number_t_4": 342.463584094229,
   "Total_Sunspot_Number_t_3": 371.38866546368973,
   "Total_Sunspot_Number_t_2": 343.1228762802467,
   "Total_Sunspot_Number_t_1": 338.9936251216213
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 185.5981518019948,
   "Total_Sunspot_Number_t_4": 1.6149674206192368,
   "Total_Sunspot_Number_t_3": 266.13427014965265,
   "Total_Sunspot_Number_t_2": 33.2064874260507,
   "Total_Sunspot_Number_t_1": 60.97563646202984
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 260.56707509625994,
   "Total_Sunspot_Number_t_4": 397.84930673198716,
   "Total_Sunspot_Number_t_3": 217.46239109053803,
   "Total_Sunspot_Number_t_2": 284.6936767533349,
   "Total_Sunspot_Number_t_1": 314.8860381429214
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 68.07118311500474,
   "Total_Sunspot_Number_t_4": 39.37304617785479,
   "Total_Sunspot_Number_t_3": 24.656744583503983,
   "Total_Sunspot_Number_t_2": 294.30034463278406,
   "Total_Sunspot_Number_t_1": 326.94600841473584
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 332.90239572698556,
   "Total_Sunspot_Number_t_4": 322.317322357938,
   "Total_Sunspot_Number_t_3": 361.41937552365124,
   "Total_Sunspot_Number_t_2": 205.55091536170298,
   "Total_Sunspot_Number_t_1": 322.0497141542939
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 200.72018656017997,
   "Total_Sunspot_Number_t_4": 69.84174131263703,
   "Total_Sunspot_Number_t_3": 263.59876197355857,
   "Total_Sunspot_Number_t_2": 330.7187253293258,
   "Total_Sunspot_Number_t_1": 51.825343050625726
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 68.69797712898385,
   "Total_Sunspot_Number_t_4": 73.88463407396004,
   "Total_Sunspot_Number_t_3": 24.304151050579524,
   "Total_Sunspot_Number_t_2": 346.69510226886746,
   "Total_Sunspot_Number_t_1": 53.13933476794283
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 341.6305901228605,
   "Total_Sunspot_Number_t_4": 273.0798017874087,
   "Total_Sunspot_Number_t_3": 142.94382935234825,
   "Total_Sunspot_Number_t_2": 219.14593188471497,
   "Total_Sunspot_Number_t_1": 132.82221507043502
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 407.2,
   "Total_Sunspot_Number_t_4": 215.1045757086921,
   "Total_Sunspot_Number_t_3": 406.2,
   "Total_Sunspot_Number_t_2": 320.47431428320874,
   "Total_Sunspot_Number_t_1": 405.2
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 402.2,
   "Total_Sunspot_Number_t_4": 92.32876443594938,
   "Total_Sunspot_Number_t_3": 404.2,
   "Total_Sunspot_Number_t_2": 71.54094249963053,
   "Total_Sunspot_Number_t_1": 235.8343195447333
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_13": 213.96184926365675,
   "Total_Sunspot_Number_t_4": 401.2,
   "Total_Sunspot_Number_t_3": 71.40843010602168,
   "Total_Sunspot_Number_t_2": 405.2,
   "Total_Sunspot_Number_t_1": 217.80908304064383
}'
echo -e ""
