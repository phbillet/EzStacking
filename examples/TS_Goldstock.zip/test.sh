echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1834.0059635103225,
   "Close_t_1": 2040.6002425839888,
   "Open_t_1": 1271.6787488290756,
   "High_t_1": 1111.6386103744865,
   "Low_t_1": 1945.6490336294123
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1319.7315237509667,
   "Close_t_1": 1875.5780084559133,
   "Open_t_1": 1780.0700068413964,
   "High_t_1": 1260.3116011264433,
   "Low_t_1": 1330.2762241774067
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1672.8842971598006,
   "Close_t_1": 1121.4270819473418,
   "Open_t_1": 1331.7579798798088,
   "High_t_1": 1532.7716120155155,
   "Low_t_1": 1733.880506667066
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1155.8487131322458,
   "Close_t_1": 1684.3462656434172,
   "Open_t_1": 1683.410555054922,
   "High_t_1": 1884.1299604319443,
   "Low_t_1": 1502.9317127826412
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1732.62941167566,
   "Close_t_1": 1657.911774912251,
   "Open_t_1": 1056.0050765566086,
   "High_t_1": 2075.8810395623914,
   "Low_t_1": 2018.3021747287212
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1133.5567711121266,
   "Close_t_1": 1273.7579998547872,
   "Open_t_1": 1628.6879149859774,
   "High_t_1": 1876.25749280967,
   "Low_t_1": 1051.9996665222366
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1332.6859765894123,
   "Close_t_1": 1884.907768612754,
   "Open_t_1": 1917.5015977698713,
   "High_t_1": 2026.4809092006271,
   "Low_t_1": 1538.2364530545028
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1617.688983699175,
   "Close_t_1": 1271.0853017453287,
   "Open_t_1": 1841.0674604385938,
   "High_t_1": 1341.212459703678,
   "Low_t_1": 1484.2894926118304
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1634.2878537458853,
   "Close_t_1": 1543.217771002068,
   "Open_t_1": 2076.3795872996798,
   "High_t_1": 1270.9497151993355,
   "Low_t_1": 1346.5164853422398
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1117.1173310592035,
   "Close_t_1": 2007.6691188378732,
   "Open_t_1": 1716.8657201088631,
   "High_t_1": 1736.6410387459266,
   "Low_t_1": 1554.6611108441907
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 2104.2,
   "Close_t_1": 1460.56980750477,
   "Open_t_1": 2096.4,
   "High_t_1": 1371.2309150501721,
   "Low_t_1": 1340.7878192339854
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 2108.2,
   "Close_t_1": 1934.7230680877265,
   "Open_t_1": 1160.8196724493937,
   "High_t_1": 2100.2,
   "Low_t_1": 1310.3581061563232
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 2100.2,
   "Close_t_1": 1394.7602726027671,
   "Open_t_1": 2101.4,
   "High_t_1": 2103.2,
   "Low_t_1": 2076.6
}'
echo -e ""
