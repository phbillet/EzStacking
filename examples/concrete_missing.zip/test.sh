echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 508.53543642874826,
   "BlastFurnaceSlag": 144.65766013911258,
   "Water": 141.6598042594475,
   "Superplasticizer": 21.908359464817345,
   "Age": 116.18746679613302
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 180.02478126412512,
   "BlastFurnaceSlag": 32.43319983444722,
   "Water": 162.35081640372556,
   "Superplasticizer": 5.971304413127482,
   "Age": 180.73012107221626
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 226.73952510285275,
   "BlastFurnaceSlag": 27.56977258122868,
   "Water": 215.81823706168746,
   "Superplasticizer": 13.884301650660014,
   "Age": 175.99462576865375
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 515.6816139742081,
   "BlastFurnaceSlag": 26.15768739055683,
   "Water": 150.67024788698626,
   "Superplasticizer": 4.3302742531320595,
   "Age": 265.7006358855449
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 533.0165531325122,
   "BlastFurnaceSlag": 247.08245161663262,
   "Water": 167.39521966337168,
   "Superplasticizer": 20.78333632238724,
   "Age": 123.32888913344354
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 247.77143711993548,
   "BlastFurnaceSlag": 84.38613073323982,
   "Water": 214.34991837877047,
   "Superplasticizer": 14.613829791510211,
   "Age": 156.8747879407175
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 458.44999962893115,
   "BlastFurnaceSlag": 94.05143329050888,
   "Water": 196.0940492011781,
   "Superplasticizer": 13.756488828673321,
   "Age": 298.3296919958926
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 365.22859579177157,
   "BlastFurnaceSlag": 283.0103698103318,
   "Water": 235.82614007959404,
   "Superplasticizer": 1.4639193433378765,
   "Age": 212.60715961708405
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 134.67570582830044,
   "BlastFurnaceSlag": 319.68334564131544,
   "Water": 126.96732745085576,
   "Superplasticizer": 9.017633903093104,
   "Age": 300.95608419066474
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 148.32550573439852,
   "BlastFurnaceSlag": 218.5355960794758,
   "Water": 236.2621313506331,
   "Superplasticizer": 12.329567402906779,
   "Age": 105.41959365735124
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 328.37242104130974,
   "BlastFurnaceSlag": 261.63194045428656,
   "Water": 176.7299877368451,
   "Superplasticizer": 5.705042727448654,
   "Age": 351.05327348099905
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 367.0352367718752,
   "BlastFurnaceSlag": 360.4,
   "Water": 205.6214273785245,
   "Superplasticizer": 34.2,
   "Age": 27.521772610223397
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 549.0,
   "BlastFurnaceSlag": 183.75775946440115,
   "Water": 247.0,
   "Superplasticizer": 37.2,
   "Age": 374
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 175.65409073242057,
   "BlastFurnaceSlag": 361.4,
   "Water": 255.0,
   "Superplasticizer": 42.2,
   "Age": 375
}'
echo -e ""
