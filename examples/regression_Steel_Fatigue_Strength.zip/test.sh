echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 51.582647688686535,
   "TT": 117.01661621996651,
   "C": 0.4381356467494728,
   "Cr": 0.5218783436208211
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 324.47686145335797,
   "TT": 337.1315176054437,
   "C": 0.5670930882996146,
   "Cr": 0.7373465652953168
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 524.466629729015,
   "TT": 509.4887108748081,
   "C": 0.3470527828960036,
   "Cr": 1.0954784467558114
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 472.20466583913947,
   "TT": 591.032575611676,
   "C": 0.27063427259713,
   "Cr": 0.23516882624766283
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 96.70878347965964,
   "TT": 68.72311873505262,
   "C": 0.27411803162213205,
   "Cr": 0.21118314471111413
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 410.30772583633444,
   "TT": 182.16053328464537,
   "C": 0.34250983752278813,
   "Cr": 1.0780222658251728
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 298.86763325992564,
   "TT": 72.97247216518292,
   "C": 0.4127221322550243,
   "Cr": 0.437045718017384
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 499.19321188481996,
   "TT": 441.87848448696934,
   "C": 0.3607121137651722,
   "Cr": 0.5396198919471807
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 112.5187002258254,
   "TT": 391.07659186474734,
   "C": 0.17518843823048652,
   "Cr": 0.016671949882352818
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 246.19130379413468,
   "TT": 415.77649683735706,
   "C": 0.5121805964693926,
   "Cr": 0.5178529079565941
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 402.2186390970487,
   "TT": 681,
   "C": 3.63,
   "Cr": 0.5699590335154847
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 543.0,
   "TT": 276.2667560750515,
   "C": 1.63,
   "Cr": 0.2722065183442389
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 550.0,
   "TT": 689,
   "C": 0.2854180473741715,
   "Cr": 8.17
}'
echo -e ""
