echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.828939430673508,
   "sepal_width": 3.896055454034763,
   "petal_length": 2.4297315651530096,
   "petal_width": 0.8912905676934981
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.516886909185254,
   "sepal_width": 2.022798205375717,
   "petal_length": 4.932224183277807,
   "petal_width": 0.7094941018055686
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.191719682529297,
   "sepal_width": 2.016888913352578,
   "petal_length": 1.534664158641175,
   "petal_width": 1.6140552467255616
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.600176144549568,
   "sepal_width": 3.223538520448344,
   "petal_length": 5.053183489572828,
   "petal_width": 2.180115708947329
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.033795355342274,
   "sepal_width": 2.1831445619163805,
   "petal_length": 4.256725159286992,
   "petal_width": 1.223943787907756
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.5064263227885295,
   "sepal_width": 2.4308576236004154,
   "petal_length": 4.1491416283905345,
   "petal_width": 0.915129403024395
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.002372755409523,
   "sepal_width": 3.161793927055637,
   "petal_length": 1.2811918058764276,
   "petal_width": 0.5240077330872251
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.798053839500304,
   "sepal_width": 3.4370487340906464,
   "petal_length": 3.196977531065247,
   "petal_width": 1.2621218707632988
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.304612506295339,
   "sepal_width": 3.3741326491085033,
   "petal_length": 6.436839299714298,
   "petal_width": 0.6147887833634079
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.575945867839238,
   "sepal_width": 3.4766808409742493,
   "petal_length": 2.5122697759099473,
   "petal_width": 0.7369538559637319
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.728868113908751,
   "sepal_width": 3.494180899028545,
   "petal_length": 6.606688372290961,
   "petal_width": 0.7416422250061483
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.1026648261528855,
   "sepal_width": 3.096632754015686,
   "petal_length": 6.6365818133225085,
   "petal_width": 2.471741834954236
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.009826102771867,
   "sepal_width": 2.2844561350684,
   "petal_length": 1.6213454860554934,
   "petal_width": 0.7551348151208155
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.648967808069083,
   "sepal_width": 2.864367200984792,
   "petal_length": 6.224910326547317,
   "petal_width": 1.5084552984439825
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.147886209413896,
   "sepal_width": 3.1718211503931126,
   "petal_length": 5.16493583424439,
   "petal_width": 0.7118225714858305
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.1956010855476515,
   "sepal_width": 2.853838166468724,
   "petal_length": 4.823221428542997,
   "petal_width": 2.4804556088110044
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.531470675232732,
   "sepal_width": 4.017684855495682,
   "petal_length": 3.038449173075952,
   "petal_width": 1.3994386510620782
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.221673583230421,
   "sepal_width": 2.29344748625541,
   "petal_length": 5.423688421474933,
   "petal_width": 2.2878037072490036
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.61391564911917,
   "sepal_width": 3.5769367453180516,
   "petal_length": 1.4622336727253034,
   "petal_width": 1.866313850558514
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.221441685704575,
   "sepal_width": 2.303051629754649,
   "petal_length": 2.0423621858198873,
   "petal_width": 2.4777743501511034
}'
echo -e ""
echo -e "Test OK: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.905959300356191,
   "sepal_width": 2.8706260994722577,
   "petal_length": 4.682943754335806,
   "petal_width": 0.7211602597098521
}'
echo -e ""
echo -e "Test OK: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.552448461543921,
   "sepal_width": 3.577539434062436,
   "petal_length": 4.7269822004330155,
   "petal_width": 1.4514369866231913
}'
echo -e ""
echo -e "Test OK: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.6838012516801815,
   "sepal_width": 3.7493251177100566,
   "petal_length": 2.8205157643340444,
   "petal_width": 1.9640538619753791
}'
echo -e ""
echo -e "Test OK: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.373999251087866,
   "sepal_width": 2.3653106783990374,
   "petal_length": 3.6034565341717446,
   "petal_width": 0.48115692993827
}'
echo -e ""
echo -e "Test OK: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.835992941832472,
   "sepal_width": 2.203120456535077,
   "petal_length": 3.9944622033053356,
   "petal_width": 1.573701605743959
}'
echo -e ""
echo -e "Test OK: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.189996816980485,
   "sepal_width": 3.233940942854638,
   "petal_length": 2.039113267291293,
   "petal_width": 1.9902500491538484
}'
echo -e ""
echo -e "Test OK: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.082025680438312,
   "sepal_width": 2.5143100768806175,
   "petal_length": 5.590763119751731,
   "petal_width": 1.2661787972390768
}'
echo -e ""
echo -e "Test OK: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.501905839192762,
   "sepal_width": 2.2372854127020387,
   "petal_length": 6.796568307421166,
   "petal_width": 2.071417615933376
}'
echo -e ""
echo -e "Test OK: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.812862554253604,
   "sepal_width": 2.2810055699922045,
   "petal_length": 3.6539138681199317,
   "petal_width": 1.7332075611017277
}'
echo -e ""
echo -e "Test OK: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.987105086472185,
   "sepal_width": 4.020444009843251,
   "petal_length": 2.18190708431523,
   "petal_width": 2.1116378219814447
}'
echo -e ""
echo -e "Test OK: 30"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.915618162626787,
   "sepal_width": 3.1651598902407785,
   "petal_length": 2.3203225095056976,
   "petal_width": 2.218392801344329
}'
echo -e ""
echo -e "Test OK: 31"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.049556301490814,
   "sepal_width": 2.2969792279861503,
   "petal_length": 3.860634200391099,
   "petal_width": 0.9704672805516363
}'
echo -e ""
echo -e "Test OK: 32"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.4722496427509935,
   "sepal_width": 3.5111019101220133,
   "petal_length": 6.490087204147552,
   "petal_width": 2.3627232910685483
}'
echo -e ""
echo -e "Test OK: 33"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.450655071509337,
   "sepal_width": 4.251394382382757,
   "petal_length": 6.031168983697659,
   "petal_width": 0.757188421714803
}'
echo -e ""
echo -e "Test OK: 34"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.7565164125945465,
   "sepal_width": 4.055006941576055,
   "petal_length": 1.413145850838142,
   "petal_width": 0.6918236110153885
}'
echo -e ""
echo -e "Test OK: 35"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.860896203598587,
   "sepal_width": 2.004054734036595,
   "petal_length": 5.786233802097897,
   "petal_width": 1.1856045590736548
}'
echo -e ""
echo -e "Test OK: 36"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.915207562540583,
   "sepal_width": 2.5609250691549024,
   "petal_length": 6.132773420540775,
   "petal_width": 0.7351228678549329
}'
echo -e ""
echo -e "Test OK: 37"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.395573884039786,
   "sepal_width": 3.235618884691635,
   "petal_length": 2.8841626957509323,
   "petal_width": 0.3326916342616375
}'
echo -e ""
echo -e "Test OK: 38"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.071917674310117,
   "sepal_width": 2.8650577541438285,
   "petal_length": 3.3219026070092426,
   "petal_width": 1.9289259079442629
}'
echo -e ""
echo -e "Test OK: 39"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.19026239879049,
   "sepal_width": 4.379189236437037,
   "petal_length": 4.819665373151079,
   "petal_width": 2.4102431049176327
}'
echo -e ""
echo -e "Test OK: 40"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.995563337552548,
   "sepal_width": 3.38613263338559,
   "petal_length": 3.195917997678362,
   "petal_width": 2.269850343777176
}'
echo -e ""
echo -e "Test OK: 41"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.794968276689326,
   "sepal_width": 3.56500198002915,
   "petal_length": 6.587113857594497,
   "petal_width": 0.8674076388942358
}'
echo -e ""
echo -e "Test OK: 42"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.166797533337851,
   "sepal_width": 3.2487982532466604,
   "petal_length": 3.095830361162175,
   "petal_width": 2.3866899483130912
}'
echo -e ""
echo -e "Test OK: 43"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.523121689195363,
   "sepal_width": 3.445279336855968,
   "petal_length": 4.005344135967768,
   "petal_width": 1.7741892480226977
}'
echo -e ""
echo -e "Test OK: 44"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.7587094014948494,
   "sepal_width": 2.235777524758394,
   "petal_length": 5.444184993292325,
   "petal_width": 1.3305819356847428
}'
echo -e ""
echo -e "Test OK: 45"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.845554389277996,
   "sepal_width": 2.584111684261318,
   "petal_length": 2.907532981629093,
   "petal_width": 0.14742582198486326
}'
echo -e ""
echo -e "Test OK: 46"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.284819090508597,
   "sepal_width": 2.360789328851228,
   "petal_length": 5.815734223282244,
   "petal_width": 0.8089024749418348
}'
echo -e ""
echo -e "Test OK: 47"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.21341075796302,
   "sepal_width": 2.247547372676606,
   "petal_length": 2.0295172099552534,
   "petal_width": 2.446679683357748
}'
echo -e ""
echo -e "Test OK: 48"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.650916979287748,
   "sepal_width": 4.219765858946138,
   "petal_length": 2.696303458630748,
   "petal_width": 0.16974813049947093
}'
echo -e ""
echo -e "Test OK: 49"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.393895648413654,
   "sepal_width": 3.415113403795938,
   "petal_length": 6.547998123737122,
   "petal_width": 0.8416592077596962
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.736061264672182,
   "sepal_width": 14.4,
   "petal_length": 1.0788027812513812,
   "petal_width": 6.5
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.827156267574403,
   "sepal_width": 3.3494778523259083,
   "petal_length": 13.9,
   "petal_width": 0.43480302543418814
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 13.9,
   "sepal_width": 3.0646353920776526,
   "petal_length": 8.9,
   "petal_width": 0.4959117760869005
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 11.9,
   "sepal_width": 3.4834411659947957,
   "petal_length": 9.9,
   "petal_width": 2.4281041669131107
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.000916932550566,
   "sepal_width": 4.4,
   "petal_length": 3.4091171466900136,
   "petal_width": 0.8798836495567603
}'
echo -e ""
echo -e "Test KO: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 14.9,
   "sepal_width": 12.4,
   "petal_length": 10.9,
   "petal_width": 2.5
}'
echo -e ""
echo -e "Test KO: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 9.9,
   "sepal_width": 4.4,
   "petal_length": 2.774862192781095,
   "petal_width": 6.5
}'
echo -e ""
echo -e "Test KO: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 17.9,
   "sepal_width": 14.4,
   "petal_length": 10.9,
   "petal_width": 2.5
}'
echo -e ""
echo -e "Test KO: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.638352024648462,
   "sepal_width": 9.4,
   "petal_length": 6.85647121066123,
   "petal_width": 3.5
}'
echo -e ""
echo -e "Test KO: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.556683968581407,
   "sepal_width": 3.9627697883687807,
   "petal_length": 16.9,
   "petal_width": 0.9677795479595706
}'
echo -e ""
echo -e "Test KO: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.531496329044186,
   "sepal_width": 12.4,
   "petal_length": 2.7243878390040566,
   "petal_width": 4.5
}'
echo -e ""
echo -e "Test KO: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 15.9,
   "sepal_width": 2.390264430736789,
   "petal_length": 14.9,
   "petal_width": 0.9969859393914979
}'
echo -e ""
echo -e "Test KO: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.480552212205806,
   "sepal_width": 7.4,
   "petal_length": 6.075133149832833,
   "petal_width": 2.490029325967078
}'
echo -e ""
echo -e "Test KO: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 17.9,
   "sepal_width": 3.9096081124183413,
   "petal_length": 1.767112571370804,
   "petal_width": 1.0328925888477278
}'
echo -e ""
echo -e "Test KO: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 12.9,
   "sepal_width": 2.7989210614118636,
   "petal_length": 13.9,
   "petal_width": 10.5
}'
echo -e ""
echo -e "Test KO: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 16.9,
   "sepal_width": 11.4,
   "petal_length": 5.3856813882069,
   "petal_width": 6.5
}'
echo -e ""
echo -e "Test KO: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.462686555791496,
   "sepal_width": 7.4,
   "petal_length": 5.567067626470342,
   "petal_width": 4.5
}'
echo -e ""
echo -e "Test KO: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 15.9,
   "sepal_width": 3.408558172351901,
   "petal_length": 8.9,
   "petal_width": 0.8703746133486707
}'
echo -e ""
echo -e "Test KO: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.138474302049527,
   "sepal_width": 9.4,
   "petal_length": 4.783882408767387,
   "petal_width": 9.5
}'
echo -e ""
echo -e "Test KO: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 15.9,
   "sepal_width": 2.1013929648924905,
   "petal_length": 7.9,
   "petal_width": 1.6810706521303096
}'
echo -e ""
echo -e "Test KO: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 11.9,
   "sepal_width": 2.5251762696147724,
   "petal_length": 7.9,
   "petal_width": 2.3894094582219387
}'
echo -e ""
echo -e "Test KO: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.439091634939264,
   "sepal_width": 7.4,
   "petal_length": 5.162407812861192,
   "petal_width": 7.5
}'
echo -e ""
echo -e "Test KO: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 16.9,
   "sepal_width": 3.354261242568276,
   "petal_length": 16.9,
   "petal_width": 2.476825092950968
}'
echo -e ""
echo -e "Test KO: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.104258539890948,
   "sepal_width": 10.4,
   "petal_length": 4.048102683147858,
   "petal_width": 1.877783665456497
}'
echo -e ""
echo -e "Test KO: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.024736001649827,
   "sepal_width": 2.172912895117688,
   "petal_length": 9.9,
   "petal_width": 2.036788936723722
}'
echo -e ""
echo -e "Test KO: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 12.9,
   "sepal_width": 2.2650466948601617,
   "petal_length": 14.9,
   "petal_width": 0.4476585423316728
}'
echo -e ""
echo -e "Test KO: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 14.9,
   "sepal_width": 3.6929857771236074,
   "petal_length": 15.9,
   "petal_width": 9.5
}'
echo -e ""
echo -e "Test KO: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.403522661104376,
   "sepal_width": 14.4,
   "petal_length": 6.0663189884498525,
   "petal_width": 4.5
}'
echo -e ""
echo -e "Test KO: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.770346760502093,
   "sepal_width": 3.4226270428983243,
   "petal_length": 2.2905577874176046,
   "petal_width": 3.5
}'
echo -e ""
echo -e "Test KO: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 9.9,
   "sepal_width": 3.0902424048186146,
   "petal_length": 12.9,
   "petal_width": 2.1579817155749725
}'
echo -e ""
echo -e "Test KO: 30"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 11.9,
   "sepal_width": 3.0601161928357214,
   "petal_length": 11.9,
   "petal_width": 1.1897784422728643
}'
echo -e ""
echo -e "Test KO: 31"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 8.9,
   "sepal_width": 9.4,
   "petal_length": 6.163556270152091,
   "petal_width": 10.5
}'
echo -e ""
echo -e "Test KO: 32"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 16.9,
   "sepal_width": 7.4,
   "petal_length": 1.529308982189783,
   "petal_width": 2.2496388083082843
}'
echo -e ""
echo -e "Test KO: 33"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 10.9,
   "sepal_width": 2.6179902138562783,
   "petal_length": 6.8553362168272685,
   "petal_width": 4.5
}'
echo -e ""
echo -e "Test KO: 34"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 9.9,
   "sepal_width": 2.389215826153447,
   "petal_length": 6.852705580057573,
   "petal_width": 1.5150431080565998
}'
echo -e ""
echo -e "Test KO: 35"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.6934656272699655,
   "sepal_width": 14.4,
   "petal_length": 14.9,
   "petal_width": 2.0520978386182294
}'
echo -e ""
echo -e "Test KO: 36"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.9,
   "sepal_width": 4.134229672200016,
   "petal_length": 16.9,
   "petal_width": 9.5
}'
echo -e ""
echo -e "Test KO: 37"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.446911984951848,
   "sepal_width": 10.4,
   "petal_length": 6.174775852246484,
   "petal_width": 10.5
}'
echo -e ""
echo -e "Test KO: 38"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.9,
   "sepal_width": 2.0269824643600747,
   "petal_length": 6.560565716704317,
   "petal_width": 11.5
}'
echo -e ""
echo -e "Test KO: 39"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 15.9,
   "sepal_width": 3.931305118569351,
   "petal_length": 7.9,
   "petal_width": 0.4036255564902069
}'
echo -e ""
echo -e "Test KO: 40"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.824993629849404,
   "sepal_width": 11.4,
   "petal_length": 14.9,
   "petal_width": 1.2364753313969976
}'
echo -e ""
echo -e "Test KO: 41"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 12.9,
   "sepal_width": 13.4,
   "petal_length": 1.4271877137164932,
   "petal_width": 1.1938184700889247
}'
echo -e ""
echo -e "Test KO: 42"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 17.9,
   "sepal_width": 3.8596672263893694,
   "petal_length": 12.9,
   "petal_width": 1.8716041180394518
}'
echo -e ""
echo -e "Test KO: 43"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.523975138841907,
   "sepal_width": 11.4,
   "petal_length": 3.7491650603951503,
   "petal_width": 12.5
}'
echo -e ""
echo -e "Test KO: 44"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.9890265707568435,
   "sepal_width": 2.735673282263769,
   "petal_length": 16.9,
   "petal_width": 11.5
}'
echo -e ""
echo -e "Test KO: 45"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 15.9,
   "sepal_width": 2.1101733039251642,
   "petal_length": 9.9,
   "petal_width": 7.5
}'
echo -e ""
echo -e "Test KO: 46"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 10.9,
   "sepal_width": 9.4,
   "petal_length": 15.9,
   "petal_width": 0.9336324248237317
}'
echo -e ""
echo -e "Test KO: 47"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 16.9,
   "sepal_width": 4.074158976464474,
   "petal_length": 15.9,
   "petal_width": 12.5
}'
echo -e ""
echo -e "Test KO: 48"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.26864127307819,
   "sepal_width": 3.4149209207599034,
   "petal_length": 16.9,
   "petal_width": 2.3703946389581074
}'
echo -e ""
echo -e "Test KO: 49"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 17.9,
   "sepal_width": 12.4,
   "petal_length": 2.7073440602108256,
   "petal_width": 8.5
}'
echo -e ""
