echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 255198.738156963,
   "MGR_ID": 37713.60366365559,
   "ROLE_ROLLUP_1": 89213.0004184052,
   "ROLE_ROLLUP_2": 83649.84360488586,
   "ROLE_DEPTNAME": 175748.70105636082,
   "ROLE_TITLE": 225072.58434111733,
   "ROLE_FAMILY_DESC": 150213.5564604275,
   "ROLE_FAMILY": 296822.6698675299,
   "ROLE_CODE": 184998.799917781
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 236407.3793790352,
   "MGR_ID": 45183.93068831262,
   "ROLE_ROLLUP_1": 212053.01892234484,
   "ROLE_ROLLUP_2": 56745.81027046302,
   "ROLE_DEPTNAME": 186824.24111612505,
   "ROLE_TITLE": 292870.61159196583,
   "ROLE_FAMILY_DESC": 105630.12383297566,
   "ROLE_FAMILY": 180508.9536675413,
   "ROLE_CODE": 152343.43963659887
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 6481.241048721164,
   "MGR_ID": 3419.0410970246635,
   "ROLE_ROLLUP_1": 211633.09630579263,
   "ROLE_ROLLUP_2": 174794.49906609516,
   "ROLE_DEPTNAME": 157248.68917895848,
   "ROLE_TITLE": 236854.12332658924,
   "ROLE_FAMILY_DESC": 9053.351319745303,
   "ROLE_FAMILY": 293926.73630364594,
   "ROLE_CODE": 157624.8780281091
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 284080.89695007034,
   "MGR_ID": 130398.61326178681,
   "ROLE_ROLLUP_1": 55191.25775805804,
   "ROLE_ROLLUP_2": 54631.89459224311,
   "ROLE_DEPTNAME": 60202.31305912547,
   "ROLE_TITLE": 117996.63161391777,
   "ROLE_FAMILY_DESC": 209290.83553827053,
   "ROLE_FAMILY": 187469.56693841013,
   "ROLE_CODE": 130921.66531830504
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 175316.08544402322,
   "MGR_ID": 17339.21607296113,
   "ROLE_ROLLUP_1": 261789.24027950485,
   "ROLE_ROLLUP_2": 233577.35863557394,
   "ROLE_DEPTNAME": 238350.02450533575,
   "ROLE_TITLE": 120533.54074718556,
   "ROLE_FAMILY_DESC": 80898.58433573003,
   "ROLE_FAMILY": 207537.15290393503,
   "ROLE_CODE": 125626.82850419289
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 187781.68018617394,
   "MGR_ID": 33238.133171784466,
   "ROLE_ROLLUP_1": 96393.89675143808,
   "ROLE_ROLLUP_2": 64247.25459120076,
   "ROLE_DEPTNAME": 244297.44059996324,
   "ROLE_TITLE": 293821.2031375073,
   "ROLE_FAMILY_DESC": 198391.93064690323,
   "ROLE_FAMILY": 133909.7083586905,
   "ROLE_CODE": 165568.16829901363
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 11860.466583062282,
   "MGR_ID": 25334.313184284198,
   "ROLE_ROLLUP_1": 191071.5799616043,
   "ROLE_ROLLUP_2": 156534.83622694423,
   "ROLE_DEPTNAME": 47170.29852130041,
   "ROLE_TITLE": 299330.4884258574,
   "ROLE_FAMILY_DESC": 288204.61738085275,
   "ROLE_FAMILY": 166336.53040624878,
   "ROLE_CODE": 174924.7770510848
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 80673.52125583941,
   "MGR_ID": 278776.81218944455,
   "ROLE_ROLLUP_1": 198931.96748677356,
   "ROLE_ROLLUP_2": 65709.00983396165,
   "ROLE_DEPTNAME": 146922.56000689557,
   "ROLE_TITLE": 222851.37966283353,
   "ROLE_FAMILY_DESC": 91147.85920915786,
   "ROLE_FAMILY": 188701.20590648634,
   "ROLE_CODE": 200213.62963948224
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 30503.98601498449,
   "MGR_ID": 104181.13898248858,
   "ROLE_ROLLUP_1": 125570.56232999789,
   "ROLE_ROLLUP_2": 159059.89065807595,
   "ROLE_DEPTNAME": 34837.25200711416,
   "ROLE_TITLE": 240008.74146092753,
   "ROLE_FAMILY_DESC": 269459.8689745655,
   "ROLE_FAMILY": 214162.56481309954,
   "ROLE_CODE": 134771.25697132936
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 78198.40308052921,
   "MGR_ID": 262169.7589940159,
   "ROLE_ROLLUP_1": 281106.4937637821,
   "ROLE_ROLLUP_2": 213475.2934316903,
   "ROLE_DEPTNAME": 231938.21014980128,
   "ROLE_TITLE": 180877.66659480138,
   "ROLE_FAMILY_DESC": 184121.31715018404,
   "ROLE_FAMILY": 101561.9651334419,
   "ROLE_CODE": 121101.83757042041
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 17190.108473669978,
   "MGR_ID": 162501.8083980461,
   "ROLE_ROLLUP_1": 311183,
   "ROLE_ROLLUP_2": 116036.622804592,
   "ROLE_DEPTNAME": 286794,
   "ROLE_TITLE": 311870,
   "ROLE_FAMILY_DESC": 310847.0960623077,
   "ROLE_FAMILY": 308581,
   "ROLE_CODE": 119043.56150949947
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 312155,
   "MGR_ID": 159400.9269963204,
   "ROLE_ROLLUP_1": 311181,
   "ROLE_ROLLUP_2": 116693.7639911134,
   "ROLE_DEPTNAME": 286799,
   "ROLE_TITLE": 186414.54167416366,
   "ROLE_FAMILY_DESC": 311870,
   "ROLE_FAMILY": 81819.44686083027,
   "ROLE_CODE": 151637.17531510635
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 312160,
   "MGR_ID": 274679.50726239523,
   "ROLE_ROLLUP_1": 311186,
   "ROLE_ROLLUP_2": 107251.14946842837,
   "ROLE_DEPTNAME": 286799,
   "ROLE_TITLE": 244780.5576645605,
   "ROLE_FAMILY_DESC": 125364.80528085041,
   "ROLE_FAMILY": 308577,
   "ROLE_CODE": 200923.13559839842
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 312155,
   "MGR_ID": 289814.7174528607,
   "ROLE_ROLLUP_1": 311179,
   "ROLE_ROLLUP_2": 286800,
   "ROLE_DEPTNAME": 191342.55731357788,
   "ROLE_TITLE": 311871,
   "ROLE_FAMILY_DESC": 112418.24727231199,
   "ROLE_FAMILY": 308575,
   "ROLE_CODE": 120932.98646233288
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 81461.62687391214,
   "MGR_ID": 311696,
   "ROLE_ROLLUP_1": 237352.9770362038,
   "ROLE_ROLLUP_2": 286801,
   "ROLE_DEPTNAME": 273371.1719192059,
   "ROLE_TITLE": 311867,
   "ROLE_FAMILY_DESC": 92113.86222670885,
   "ROLE_FAMILY": 308584,
   "ROLE_CODE": 270697
}'
echo -e ""
echo -e "Test KO: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 312163,
   "MGR_ID": 306600.7703089305,
   "ROLE_ROLLUP_1": 154511.19002750757,
   "ROLE_ROLLUP_2": 132598.68609356158,
   "ROLE_DEPTNAME": 70079.22496146304,
   "ROLE_TITLE": 311872,
   "ROLE_FAMILY_DESC": 115617.8009845456,
   "ROLE_FAMILY": 308583,
   "ROLE_CODE": 270695
}'
echo -e ""
echo -e "Test KO: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 32127.00950342279,
   "MGR_ID": 39427.564768404685,
   "ROLE_ROLLUP_1": 311188,
   "ROLE_ROLLUP_2": 32719.456390377898,
   "ROLE_DEPTNAME": 286793,
   "ROLE_TITLE": 260096.00740067541,
   "ROLE_FAMILY_DESC": 311872,
   "ROLE_FAMILY": 62004.148945432134,
   "ROLE_CODE": 270700
}'
echo -e ""
echo -e "Test KO: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 301501.8433945043,
   "MGR_ID": 311703,
   "ROLE_ROLLUP_1": 259316.51380157494,
   "ROLE_ROLLUP_2": 180755.92118920237,
   "ROLE_DEPTNAME": 286800,
   "ROLE_TITLE": 268165.64137717674,
   "ROLE_FAMILY_DESC": 311871,
   "ROLE_FAMILY": 101328.25826993109,
   "ROLE_CODE": 270698
}'
echo -e ""
echo -e "Test KO: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 188862.08447008076,
   "MGR_ID": 311698,
   "ROLE_ROLLUP_1": 141436.73586623574,
   "ROLE_ROLLUP_2": 269212.33850892127,
   "ROLE_DEPTNAME": 286797,
   "ROLE_TITLE": 134278.13095275813,
   "ROLE_FAMILY_DESC": 45066.7488675217,
   "ROLE_FAMILY": 271382.27366622287,
   "ROLE_CODE": 270692
}'
echo -e ""
echo -e "Test KO: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 312162,
   "MGR_ID": 311705,
   "ROLE_ROLLUP_1": 112800.60270353242,
   "ROLE_ROLLUP_2": 286798,
   "ROLE_DEPTNAME": 255538.0025167997,
   "ROLE_TITLE": 311877,
   "ROLE_FAMILY_DESC": 5495.187825317702,
   "ROLE_FAMILY": 308584,
   "ROLE_CODE": 216471.80854601125
}'
echo -e ""
