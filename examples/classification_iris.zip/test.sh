echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.87443505629305,
   "sepal_width": 2.778691772540018,
   "petal_length": 3.0584913719008715,
   "petal_width": 2.004737624123596
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.520971562405492,
   "sepal_width": 3.4297920798264094,
   "petal_length": 5.874854314886578,
   "petal_width": 1.6275563748521338
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.192454731650171,
   "sepal_width": 2.054476943836944,
   "petal_length": 5.136415033690313,
   "petal_width": 1.7095749544090044
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.582472784990401,
   "sepal_width": 3.3157960998066387,
   "petal_length": 1.248955018654185,
   "petal_width": 0.8835676282817579
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.703496545362398,
   "sepal_width": 2.304828884543203,
   "petal_length": 1.9970948029507811,
   "petal_width": 2.486541216374775
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.3378445079499,
   "sepal_width": 2.4972391005385,
   "petal_length": 5.66451578072512,
   "petal_width": 1.4761231209882557
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.607426838178069,
   "sepal_width": 3.644687289189445,
   "petal_length": 6.121615945526553,
   "petal_width": 0.25226829261387707
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.194660790905413,
   "sepal_width": 2.3199748655561594,
   "petal_length": 5.350851379958995,
   "petal_width": 1.656995952086632
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.573088115285671,
   "sepal_width": 2.974993275623566,
   "petal_length": 3.2403314514134265,
   "petal_width": 2.0297607505381845
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.023484028653739,
   "sepal_width": 3.4819196494595106,
   "petal_length": 6.215198139548824,
   "petal_width": 0.3575022769645806
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.870686250259918,
   "sepal_width": 2.567398011313294,
   "petal_length": 7.9,
   "petal_width": 1.7697766812144242
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 12.9,
   "sepal_width": 2.6264827389003536,
   "petal_length": 3.289162863926439,
   "petal_width": 1.1590672167042715
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.367990644708247,
   "sepal_width": 2.245393183902883,
   "petal_length": 12.9,
   "petal_width": 0.48248157674416425
}'
echo -e ""
