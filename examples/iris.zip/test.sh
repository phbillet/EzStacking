echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.149480378898328,
   "sepal_width": 2.5049373790670737,
   "petal_length": 5.187368729382598,
   "petal_width": 0.347605121784477
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.566253213183886,
   "sepal_width": 3.598409335596866,
   "petal_length": 5.97253312191874,
   "petal_width": 1.744303213328342
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.318726429159448,
   "sepal_width": 2.8981657349772547,
   "petal_length": 6.445947538267054,
   "petal_width": 1.5091693742838526
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 15.9,
   "sepal_width": 11.4,
   "petal_length": 2.7609905137330397,
   "petal_width": 6.5
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 8.9,
   "sepal_width": 3.997835624165188,
   "petal_length": 10.9,
   "petal_width": 8.5
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 10.9,
   "sepal_width": 3.9909000131514603,
   "petal_length": 14.9,
   "petal_width": 2.1968371018537995
}'
echo -e ""
