echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.761694227993962,
   "Number_of_bathrooms": 4.486546746590539,
   "Area": 3240.889560356361,
   "Zipcode": 55823.05584838491
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.459444743222352,
   "Number_of_bathrooms": 3.922923462696583,
   "Area": 6126.346215327523,
   "Zipcode": 56866.57308444828
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.036840030383633,
   "Number_of_bathrooms": 3.5810892617818975,
   "Area": 7668.485138361396,
   "Zipcode": 56053.1380464502
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.280878399990754,
   "Number_of_bathrooms": 6.09245360899516,
   "Area": 719.4286237866729,
   "Zipcode": 74435.57153721293
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.7815675997335436,
   "Number_of_bathrooms": 4.782627832149762,
   "Area": 8194.617109467295,
   "Zipcode": 76758.5946384198
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.56586126636032,
   "Number_of_bathrooms": 6.360483192443443,
   "Area": 6526.373707949282,
   "Zipcode": 43228.168397292204
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.205601207303155,
   "Number_of_bathrooms": 5.756069159639446,
   "Area": 1914.2778801798377,
   "Zipcode": 67736.02038849462
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.545447363926047,
   "Number_of_bathrooms": 3.044896296099587,
   "Area": 3059.613174397036,
   "Zipcode": 71959.43572745238
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.380940413234446,
   "Number_of_bathrooms": 5.286070545070762,
   "Area": 7844.529909304723,
   "Zipcode": 71891.33734020412
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.50190019104852,
   "Number_of_bathrooms": 5.9067506809992745,
   "Area": 7874.444111750142,
   "Zipcode": 94155.98418862864
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.451292582897852,
   "Number_of_bathrooms": 3.520350257570849,
   "Area": 2105.998254219065,
   "Zipcode": 80610.21548292157
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.357698405024257,
   "Number_of_bathrooms": 1.3469244955827826,
   "Area": 1858.7539061105438,
   "Zipcode": 70622.29716658553
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.447194534511504,
   "Number_of_bathrooms": 5.789289974572571,
   "Area": 8334.81722241128,
   "Zipcode": 72295.51654219477
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.4972662788652418,
   "Number_of_bathrooms": 2.461387604360641,
   "Area": 1911.7876373366087,
   "Zipcode": 92987.5833536119
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.580229736791989,
   "Number_of_bathrooms": 6.664299594684732,
   "Area": 776.1004324174379,
   "Zipcode": 83686.07289807175
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.5970727195644843,
   "Number_of_bathrooms": 1.9478871406309926,
   "Area": 4172.496076376536,
   "Zipcode": 94654.6939370443
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.749540838661264,
   "Number_of_bathrooms": 4.435929791818669,
   "Area": 9047.306006233577,
   "Zipcode": 63475.98974380545
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.6457916623008595,
   "Number_of_bathrooms": 6.836720219595177,
   "Area": 1780.0873833312473,
   "Zipcode": 62190.0125969098
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.003029319630208,
   "Number_of_bathrooms": 1.1186891059429631,
   "Area": 8785.41101629951,
   "Zipcode": 55627.73849332439
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.645389448849744,
   "Number_of_bathrooms": 1.1843587568686216,
   "Area": 4246.221637349377,
   "Zipcode": 89540.45326139571
}'
echo -e ""
echo -e "Test OK: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.783692363791566,
   "Number_of_bathrooms": 4.538172915698659,
   "Area": 4777.1429918910935,
   "Zipcode": 93049.18813553717
}'
echo -e ""
echo -e "Test OK: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.981826015495479,
   "Number_of_bathrooms": 6.037150188034774,
   "Area": 6435.48758328805,
   "Zipcode": 89071.2891555689
}'
echo -e ""
echo -e "Test OK: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.4034785034460437,
   "Number_of_bathrooms": 6.267158710842068,
   "Area": 5529.530937312887,
   "Zipcode": 54776.260366671544
}'
echo -e ""
echo -e "Test OK: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.493809635798552,
   "Number_of_bathrooms": 1.9764092691081327,
   "Area": 2251.7898455130344,
   "Zipcode": 78987.6063120898
}'
echo -e ""
echo -e "Test OK: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.4432153960788545,
   "Number_of_bathrooms": 4.417063489134977,
   "Area": 2597.73278674444,
   "Zipcode": 86375.56201570515
}'
echo -e ""
echo -e "Test OK: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.439612785500474,
   "Number_of_bathrooms": 4.614453878264053,
   "Area": 8041.807892578485,
   "Zipcode": 58737.362269476915
}'
echo -e ""
echo -e "Test OK: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.286210943898368,
   "Number_of_bathrooms": 2.0117826436495316,
   "Area": 4766.878747276491,
   "Zipcode": 44608.834001937415
}'
echo -e ""
echo -e "Test OK: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.909230696046826,
   "Number_of_bathrooms": 4.366314251502685,
   "Area": 1812.4423392830472,
   "Zipcode": 44072.33943454776
}'
echo -e ""
echo -e "Test OK: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.6725056849629683,
   "Number_of_bathrooms": 2.3110883462379563,
   "Area": 4350.15300946047,
   "Zipcode": 95473.29751415087
}'
echo -e ""
echo -e "Test OK: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.616653927176452,
   "Number_of_bathrooms": 5.210699478000381,
   "Area": 6820.026282234841,
   "Zipcode": 52791.457878374844
}'
echo -e ""
echo -e "Test OK: 30"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.141970423119053,
   "Number_of_bathrooms": 5.19855895038405,
   "Area": 4213.883403109097,
   "Zipcode": 55496.45671712145
}'
echo -e ""
echo -e "Test OK: 31"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.663856617748807,
   "Number_of_bathrooms": 5.537534298881109,
   "Area": 6032.185745698092,
   "Zipcode": 53611.29205764868
}'
echo -e ""
echo -e "Test OK: 32"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.78707321989007,
   "Number_of_bathrooms": 2.8316076197304394,
   "Area": 1074.6223786087544,
   "Zipcode": 43083.37137529713
}'
echo -e ""
echo -e "Test OK: 33"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.0739908634488775,
   "Number_of_bathrooms": 4.744001898105459,
   "Area": 5893.1145601982225,
   "Zipcode": 62221.58777313212
}'
echo -e ""
echo -e "Test OK: 34"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.893207435417041,
   "Number_of_bathrooms": 4.0374185414889405,
   "Area": 2398.7266768510626,
   "Zipcode": 76522.59485771123
}'
echo -e ""
echo -e "Test OK: 35"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.550836485648128,
   "Number_of_bathrooms": 6.501325778680986,
   "Area": 7830.986104516997,
   "Zipcode": 97622.11367775353
}'
echo -e ""
echo -e "Test OK: 36"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.785553296773543,
   "Number_of_bathrooms": 3.552116807248559,
   "Area": 3223.4166862414268,
   "Zipcode": 80289.88885899907
}'
echo -e ""
echo -e "Test OK: 37"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.5809441968225,
   "Number_of_bathrooms": 5.5284838274843935,
   "Area": 2879.803362588134,
   "Zipcode": 64802.0472735201
}'
echo -e ""
echo -e "Test OK: 38"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.1504000522314515,
   "Number_of_bathrooms": 6.426566271467732,
   "Area": 3027.856394175208,
   "Zipcode": 54207.61604291042
}'
echo -e ""
echo -e "Test OK: 39"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.806633938249274,
   "Number_of_bathrooms": 2.183658802567158,
   "Area": 4127.708166952429,
   "Zipcode": 54143.364095709905
}'
echo -e ""
echo -e "Test OK: 40"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.861917852601378,
   "Number_of_bathrooms": 3.010042117374029,
   "Area": 3793.2239544114964,
   "Zipcode": 82601.03737075307
}'
echo -e ""
echo -e "Test OK: 41"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.1497865889427255,
   "Number_of_bathrooms": 1.3184116654309102,
   "Area": 9353.11994112628,
   "Zipcode": 94228.44096968436
}'
echo -e ""
echo -e "Test OK: 42"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.77155001089462,
   "Number_of_bathrooms": 1.8091490996691146,
   "Area": 1101.209113141996,
   "Zipcode": 93288.13154306103
}'
echo -e ""
echo -e "Test OK: 43"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.437686684830393,
   "Number_of_bathrooms": 3.5488380859343,
   "Area": 7495.737109605339,
   "Zipcode": 45909.4332668415
}'
echo -e ""
echo -e "Test OK: 44"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.276406099449298,
   "Number_of_bathrooms": 4.5116046737535935,
   "Area": 8055.297489651888,
   "Zipcode": 82673.05838134358
}'
echo -e ""
echo -e "Test OK: 45"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.717959423967555,
   "Number_of_bathrooms": 2.2487979710403545,
   "Area": 6788.161678788156,
   "Zipcode": 53662.22241684017
}'
echo -e ""
echo -e "Test OK: 46"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.209115752093609,
   "Number_of_bathrooms": 2.4619304721861646,
   "Area": 4950.54422676245,
   "Zipcode": 60911.13360646281
}'
echo -e ""
echo -e "Test OK: 47"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.8611070327632235,
   "Number_of_bathrooms": 6.752659317085412,
   "Area": 8272.51929675061,
   "Zipcode": 65302.34078171705
}'
echo -e ""
echo -e "Test OK: 48"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.7737488550943894,
   "Number_of_bathrooms": 1.8450547754069537,
   "Area": 1904.650897940365,
   "Zipcode": 44035.60187830685
}'
echo -e ""
echo -e "Test OK: 49"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.810840915712971,
   "Number_of_bathrooms": 3.6378877200328907,
   "Area": 6310.230167827927,
   "Zipcode": 82657.10246144116
}'
echo -e ""
echo -e "Test OK: 50"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.4991206931321734,
   "Number_of_bathrooms": 3.517659608404739,
   "Area": 6884.979632820146,
   "Zipcode": 40839.40303506822
}'
echo -e ""
echo -e "Test OK: 51"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.2199130053092773,
   "Number_of_bathrooms": 2.3985765385787197,
   "Area": 5147.989470199638,
   "Zipcode": 90947.78167335424
}'
echo -e ""
echo -e "Test OK: 52"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.434858170397316,
   "Number_of_bathrooms": 3.7923371652744935,
   "Area": 1319.9758156044109,
   "Zipcode": 82307.65183643761
}'
echo -e ""
echo -e "Test OK: 53"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.786687231011716,
   "Number_of_bathrooms": 2.760916810028032,
   "Area": 4262.980188931926,
   "Zipcode": 55613.24358412827
}'
echo -e ""
echo -e "Test OK: 54"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.520950753254814,
   "Number_of_bathrooms": 4.468095506789409,
   "Area": 2214.258542378948,
   "Zipcode": 97815.58758489806
}'
echo -e ""
echo -e "Test OK: 55"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.74645161723919,
   "Number_of_bathrooms": 5.654984161998279,
   "Area": 9010.653307629615,
   "Zipcode": 86289.17409085241
}'
echo -e ""
echo -e "Test OK: 56"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.919211083288329,
   "Number_of_bathrooms": 5.990868788785056,
   "Area": 8086.987068310681,
   "Zipcode": 63073.69915683854
}'
echo -e ""
echo -e "Test OK: 57"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.4587834029674878,
   "Number_of_bathrooms": 6.192865820730579,
   "Area": 8422.15215562188,
   "Zipcode": 39505.64140029365
}'
echo -e ""
echo -e "Test OK: 58"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.808071312371656,
   "Number_of_bathrooms": 1.8974819206482907,
   "Area": 6362.342767827406,
   "Zipcode": 48785.971701099064
}'
echo -e ""
echo -e "Test OK: 59"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.267913844785286,
   "Number_of_bathrooms": 3.865454605228324,
   "Area": 799.4408372262072,
   "Zipcode": 79913.63241601633
}'
echo -e ""
echo -e "Test OK: 60"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.38027336959733,
   "Number_of_bathrooms": 5.35397846921268,
   "Area": 6682.562372849803,
   "Zipcode": 59761.436959926476
}'
echo -e ""
echo -e "Test OK: 61"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.775538075753815,
   "Number_of_bathrooms": 3.8275297262024974,
   "Area": 6804.474012924496,
   "Zipcode": 94060.01461740451
}'
echo -e ""
echo -e "Test OK: 62"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.406581410131402,
   "Number_of_bathrooms": 1.2928506060800469,
   "Area": 4100.0062821647925,
   "Zipcode": 66158.02172981814
}'
echo -e ""
echo -e "Test OK: 63"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.1680108887323124,
   "Number_of_bathrooms": 2.8943861603895082,
   "Area": 5753.493769078409,
   "Zipcode": 45336.91818342458
}'
echo -e ""
echo -e "Test OK: 64"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.6696265833688693,
   "Number_of_bathrooms": 4.519550926396661,
   "Area": 6099.852322517989,
   "Zipcode": 94005.07739184654
}'
echo -e ""
echo -e "Test OK: 65"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.5772456349579937,
   "Number_of_bathrooms": 2.633479108287146,
   "Area": 8816.069208979734,
   "Zipcode": 79238.1217223669
}'
echo -e ""
echo -e "Test OK: 66"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.4121914932701607,
   "Number_of_bathrooms": 3.335140213819659,
   "Area": 2001.6229474580255,
   "Zipcode": 76850.35451876963
}'
echo -e ""
echo -e "Test OK: 67"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.030343185019388,
   "Number_of_bathrooms": 4.177508889924427,
   "Area": 1428.5916115852197,
   "Zipcode": 49196.92393407427
}'
echo -e ""
echo -e "Test OK: 68"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.72307067909895,
   "Number_of_bathrooms": 6.735476248134651,
   "Area": 8495.732230194866,
   "Zipcode": 80297.03010513217
}'
echo -e ""
echo -e "Test OK: 69"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.483249314945553,
   "Number_of_bathrooms": 6.269895427743874,
   "Area": 9039.535536023755,
   "Zipcode": 71606.05487902348
}'
echo -e ""
echo -e "Test OK: 70"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.168174876440891,
   "Number_of_bathrooms": 5.961986846571472,
   "Area": 3044.619873916936,
   "Zipcode": 90729.8196052603
}'
echo -e ""
echo -e "Test OK: 71"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.9330917168842414,
   "Number_of_bathrooms": 5.175240160235066,
   "Area": 732.6584399406669,
   "Zipcode": 55126.918620185344
}'
echo -e ""
echo -e "Test OK: 72"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.198846468201935,
   "Number_of_bathrooms": 3.2798042344661003,
   "Area": 7833.746936859404,
   "Zipcode": 89932.75478457498
}'
echo -e ""
echo -e "Test OK: 73"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.2790932908401675,
   "Number_of_bathrooms": 1.847631971014645,
   "Area": 3189.169187750518,
   "Zipcode": 88228.56547681944
}'
echo -e ""
echo -e "Test OK: 74"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.9720852618604376,
   "Number_of_bathrooms": 2.4122428306996393,
   "Area": 3188.1564822954374,
   "Zipcode": 70175.11998755175
}'
echo -e ""
echo -e "Test OK: 75"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.129403364264166,
   "Number_of_bathrooms": 2.9263011242833,
   "Area": 2711.4083474857757,
   "Zipcode": 95296.41241758785
}'
echo -e ""
echo -e "Test OK: 76"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.891960621551474,
   "Number_of_bathrooms": 3.6441844008379967,
   "Area": 7097.471176288188,
   "Zipcode": 46426.06683153649
}'
echo -e ""
echo -e "Test OK: 77"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.162152221563337,
   "Number_of_bathrooms": 5.851656757702511,
   "Area": 6899.916831338626,
   "Zipcode": 41888.51292281944
}'
echo -e ""
echo -e "Test OK: 78"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.588291782549082,
   "Number_of_bathrooms": 1.4640737976970934,
   "Area": 6726.9535704946975,
   "Zipcode": 55743.77146573107
}'
echo -e ""
echo -e "Test OK: 79"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.351896770353737,
   "Number_of_bathrooms": 5.990961910069912,
   "Area": 2971.435315393632,
   "Zipcode": 40572.042974037344
}'
echo -e ""
echo -e "Test OK: 80"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.9807498367065905,
   "Number_of_bathrooms": 4.390074983437721,
   "Area": 2243.049513029117,
   "Zipcode": 87774.65871441309
}'
echo -e ""
echo -e "Test OK: 81"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.143178969451307,
   "Number_of_bathrooms": 5.752465973643236,
   "Area": 3085.566298946188,
   "Zipcode": 60792.23512788539
}'
echo -e ""
echo -e "Test OK: 82"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.2022786680228865,
   "Number_of_bathrooms": 1.0243118138818128,
   "Area": 2907.244798887673,
   "Zipcode": 57942.372194700685
}'
echo -e ""
echo -e "Test OK: 83"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.234299135135312,
   "Number_of_bathrooms": 3.7462753534970887,
   "Area": 2684.2106035325196,
   "Zipcode": 56855.01237041128
}'
echo -e ""
echo -e "Test OK: 84"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.1719150828445635,
   "Number_of_bathrooms": 6.451777056642202,
   "Area": 7547.60642703626,
   "Zipcode": 56589.43013436301
}'
echo -e ""
echo -e "Test OK: 85"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.6465520312507527,
   "Number_of_bathrooms": 4.293181924110286,
   "Area": 5366.123443327596,
   "Zipcode": 43118.09517775499
}'
echo -e ""
echo -e "Test OK: 86"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.622660873599833,
   "Number_of_bathrooms": 1.277195915140285,
   "Area": 2810.371925627004,
   "Zipcode": 71274.01710926203
}'
echo -e ""
echo -e "Test OK: 87"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.912017142162222,
   "Number_of_bathrooms": 4.721396182478067,
   "Area": 7463.178111392988,
   "Zipcode": 61818.08396665847
}'
echo -e ""
echo -e "Test OK: 88"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.938861547837705,
   "Number_of_bathrooms": 1.2109359791622043,
   "Area": 8706.405931434234,
   "Zipcode": 67362.67858280856
}'
echo -e ""
echo -e "Test OK: 89"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.6003783232526905,
   "Number_of_bathrooms": 2.4476610028855177,
   "Area": 9533.642826605668,
   "Zipcode": 86607.30042534095
}'
echo -e ""
echo -e "Test OK: 90"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.4702141744900863,
   "Number_of_bathrooms": 6.620274658270101,
   "Area": 7660.312173585373,
   "Zipcode": 56226.51422381018
}'
echo -e ""
echo -e "Test OK: 91"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.158679384290942,
   "Number_of_bathrooms": 5.237347790796619,
   "Area": 1484.8684258071657,
   "Zipcode": 91954.00178522278
}'
echo -e ""
echo -e "Test OK: 92"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.06649223128101,
   "Number_of_bathrooms": 3.666303129203487,
   "Area": 5613.2943318329635,
   "Zipcode": 52243.31706241999
}'
echo -e ""
echo -e "Test OK: 93"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.55867064587625,
   "Number_of_bathrooms": 1.7107931857875234,
   "Area": 1020.2038142363187,
   "Zipcode": 73532.51176270994
}'
echo -e ""
echo -e "Test OK: 94"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.293896706179251,
   "Number_of_bathrooms": 4.036270439853934,
   "Area": 6149.021896066,
   "Zipcode": 90468.96929671144
}'
echo -e ""
echo -e "Test OK: 95"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.9514561331365656,
   "Number_of_bathrooms": 2.203564576803358,
   "Area": 8432.819633084662,
   "Zipcode": 51532.13330620475
}'
echo -e ""
echo -e "Test OK: 96"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.323970032762707,
   "Number_of_bathrooms": 5.03659498970481,
   "Area": 1041.4185036136985,
   "Zipcode": 90281.90118041098
}'
echo -e ""
echo -e "Test OK: 97"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.9878217066396755,
   "Number_of_bathrooms": 5.645480827822885,
   "Area": 7931.373978706118,
   "Zipcode": 61655.03579633901
}'
echo -e ""
echo -e "Test OK: 98"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.908225806725453,
   "Number_of_bathrooms": 6.855482113699652,
   "Area": 3948.6500300688667,
   "Zipcode": 95267.28922150785
}'
echo -e ""
echo -e "Test OK: 99"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.721080820332803,
   "Number_of_bathrooms": 5.811301445840961,
   "Area": 2554.7522093018442,
   "Zipcode": 79929.5679311883
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.6575161462006203,
   "Number_of_bathrooms": 17.0,
   "Area": 988.3049725155652,
   "Zipcode": 54871.03301971595
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.0100908374849444,
   "Number_of_bathrooms": 11.0,
   "Area": 5609.146570630558,
   "Zipcode": 92138.20974225816
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.7676874477513347,
   "Number_of_bathrooms": 8.0,
   "Area": 9591,
   "Zipcode": 70000.56292728544
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.356107862136609,
   "Number_of_bathrooms": 10.0,
   "Area": 6509.394953396402,
   "Zipcode": 98026
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.4884538635861446,
   "Number_of_bathrooms": 16.0,
   "Area": 9589,
   "Zipcode": 89822.99463043598
}'
echo -e ""
echo -e "Test KO: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.222385521192114,
   "Number_of_bathrooms": 16.0,
   "Area": 3947.681929916,
   "Zipcode": 70369.00256528868
}'
echo -e ""
echo -e "Test KO: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.2752315388382005,
   "Number_of_bathrooms": 2.2146698645803737,
   "Area": 9583,
   "Zipcode": 98021
}'
echo -e ""
echo -e "Test KO: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.759724288359588,
   "Number_of_bathrooms": 14.0,
   "Area": 3501.5618889630323,
   "Zipcode": 98025
}'
echo -e ""
echo -e "Test KO: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.203842048889828,
   "Number_of_bathrooms": 12.0,
   "Area": 3685.708138455005,
   "Zipcode": 65422.8824240869
}'
echo -e ""
echo -e "Test KO: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 20,
   "Number_of_bathrooms": 2.8784936170558186,
   "Area": 6811.563287614674,
   "Zipcode": 98029
}'
echo -e ""
echo -e "Test KO: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 17,
   "Number_of_bathrooms": 6.673921623035747,
   "Area": 9593,
   "Zipcode": 66603.79137530198
}'
echo -e ""
echo -e "Test KO: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 11,
   "Number_of_bathrooms": 5.405929019040847,
   "Area": 9593,
   "Zipcode": 77265.38592811304
}'
echo -e ""
echo -e "Test KO: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.067608124328526,
   "Number_of_bathrooms": 8.0,
   "Area": 3023.483278956427,
   "Zipcode": 52236.645871513756
}'
echo -e ""
echo -e "Test KO: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 16,
   "Number_of_bathrooms": 16.0,
   "Area": 9588,
   "Zipcode": 98028
}'
echo -e ""
echo -e "Test KO: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 14,
   "Number_of_bathrooms": 3.054555182329889,
   "Area": 9583,
   "Zipcode": 94727.24325754825
}'
echo -e ""
echo -e "Test KO: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 15,
   "Number_of_bathrooms": 5.863358954748488,
   "Area": 6500.612342976444,
   "Zipcode": 98028
}'
echo -e ""
echo -e "Test KO: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.491093589070776,
   "Number_of_bathrooms": 3.231514712715396,
   "Area": 9587,
   "Zipcode": 40057.23189158306
}'
echo -e ""
echo -e "Test KO: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 12,
   "Number_of_bathrooms": 4.295698959789533,
   "Area": 9591,
   "Zipcode": 59286.05463685893
}'
echo -e ""
echo -e "Test KO: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.2372237217811635,
   "Number_of_bathrooms": 16.0,
   "Area": 8478.322393127692,
   "Zipcode": 98022
}'
echo -e ""
echo -e "Test KO: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 13,
   "Number_of_bathrooms": 6.617105895411342,
   "Area": 9585,
   "Zipcode": 98026
}'
echo -e ""
echo -e "Test KO: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 11,
   "Number_of_bathrooms": 3.41957305009612,
   "Area": 9583,
   "Zipcode": 38413.9688308247
}'
echo -e ""
echo -e "Test KO: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.7370599045353223,
   "Number_of_bathrooms": 12.0,
   "Area": 6401.150583747673,
   "Zipcode": 98029
}'
echo -e ""
echo -e "Test KO: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.578020012382309,
   "Number_of_bathrooms": 11.0,
   "Area": 9589,
   "Zipcode": 86966.0617923747
}'
echo -e ""
echo -e "Test KO: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.904988676886301,
   "Number_of_bathrooms": 8.0,
   "Area": 9588,
   "Zipcode": 52452.359474475496
}'
echo -e ""
echo -e "Test KO: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.7178027567586227,
   "Number_of_bathrooms": 10.0,
   "Area": 5274.498764060142,
   "Zipcode": 98023
}'
echo -e ""
echo -e "Test KO: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 19,
   "Number_of_bathrooms": 1.9398726112042344,
   "Area": 9589,
   "Zipcode": 39450.250979565804
}'
echo -e ""
echo -e "Test KO: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.862483668592853,
   "Number_of_bathrooms": 17.0,
   "Area": 9588,
   "Zipcode": 98026
}'
echo -e ""
echo -e "Test KO: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 13,
   "Number_of_bathrooms": 13.0,
   "Area": 5794.750708915453,
   "Zipcode": 98029
}'
echo -e ""
echo -e "Test KO: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 17,
   "Number_of_bathrooms": 3.9461735264390043,
   "Area": 6528.567026691309,
   "Zipcode": 98028
}'
echo -e ""
echo -e "Test KO: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 18,
   "Number_of_bathrooms": 4.12708198613884,
   "Area": 9584,
   "Zipcode": 38285.88871151885
}'
echo -e ""
echo -e "Test KO: 30"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 15,
   "Number_of_bathrooms": 3.0298564936503714,
   "Area": 9584,
   "Zipcode": 72409.94661164674
}'
echo -e ""
echo -e "Test KO: 31"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 8.412027527977799,
   "Number_of_bathrooms": 14.0,
   "Area": 5013.577519445406,
   "Zipcode": 98025
}'
echo -e ""
echo -e "Test KO: 32"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 15,
   "Number_of_bathrooms": 2.3123722743823216,
   "Area": 9583,
   "Zipcode": 65285.57623859177
}'
echo -e ""
echo -e "Test KO: 33"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.213645240497594,
   "Number_of_bathrooms": 2.3660183336684684,
   "Area": 8431.017058744583,
   "Zipcode": 40007.348834803
}'
echo -e ""
echo -e "Test KO: 34"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.038784270562893,
   "Number_of_bathrooms": 9.0,
   "Area": 1703.882622490345,
   "Zipcode": 98030
}'
echo -e ""
echo -e "Test KO: 35"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 19,
   "Number_of_bathrooms": 6.40469008155895,
   "Area": 9587,
   "Zipcode": 79779.07358591948
}'
echo -e ""
echo -e "Test KO: 36"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.166350123727456,
   "Number_of_bathrooms": 8.0,
   "Area": 7559.984935701184,
   "Zipcode": 98028
}'
echo -e ""
echo -e "Test KO: 37"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 17,
   "Number_of_bathrooms": 9.0,
   "Area": 4559.013946670482,
   "Zipcode": 98021
}'
echo -e ""
echo -e "Test KO: 38"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.277494210155001,
   "Number_of_bathrooms": 9.0,
   "Area": 1892.5090806486542,
   "Zipcode": 98031
}'
echo -e ""
echo -e "Test KO: 39"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 15,
   "Number_of_bathrooms": 5.389957599674259,
   "Area": 9589,
   "Zipcode": 39797.48786776559
}'
echo -e ""
echo -e "Test KO: 40"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 17,
   "Number_of_bathrooms": 12.0,
   "Area": 8387.010166681794,
   "Zipcode": 98031
}'
echo -e ""
echo -e "Test KO: 41"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 10,
   "Number_of_bathrooms": 1.3808454382362836,
   "Area": 9591,
   "Zipcode": 92657.65652557436
}'
echo -e ""
echo -e "Test KO: 42"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.766457248531633,
   "Number_of_bathrooms": 6.487747083825446,
   "Area": 9586,
   "Zipcode": 41006.487959036545
}'
echo -e ""
echo -e "Test KO: 43"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 10,
   "Number_of_bathrooms": 3.281016379397639,
   "Area": 9585,
   "Zipcode": 53865.05926866609
}'
echo -e ""
echo -e "Test KO: 44"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 20,
   "Number_of_bathrooms": 1.7655628546670494,
   "Area": 9590,
   "Zipcode": 98029
}'
echo -e ""
echo -e "Test KO: 45"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 17,
   "Number_of_bathrooms": 4.8181274674678205,
   "Area": 9593,
   "Zipcode": 39799.81104136462
}'
echo -e ""
echo -e "Test KO: 46"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 13,
   "Number_of_bathrooms": 14.0,
   "Area": 9588,
   "Zipcode": 81374.44550312945
}'
echo -e ""
echo -e "Test KO: 47"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 13,
   "Number_of_bathrooms": 7.0,
   "Area": 2791.39404392215,
   "Zipcode": 98030
}'
echo -e ""
echo -e "Test KO: 48"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 16,
   "Number_of_bathrooms": 4.136893437732751,
   "Area": 9592,
   "Zipcode": 82930.64187518114
}'
echo -e ""
echo -e "Test KO: 49"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 11,
   "Number_of_bathrooms": 3.1438270424503334,
   "Area": 1329.3029397781747,
   "Zipcode": 98022
}'
echo -e ""
echo -e "Test KO: 50"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 14,
   "Number_of_bathrooms": 3.8139866294823874,
   "Area": 9593,
   "Zipcode": 77179.07945611348
}'
echo -e ""
echo -e "Test KO: 51"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 20,
   "Number_of_bathrooms": 6.967473001449398,
   "Area": 9585,
   "Zipcode": 98030
}'
echo -e ""
echo -e "Test KO: 52"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.719713720829651,
   "Number_of_bathrooms": 9.0,
   "Area": 6843.7410680000985,
   "Zipcode": 65549.47806763007
}'
echo -e ""
echo -e "Test KO: 53"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 17,
   "Number_of_bathrooms": 6.67283809205799,
   "Area": 9587,
   "Zipcode": 85378.32644613662
}'
echo -e ""
echo -e "Test KO: 54"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 17,
   "Number_of_bathrooms": 1.1850350435055523,
   "Area": 9592,
   "Zipcode": 84644.4427281699
}'
echo -e ""
echo -e "Test KO: 55"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 13,
   "Number_of_bathrooms": 2.833075879692623,
   "Area": 9592,
   "Zipcode": 36889.078298832566
}'
echo -e ""
echo -e "Test KO: 56"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 6.919272997717961,
   "Number_of_bathrooms": 14.0,
   "Area": 6895.90196281197,
   "Zipcode": 98028
}'
echo -e ""
echo -e "Test KO: 57"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 18,
   "Number_of_bathrooms": 6.455037684351071,
   "Area": 9589,
   "Zipcode": 98028
}'
echo -e ""
echo -e "Test KO: 58"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.534818307210492,
   "Number_of_bathrooms": 3.9961975831047853,
   "Area": 9586,
   "Zipcode": 38013.40556237258
}'
echo -e ""
echo -e "Test KO: 59"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.316945604035217,
   "Number_of_bathrooms": 14.0,
   "Area": 8629.009883901677,
   "Zipcode": 98031
}'
echo -e ""
echo -e "Test KO: 60"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.309355931028993,
   "Number_of_bathrooms": 13.0,
   "Area": 833.2305279043484,
   "Zipcode": 98027
}'
echo -e ""
echo -e "Test KO: 61"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 18,
   "Number_of_bathrooms": 6.110507191975824,
   "Area": 908.7257701408221,
   "Zipcode": 98026
}'
echo -e ""
echo -e "Test KO: 62"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 4.141821766903751,
   "Number_of_bathrooms": 1.854414001289882,
   "Area": 9589,
   "Zipcode": 50314.3544886987
}'
echo -e ""
echo -e "Test KO: 63"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.5923929060823525,
   "Number_of_bathrooms": 13.0,
   "Area": 9591,
   "Zipcode": 53497.01693387145
}'
echo -e ""
echo -e "Test KO: 64"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.4998404536208403,
   "Number_of_bathrooms": 14.0,
   "Area": 8638.533833580144,
   "Zipcode": 98026
}'
echo -e ""
echo -e "Test KO: 65"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.627779905729665,
   "Number_of_bathrooms": 15.0,
   "Area": 9587,
   "Zipcode": 98027
}'
echo -e ""
echo -e "Test KO: 66"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 19,
   "Number_of_bathrooms": 17.0,
   "Area": 8356.558804111119,
   "Zipcode": 39208.95120022768
}'
echo -e ""
echo -e "Test KO: 67"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.8195008368887144,
   "Number_of_bathrooms": 2.120919792215332,
   "Area": 9583,
   "Zipcode": 61440.840329096085
}'
echo -e ""
echo -e "Test KO: 68"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 18,
   "Number_of_bathrooms": 10.0,
   "Area": 9593,
   "Zipcode": 93251.30126859451
}'
echo -e ""
echo -e "Test KO: 69"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.58808513566857,
   "Number_of_bathrooms": 8.0,
   "Area": 2457.939249024902,
   "Zipcode": 98021
}'
echo -e ""
echo -e "Test KO: 70"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.7141264728300745,
   "Number_of_bathrooms": 13.0,
   "Area": 5634.1928775120805,
   "Zipcode": 98027
}'
echo -e ""
echo -e "Test KO: 71"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.0773699408296853,
   "Number_of_bathrooms": 16.0,
   "Area": 9593,
   "Zipcode": 76131.65070396171
}'
echo -e ""
echo -e "Test KO: 72"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 3.9181074037351884,
   "Number_of_bathrooms": 6.612956633837808,
   "Area": 9584,
   "Zipcode": 45898.037901965996
}'
echo -e ""
echo -e "Test KO: 73"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 14,
   "Number_of_bathrooms": 2.2248538731810665,
   "Area": 9588,
   "Zipcode": 39168.393129239426
}'
echo -e ""
echo -e "Test KO: 74"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 14,
   "Number_of_bathrooms": 3.9889391914771926,
   "Area": 9583,
   "Zipcode": 84826.93899591829
}'
echo -e ""
echo -e "Test KO: 75"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.8728449899897326,
   "Number_of_bathrooms": 4.037916153926327,
   "Area": 9576.071398728442,
   "Zipcode": 98030
}'
echo -e ""
echo -e "Test KO: 76"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 18,
   "Number_of_bathrooms": 5.498232498519456,
   "Area": 9593,
   "Zipcode": 78887.63388085584
}'
echo -e ""
echo -e "Test KO: 77"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.017672989071709,
   "Number_of_bathrooms": 6.601686461142301,
   "Area": 9593,
   "Zipcode": 79545.80525565523
}'
echo -e ""
echo -e "Test KO: 78"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 18,
   "Number_of_bathrooms": 3.5678759042342616,
   "Area": 9067.247238976035,
   "Zipcode": 98026
}'
echo -e ""
echo -e "Test KO: 79"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.624486755061444,
   "Number_of_bathrooms": 4.179863552567717,
   "Area": 9590,
   "Zipcode": 98029
}'
echo -e ""
echo -e "Test KO: 80"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 17,
   "Number_of_bathrooms": 4.599340561349919,
   "Area": 9590,
   "Zipcode": 68645.35046102451
}'
echo -e ""
echo -e "Test KO: 81"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.41699916202133,
   "Number_of_bathrooms": 16.0,
   "Area": 833.3151883848786,
   "Zipcode": 48527.11473040658
}'
echo -e ""
echo -e "Test KO: 82"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.893937667674576,
   "Number_of_bathrooms": 7.0,
   "Area": 7431.962068136058,
   "Zipcode": 98029
}'
echo -e ""
echo -e "Test KO: 83"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 15,
   "Number_of_bathrooms": 5.345700195432258,
   "Area": 9587,
   "Zipcode": 92239.5470186577
}'
echo -e ""
echo -e "Test KO: 84"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 17,
   "Number_of_bathrooms": 6.412747858306663,
   "Area": 7545.690197245479,
   "Zipcode": 98028
}'
echo -e ""
echo -e "Test KO: 85"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 7.833271286207955,
   "Number_of_bathrooms": 14.0,
   "Area": 7680.353104927633,
   "Zipcode": 95140.12319977896
}'
echo -e ""
echo -e "Test KO: 86"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 20,
   "Number_of_bathrooms": 3.8129463681156057,
   "Area": 4814.059727680217,
   "Zipcode": 98022
}'
echo -e ""
echo -e "Test KO: 87"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 13,
   "Number_of_bathrooms": 4.9726847860709364,
   "Area": 9588,
   "Zipcode": 98023
}'
echo -e ""
echo -e "Test KO: 88"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 10,
   "Number_of_bathrooms": 3.6492906490392105,
   "Area": 9584,
   "Zipcode": 73276.4243131255
}'
echo -e ""
echo -e "Test KO: 89"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 10,
   "Number_of_bathrooms": 16.0,
   "Area": 9270.183294574692,
   "Zipcode": 69278.62210407405
}'
echo -e ""
echo -e "Test KO: 90"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 9.742705504712545,
   "Number_of_bathrooms": 4.863175736883877,
   "Area": 9590,
   "Zipcode": 98022
}'
echo -e ""
echo -e "Test KO: 91"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 13,
   "Number_of_bathrooms": 3.287936777953276,
   "Area": 9584,
   "Zipcode": 37842.46765675015
}'
echo -e ""
echo -e "Test KO: 92"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 2.9331575969451915,
   "Number_of_bathrooms": 9.0,
   "Area": 9584,
   "Zipcode": 61217.375865857
}'
echo -e ""
echo -e "Test KO: 93"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 1.9277914005857895,
   "Number_of_bathrooms": 14.0,
   "Area": 9590,
   "Zipcode": 43118.038049387986
}'
echo -e ""
echo -e "Test KO: 94"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 16,
   "Number_of_bathrooms": 3.4437658912031983,
   "Area": 9590,
   "Zipcode": 55937.92094052136
}'
echo -e ""
echo -e "Test KO: 95"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 18,
   "Number_of_bathrooms": 1.970454254720324,
   "Area": 9590,
   "Zipcode": 45579.232886277896
}'
echo -e ""
echo -e "Test KO: 96"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 14,
   "Number_of_bathrooms": 6.473904604105742,
   "Area": 9586,
   "Zipcode": 45545.75451419047
}'
echo -e ""
echo -e "Test KO: 97"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 5.25261394015873,
   "Number_of_bathrooms": 10.0,
   "Area": 6688.082457125535,
   "Zipcode": 98027
}'
echo -e ""
echo -e "Test KO: 98"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 10,
   "Number_of_bathrooms": 17.0,
   "Area": 9270.924648826493,
   "Zipcode": 98029
}'
echo -e ""
echo -e "Test KO: 99"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Number_of_Bedrooms": 11,
   "Number_of_bathrooms": 6.056526435503585,
   "Area": 9591,
   "Zipcode": 75008.69492210483
}'
echo -e ""
