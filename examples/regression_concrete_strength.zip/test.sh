echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 151.46269535048822,
   "Blast_Furnace_Slag": 156.37835591295516,
   "Water": 182.1004728069124,
   "Superplasticizer": 24.474796807178222,
   "Age": 311.58427263414745
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 502.67860088722324,
   "Blast_Furnace_Slag": 200.34849012022056,
   "Water": 197.03820521419078,
   "Superplasticizer": 7.201939385842252,
   "Age": 261.5113739728492
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 434.7220528727324,
   "Blast_Furnace_Slag": 285.6851029470801,
   "Water": 146.8235639587358,
   "Superplasticizer": 4.671940232186144,
   "Age": 137.3798111538017
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 452.90925194731955,
   "Blast_Furnace_Slag": 162.8160912873536,
   "Water": 193.05304190724107,
   "Superplasticizer": 4.015867171030477,
   "Age": 58.50296916390568
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 258.51743218668366,
   "Blast_Furnace_Slag": 344.5550980769975,
   "Water": 169.523687858535,
   "Superplasticizer": 24.877653775174466,
   "Age": 100.40157176478826
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 388.05460372512607,
   "Blast_Furnace_Slag": 58.69688152031132,
   "Water": 232.6968451553147,
   "Superplasticizer": 19.292035187794752,
   "Age": 135.44973958680967
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 253.92111131692522,
   "Blast_Furnace_Slag": 67.23771814048877,
   "Water": 130.08739132324212,
   "Superplasticizer": 16.389426470835385,
   "Age": 28.75981268766468
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 442.00422746147905,
   "Blast_Furnace_Slag": 187.19412024180045,
   "Water": 150.11936095375634,
   "Superplasticizer": 5.686099387403981,
   "Age": 250.28634825140304
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 119.48838598856182,
   "Blast_Furnace_Slag": 291.8025223346488,
   "Water": 177.43038443287423,
   "Superplasticizer": 16.869668625539106,
   "Age": 328.4882667823551
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 448.613785904139,
   "Blast_Furnace_Slag": 32.35474411730716,
   "Water": 136.11830398869392,
   "Superplasticizer": 0.6000270640062539,
   "Age": 325.3869080947486
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 454.79625470166815,
   "Blast_Furnace_Slag": 287.59046271422443,
   "Water": 157.35834514160624,
   "Superplasticizer": 22.209974207257243,
   "Age": 120.60729350120378
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 520.764570490211,
   "Blast_Furnace_Slag": 299.3334563579439,
   "Water": 227.5046172883745,
   "Superplasticizer": 15.024341987567643,
   "Age": 316.62407119491195
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 122.2473584145381,
   "Blast_Furnace_Slag": 279.01411186125137,
   "Water": 229.2501251308504,
   "Superplasticizer": 32.0757514046525,
   "Age": 197.4021034809046
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 203.41802426162235,
   "Blast_Furnace_Slag": 59.85820701620426,
   "Water": 189.92169934285187,
   "Superplasticizer": 26.286065618974785,
   "Age": 319.0711720454932
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 309.83223197347536,
   "Blast_Furnace_Slag": 188.6888360525412,
   "Water": 165.96470242962107,
   "Superplasticizer": 4.836769345926962,
   "Age": 178.91596623755248
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 189.8936257612335,
   "Blast_Furnace_Slag": 326.67785020093766,
   "Water": 147.9227411887658,
   "Superplasticizer": 15.41362413483068,
   "Age": 35.24812040341581
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 153.81995023042487,
   "Blast_Furnace_Slag": 241.25444894326867,
   "Water": 214.46547610269553,
   "Superplasticizer": 11.170004389132727,
   "Age": 126.09120976389315
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 243.95888860719683,
   "Blast_Furnace_Slag": 354.28659888382185,
   "Water": 131.68452271898917,
   "Superplasticizer": 21.90967956845727,
   "Age": 229.96217610773127
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 144.97553485456098,
   "Blast_Furnace_Slag": 180.45411808638465,
   "Water": 197.08036704888622,
   "Superplasticizer": 23.03763345564262,
   "Age": 89.01107430121927
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 443.169404693804,
   "Blast_Furnace_Slag": 299.0908975403293,
   "Water": 165.84029436466648,
   "Superplasticizer": 30.89734131665717,
   "Age": 108.52719347939029
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 541.0,
   "Blast_Furnace_Slag": 26.623436753365024,
   "Water": 253.0,
   "Superplasticizer": 25.76162640135108,
   "Age": 333.66390318988505
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 175.2593288359493,
   "Blast_Furnace_Slag": 123.45944214539215,
   "Water": 252.0,
   "Superplasticizer": 5.0671512698060885,
   "Age": 293.61722615411384
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 216.84063329726143,
   "Blast_Furnace_Slag": 362.4,
   "Water": 211.3468176616131,
   "Superplasticizer": 40.2,
   "Age": 305.76561177301204
}'
echo -e ""
