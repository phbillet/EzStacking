echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 4.113079811071547,
   "phonon_cutoff_frequency": 11.435414458622883,
   "mean_phonon_frequency": 5.783435932324594,
   "electronic_contribution_of_dielectric_constant": 23.365060508752894,
   "nearest_neighbor_distance": 1.7690243118791469
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 6.771541081143162,
   "phonon_cutoff_frequency": 5.939004112051783,
   "mean_phonon_frequency": 3.0434574211050274,
   "electronic_contribution_of_dielectric_constant": 19.011204156671184,
   "nearest_neighbor_distance": 2.51920245259787
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 13.189316712636058,
   "phonon_cutoff_frequency": 21.41080781448627,
   "mean_phonon_frequency": 20.084129176597532,
   "electronic_contribution_of_dielectric_constant": 10.915683019467576,
   "nearest_neighbor_distance": 2.939442908079556
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 9.43572398668373,
   "phonon_cutoff_frequency": 18.666438050387523,
   "mean_phonon_frequency": 26.043010437153658,
   "electronic_contribution_of_dielectric_constant": 7.6572723063539545,
   "nearest_neighbor_distance": 2.774885708167891
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 12.34444128719178,
   "phonon_cutoff_frequency": 17.585240406568882,
   "mean_phonon_frequency": 3.8529242620187625,
   "electronic_contribution_of_dielectric_constant": 4.6556114513733835,
   "nearest_neighbor_distance": 3.0061354573059296
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 0.27895762018373016,
   "phonon_cutoff_frequency": 26.04245592913847,
   "mean_phonon_frequency": 18.63558650791962,
   "electronic_contribution_of_dielectric_constant": 13.407981954374554,
   "nearest_neighbor_distance": 1.7843204922166835
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 3.494476427926819,
   "phonon_cutoff_frequency": 38.93910520216366,
   "mean_phonon_frequency": 8.754422322333767,
   "electronic_contribution_of_dielectric_constant": 4.810179538633211,
   "nearest_neighbor_distance": 1.8569066729973946
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 9.675741466223457,
   "phonon_cutoff_frequency": 28.781896601942996,
   "mean_phonon_frequency": 26.486145438315795,
   "electronic_contribution_of_dielectric_constant": 4.502776324184841,
   "nearest_neighbor_distance": 1.744102250851256
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 11.906080090504503,
   "phonon_cutoff_frequency": 25.863823597158184,
   "mean_phonon_frequency": 24.179266303918364,
   "electronic_contribution_of_dielectric_constant": 23.125982013927214,
   "nearest_neighbor_distance": 1.716060324554643
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 7.303754406972478,
   "phonon_cutoff_frequency": 39.024319919120124,
   "mean_phonon_frequency": 12.344174856682987,
   "electronic_contribution_of_dielectric_constant": 11.041585233928764,
   "nearest_neighbor_distance": 1.8645570746601927
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 13.477943397454661,
   "phonon_cutoff_frequency": 3.0965777556161083,
   "mean_phonon_frequency": 27.62824135885493,
   "electronic_contribution_of_dielectric_constant": 25.586955860923215,
   "nearest_neighbor_distance": 2.628913832767252
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 12.68113120975533,
   "phonon_cutoff_frequency": 9.610321484611823,
   "mean_phonon_frequency": 11.9825381204374,
   "electronic_contribution_of_dielectric_constant": 24.23650384300888,
   "nearest_neighbor_distance": 1.5894342605638179
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 7.2987260624423635,
   "phonon_cutoff_frequency": 33.3186447512354,
   "mean_phonon_frequency": 13.308250163636352,
   "electronic_contribution_of_dielectric_constant": 16.846903671356298,
   "nearest_neighbor_distance": 3.326932330557065
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 13.466659537305668,
   "phonon_cutoff_frequency": 9.809446992278604,
   "mean_phonon_frequency": 10.79848643857597,
   "electronic_contribution_of_dielectric_constant": 5.218384340243543,
   "nearest_neighbor_distance": 2.9142083276294417
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 12.608523773235808,
   "phonon_cutoff_frequency": 39.24263542205696,
   "mean_phonon_frequency": 5.400678989361796,
   "electronic_contribution_of_dielectric_constant": 3.0098429186977675,
   "nearest_neighbor_distance": 3.1606675039747643
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 3.3787322840253338,
   "phonon_cutoff_frequency": 10.678963799326608,
   "mean_phonon_frequency": 18.698983431492685,
   "electronic_contribution_of_dielectric_constant": 25.63603637846327,
   "nearest_neighbor_distance": 2.1636598471130215
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 3.3301306147495446,
   "phonon_cutoff_frequency": 26.794097534080613,
   "mean_phonon_frequency": 18.074031520363544,
   "electronic_contribution_of_dielectric_constant": 13.804700800228922,
   "nearest_neighbor_distance": 2.851312547885315
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 7.669517430067153,
   "phonon_cutoff_frequency": 10.984105092671616,
   "mean_phonon_frequency": 26.141244591122796,
   "electronic_contribution_of_dielectric_constant": 21.650705735084976,
   "nearest_neighbor_distance": 3.337644306324524
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 12.62144639107152,
   "phonon_cutoff_frequency": 20.76194322496567,
   "mean_phonon_frequency": 18.395635722589333,
   "electronic_contribution_of_dielectric_constant": 6.035224118935501,
   "nearest_neighbor_distance": 2.720011353314701
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 7.199782291157923,
   "phonon_cutoff_frequency": 14.605851008253621,
   "mean_phonon_frequency": 3.7605033401364123,
   "electronic_contribution_of_dielectric_constant": 17.503257739647587,
   "nearest_neighbor_distance": 1.5995608622239672
}'
echo -e ""
echo -e "Test OK: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 6.117917787959567,
   "phonon_cutoff_frequency": 37.035363598524114,
   "mean_phonon_frequency": 23.120615182233117,
   "electronic_contribution_of_dielectric_constant": 8.406807786756815,
   "nearest_neighbor_distance": 2.6873366150577223
}'
echo -e ""
echo -e "Test OK: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 6.565652220060866,
   "phonon_cutoff_frequency": 8.293557745473997,
   "mean_phonon_frequency": 16.344609152557922,
   "electronic_contribution_of_dielectric_constant": 8.27746269853604,
   "nearest_neighbor_distance": 2.995890543781692
}'
echo -e ""
echo -e "Test OK: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 6.977130320521138,
   "phonon_cutoff_frequency": 10.733996611221439,
   "mean_phonon_frequency": 14.520659304312264,
   "electronic_contribution_of_dielectric_constant": 4.744697378767534,
   "nearest_neighbor_distance": 1.5739276597841925
}'
echo -e ""
echo -e "Test OK: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 6.155134804075754,
   "phonon_cutoff_frequency": 39.63159464774522,
   "mean_phonon_frequency": 12.81429702309681,
   "electronic_contribution_of_dielectric_constant": 3.9949454437851646,
   "nearest_neighbor_distance": 1.8247518709715513
}'
echo -e ""
echo -e "Test OK: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 0.4065720356380122,
   "phonon_cutoff_frequency": 3.985647852581153,
   "mean_phonon_frequency": 17.80942839379499,
   "electronic_contribution_of_dielectric_constant": 2.343525643722837,
   "nearest_neighbor_distance": 2.6402069435957367
}'
echo -e ""
echo -e "Test OK: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 4.093538901716228,
   "phonon_cutoff_frequency": 27.7354007612761,
   "mean_phonon_frequency": 11.419227142893174,
   "electronic_contribution_of_dielectric_constant": 1.895992747946872,
   "nearest_neighbor_distance": 2.0286629809059114
}'
echo -e ""
echo -e "Test OK: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 8.65656311482128,
   "phonon_cutoff_frequency": 34.28818274033073,
   "mean_phonon_frequency": 5.685903093354881,
   "electronic_contribution_of_dielectric_constant": 10.147966022033385,
   "nearest_neighbor_distance": 2.875924142301262
}'
echo -e ""
echo -e "Test OK: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 8.078647461823032,
   "phonon_cutoff_frequency": 36.506583949980524,
   "mean_phonon_frequency": 3.57391753615495,
   "electronic_contribution_of_dielectric_constant": 11.379707524504907,
   "nearest_neighbor_distance": 3.2613446894856493
}'
echo -e ""
echo -e "Test OK: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 1.9922744067845541,
   "phonon_cutoff_frequency": 23.394536431935407,
   "mean_phonon_frequency": 3.4082183459352766,
   "electronic_contribution_of_dielectric_constant": 20.57343314543245,
   "nearest_neighbor_distance": 3.319375357933226
}'
echo -e ""
echo -e "Test OK: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 9.272475684727754,
   "phonon_cutoff_frequency": 21.94428967849449,
   "mean_phonon_frequency": 5.873893582983363,
   "electronic_contribution_of_dielectric_constant": 22.726582120260492,
   "nearest_neighbor_distance": 2.9422158321214247
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 23.6,
   "phonon_cutoff_frequency": 21.92808975800535,
   "mean_phonon_frequency": 33.674,
   "electronic_contribution_of_dielectric_constant": 23.450619528538404,
   "nearest_neighbor_distance": 3.5902269348816906
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 19.6,
   "phonon_cutoff_frequency": 48.513,
   "mean_phonon_frequency": 19.901608945307686,
   "electronic_contribution_of_dielectric_constant": 15.697634365182157,
   "nearest_neighbor_distance": 1.5965976953049954
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 21.6,
   "phonon_cutoff_frequency": 40.10456877573281,
   "mean_phonon_frequency": 39.674,
   "electronic_contribution_of_dielectric_constant": 3.4113927575105647,
   "nearest_neighbor_distance": 2.6795482381655806
}'
echo -e ""
