echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 3.5848066306452173,
   "Glucose": 138.5317738819012,
   "BMI": 51.04136955942967,
   "DiabetesPedigreeFunction": 0.8540396397918307,
   "Age": 23.820845340419808
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 12.14104654824597,
   "Glucose": 169.99893247221158,
   "BMI": 18.427577963536322,
   "DiabetesPedigreeFunction": 2.095585517011352,
   "Age": 48.93047618379503
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 6.446704087893465,
   "Glucose": 161.7115902648605,
   "BMI": 15.960565940025718,
   "DiabetesPedigreeFunction": 1.5441153479306005,
   "Age": 27.02159759274798
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 4.068967700204586,
   "Glucose": 60.706077833989916,
   "BMI": 9.8443395196813,
   "DiabetesPedigreeFunction": 1.8652801624895108,
   "Age": 50.440661001728955
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 5.134422413163106,
   "Glucose": 99.91118159656934,
   "BMI": 11.423205187786872,
   "DiabetesPedigreeFunction": 1.7550018737524835,
   "Age": 47.457522318453634
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 11.600069741098917,
   "Glucose": 163.2953514285056,
   "BMI": 33.79428847489113,
   "DiabetesPedigreeFunction": 0.08044813883657279,
   "Age": 42.5006398299972
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 12.826698787632099,
   "Glucose": 78.0063541854891,
   "BMI": 2.8420690801016124,
   "DiabetesPedigreeFunction": 1.2417268124413694,
   "Age": 52.533857946172304
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 8.664760230321658,
   "Glucose": 144.22515384538778,
   "BMI": 59.08108486050673,
   "DiabetesPedigreeFunction": 1.5223607422323902,
   "Age": 71.99057778634105
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 0.07652493754097445,
   "Glucose": 77.24169741991311,
   "BMI": 47.91004150728566,
   "DiabetesPedigreeFunction": 0.4511910870849035,
   "Age": 59.03677752847082
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 16.306460636482825,
   "Glucose": 73.94042770112155,
   "BMI": 17.17406687431793,
   "DiabetesPedigreeFunction": 0.9083561344789726,
   "Age": 46.87737454751971
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 9.827043264968774,
   "Glucose": 105.50458437843722,
   "BMI": 52.94007152821692,
   "DiabetesPedigreeFunction": 0.5343391119603751,
   "Age": 64.25900264777546
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 21,
   "Glucose": 200,
   "BMI": 64.50379348048202,
   "DiabetesPedigreeFunction": 3.42,
   "Age": 47.15936574131214
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 26,
   "Glucose": 182.12570364608467,
   "BMI": 76.1,
   "DiabetesPedigreeFunction": 0.20862028297285118,
   "Age": 83
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Pregnancies": 16.851301736359414,
   "Glucose": 202,
   "BMI": 68.1,
   "DiabetesPedigreeFunction": 1.1342423176757486,
   "Age": 81
}'
echo -e ""
