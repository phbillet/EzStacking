echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "p",
   "gill_size": "n",
   "stalk_root": "c",
   "stalk_surface_above_ring": "s",
   "spore_print_color": "h"
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "m",
   "gill_size": "b",
   "stalk_root": "c",
   "stalk_surface_above_ring": "f",
   "spore_print_color": "o"
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "m",
   "gill_size": "n",
   "stalk_root": "?",
   "stalk_surface_above_ring": "f",
   "spore_print_color": "o"
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "f",
   "gill_size": "n",
   "stalk_root": "c",
   "stalk_surface_above_ring": "s",
   "spore_print_color": "b"
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "a",
   "gill_size": "n",
   "stalk_root": "b",
   "stalk_surface_above_ring": "f",
   "spore_print_color": "h"
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "p",
   "gill_size": "n",
   "stalk_root": "e",
   "stalk_surface_above_ring": "y",
   "spore_print_color": "b"
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "y",
   "gill_size": "n",
   "stalk_root": "e",
   "stalk_surface_above_ring": "f",
   "spore_print_color": "y"
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "n",
   "gill_size": "n",
   "stalk_root": "e",
   "stalk_surface_above_ring": "k",
   "spore_print_color": "u"
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "a",
   "gill_size": "b",
   "stalk_root": "e",
   "stalk_surface_above_ring": "k",
   "spore_print_color": "o"
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "c",
   "gill_size": "n",
   "stalk_root": "c",
   "stalk_surface_above_ring": "k",
   "spore_print_color": "y"
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "n",
   "gill_size": "n",
   "stalk_root": "c",
   "stalk_surface_above_ring": "y",
   "spore_print_color": "w"
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "m",
   "gill_size": "b",
   "stalk_root": "b",
   "stalk_surface_above_ring": "s",
   "spore_print_color": "w"
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "a",
   "gill_size": "b",
   "stalk_root": "e",
   "stalk_surface_above_ring": "y",
   "spore_print_color": "u"
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "s",
   "gill_size": "b",
   "stalk_root": "?",
   "stalk_surface_above_ring": "k",
   "spore_print_color": "u"
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "a",
   "gill_size": "b",
   "stalk_root": "r",
   "stalk_surface_above_ring": "f",
   "spore_print_color": "y"
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "n",
   "gill_size": "n",
   "stalk_root": "tata",
   "stalk_surface_above_ring": "tyty",
   "spore_print_color": "h"
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "f",
   "gill_size": "tutu",
   "stalk_root": "r",
   "stalk_surface_above_ring": "titi",
   "spore_print_color": "y"
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "tutu",
   "gill_size": "b",
   "stalk_root": "tata",
   "stalk_surface_above_ring": "s",
   "spore_print_color": "tete"
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "tutu",
   "gill_size": "b",
   "stalk_root": "tutu",
   "stalk_surface_above_ring": "f",
   "spore_print_color": "tete"
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "odor": "p",
   "gill_size": "n",
   "stalk_root": "r",
   "stalk_surface_above_ring": "tyty",
   "spore_print_color": "r"
}'
echo -e ""
