echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Passive Smoker": 7.535996916483544,
   "Fatigue": 5.306223538805264,
   "Wheezing": 4.350907381718761,
   "Swallowing Difficulty": 4.934493224523013,
   "Clubbing of Finger Nails": 7.611874141266048
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Passive Smoker": 2.1907771095020845,
   "Fatigue": 2.599806403955225,
   "Wheezing": 3.1361552572103957,
   "Swallowing Difficulty": 5.437147655367293,
   "Clubbing of Finger Nails": 7.626984448721784
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Passive Smoker": 4.594363633731561,
   "Fatigue": 7.4422840758295274,
   "Wheezing": 5.8822008683318465,
   "Swallowing Difficulty": 7.450407465497783,
   "Clubbing of Finger Nails": 2.6441246071202125
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Passive Smoker": 16,
   "Fatigue": 3.088904714207426,
   "Wheezing": 5.052072204337693,
   "Swallowing Difficulty": 18,
   "Clubbing of Finger Nails": 6.300645820546659
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Passive Smoker": 4.321513354668433,
   "Fatigue": 11,
   "Wheezing": 17,
   "Swallowing Difficulty": 11,
   "Clubbing of Finger Nails": 1.9832331064057795
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Passive Smoker": 1.6297283797789237,
   "Fatigue": 15,
   "Wheezing": 6.923676308749216,
   "Swallowing Difficulty": 14,
   "Clubbing of Finger Nails": 8.3052220462537
}'
echo -e ""
