echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0370668212513603,
   "ph": 6.629102728109869,
   "osmo": 320.82781296152666,
   "cond": 25.661333399423505,
   "urea": 353.5391821679121,
   "calc": 3.1939373104323607
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0337449137789718,
   "ph": 5.265471257173312,
   "osmo": 767.2093689590661,
   "cond": 15.753031240747797,
   "urea": 597.0711392260063,
   "calc": 14.23079204646626
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0056735866209046,
   "ph": 5.684852066509524,
   "osmo": 337.1296095098901,
   "cond": 35.62599690795713,
   "urea": 111.92799087120602,
   "calc": 0.533615739038427
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.007560031697317,
   "ph": 5.192318136520602,
   "osmo": 516.9769315247263,
   "cond": 9.610258939848872,
   "urea": 517.4312361999541,
   "calc": 4.952138089861611
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0343714657220437,
   "ph": 7.151112156366879,
   "osmo": 692.0368346074849,
   "cond": 36.21065992989095,
   "urea": 329.8816415735131,
   "calc": 3.798365697497124
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.013019268332523,
   "ph": 6.609200356731506,
   "osmo": 1086.9546228346244,
   "cond": 13.01074062273938,
   "urea": 232.4407339330718,
   "calc": 7.579225557000786
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0083890260799222,
   "ph": 6.9609530822242975,
   "osmo": 876.6525150660487,
   "cond": 11.004348268163152,
   "urea": 80.60352531458273,
   "calc": 7.387911330388495
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0214623256964415,
   "ph": 5.1994195595511155,
   "osmo": 602.4439361179789,
   "cond": 8.91680201506024,
   "urea": 429.4932853943054,
   "calc": 14.036701624313617
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0125911922719064,
   "ph": 7.5727347500547015,
   "osmo": 993.7599964902246,
   "cond": 15.265136516157458,
   "urea": 498.4334765793863,
   "calc": 2.643604866845103
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.021341927403644,
   "ph": 6.8232988160687,
   "osmo": 1087.464464417265,
   "cond": 25.637248357240672,
   "urea": 593.798552477087,
   "calc": 13.383710390357002
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0262121909670756,
   "ph": 13.940000000000001,
   "osmo": 1221.004614532906,
   "cond": 48.0,
   "urea": 89.71613878231324,
   "calc": 13.063157473082128
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.009576348452702,
   "ph": 13.940000000000001,
   "osmo": 870.0713507845564,
   "cond": 47.0,
   "urea": 348.05313567186977,
   "calc": 22.34
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0070889850258402,
   "ph": 5.776011453469099,
   "osmo": 1239,
   "cond": 14.992109687093015,
   "urea": 628,
   "calc": 8.414413043347658
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0349512132241125,
   "ph": 8.940000000000001,
   "osmo": 1241,
   "cond": 44.0,
   "urea": 361.8449926290796,
   "calc": 9.486463943010099
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 10.04,
   "ph": 8.940000000000001,
   "osmo": 742.697754751785,
   "cond": 42.0,
   "urea": 73.03461075326047,
   "calc": 24.34
}'
echo -e ""
echo -e "Test KO: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 10.04,
   "ph": 15.940000000000001,
   "osmo": 1246,
   "cond": 14.592260850508616,
   "urea": 622,
   "calc": 5.467720779421152
}'
echo -e ""
echo -e "Test KO: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0186753320378676,
   "ph": 16.94,
   "osmo": 717.8067400105043,
   "cond": 37.63661191085078,
   "urea": 630,
   "calc": 3.8268231952777114
}'
echo -e ""
echo -e "Test KO: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.029630344593176,
   "ph": 16.94,
   "osmo": 528.8146735326325,
   "cond": 48.0,
   "urea": 41.519352046390985,
   "calc": 19.34
}'
echo -e ""
echo -e "Test KO: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0275917695572985,
   "ph": 6.694163843838236,
   "osmo": 701.3564548922458,
   "cond": 45.0,
   "urea": 627,
   "calc": 18.34
}'
echo -e ""
echo -e "Test KO: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 6.04,
   "ph": 12.940000000000001,
   "osmo": 251.7938556851576,
   "cond": 41.0,
   "urea": 77.17333087541662,
   "calc": 15.34
}'
echo -e ""
