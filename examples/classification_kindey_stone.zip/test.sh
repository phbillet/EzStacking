echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0239387674689029,
   "ph": 5.665523213786509,
   "osmo": 961.4458824903255,
   "urea": 544.7025035572254,
   "calc": 4.176601091600539
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0229347285007648,
   "ph": 7.396694033081438,
   "osmo": 1121.2900840538418,
   "urea": 589.6889676751134,
   "calc": 11.968947621927766
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0272771145648434,
   "ph": 6.384659845263438,
   "osmo": 423.9965879720858,
   "urea": 345.3994541479237,
   "calc": 1.2249141826926002
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0229104972334335,
   "ph": 7.56101012419329,
   "osmo": 646.1955068477396,
   "urea": 120.04966663459543,
   "calc": 3.569678967345356
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0307921618891558,
   "ph": 6.617468638660938,
   "osmo": 929.7191760349252,
   "urea": 526.9116500282522,
   "calc": 5.837228117117926
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0072946925018527,
   "ph": 5.410646676088422,
   "osmo": 208.5410341579915,
   "urea": 514.7669847073084,
   "calc": 13.748708195676398
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0051660464866272,
   "ph": 5.158999279029808,
   "osmo": 723.3382014720404,
   "urea": 272.15873915398856,
   "calc": 12.569779579156224
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0156872333502602,
   "ph": 6.47818924956258,
   "osmo": 778.3935924171051,
   "urea": 405.6220260448883,
   "calc": 8.581160752662752
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0225448595657791,
   "ph": 7.523049808330536,
   "osmo": 284.630112643496,
   "urea": 177.25049785626115,
   "calc": 1.230957748083595
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.035631919811713,
   "ph": 5.959298078431724,
   "osmo": 511.03685023633966,
   "urea": 124.91766241437182,
   "calc": 9.258380013985155
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 1.0258789071848697,
   "ph": 5.280589334237695,
   "osmo": 344.0315377825807,
   "urea": 623,
   "calc": 10.134405286510649
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 10.04,
   "ph": 5.041627046622606,
   "osmo": 1240,
   "urea": 501.6120767351883,
   "calc": 5.499846308076603
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "gravity": 9.04,
   "ph": 12.940000000000001,
   "osmo": 1246,
   "urea": 546.872402494673,
   "calc": 4.000499676872734
}'
echo -e ""
