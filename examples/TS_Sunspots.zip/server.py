from fastapi import FastAPI
from joblib import load
import pandas as pd
import numpy as np
import nest_asyncio
import uvicorn
import ast
import time
from sklearn.base import is_classifier
from pydantic import BaseModel

# Creating FastAPI instance
app = FastAPI()

# Creating class to define the request body
# and the type hints of each attribute

class request_body(BaseModel):
      Total_Sunspot_Number_t_4: float
      Total_Sunspot_Number_t_3: float
      Total_Sunspot_Number_t_2: float
      Total_Sunspot_Number_t_1: float

# read dataframe schema
schema = pd.read_csv('schema.csv')

model = load('model.sav')


@app.get('/ping')
def pong():
    return {'ping': 'pong!'}

@app.post('/predict')
def predict(data : request_body):

    elaps_start_time = time.time()
    cpu_start_time = time.process_time()

    # Making the data in a form suitable for prediction
    test_data = [[
              data.Total_Sunspot_Number_t_4,
              data.Total_Sunspot_Number_t_3,
              data.Total_Sunspot_Number_t_2,
              data.Total_Sunspot_Number_t_1,
    ]]

    # Check input data
    data_err = []
    for ind in range(len(test_data[0])):
        if schema.iloc[ind][1] == 'num':
           interval = ast.literal_eval(schema.iloc[ind][2])
           if (test_data[0][ind] < interval[0]) | (test_data[0][ind] > interval[1]):
              data_err.append(schema.iloc[ind][0])
        if schema.iloc[ind][1] == 'cat':
           domain = ast.literal_eval(schema.iloc[ind][2])
           if not(np.isin(test_data[0][ind], domain)):
              data_err.append(schema.iloc[ind][0])

    # Predicting the regression value
    result = model.predict(pd.DataFrame(test_data,
                                        columns=[
                                                 'Total_Sunspot_Number_t_4',
                                                 'Total_Sunspot_Number_t_3',
                                                 'Total_Sunspot_Number_t_2',
                                                 'Total_Sunspot_Number_t_1',
                          ]))[0].item()

    elaps_end_time = time.time()
    cpu_end_time = time.process_time()
    elapsed_time = np.round((elaps_end_time - elaps_start_time) * 1000)
    elaps = str(elapsed_time) + 'ms'
    cpu_time = np.round((cpu_end_time - cpu_start_time) * 1000)
    cpu = str(cpu_time) + 'ms'

    # Return the Result
    return { 'regression_value' : result, 'error' : data_err, 'elapsed time' : elaps, 'cpu time' : cpu}

nest_asyncio.apply()
uvicorn.run(app, port=8000)
