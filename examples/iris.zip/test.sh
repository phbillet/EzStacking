echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.57295159505403,
   "sepal_width": 4.396300226745048,
   "petal_length": 4.110617779043915,
   "petal_width": 0.34293036623074674
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.301652511103209,
   "sepal_width": 2.2315256733102724,
   "petal_length": 3.5628446781769187,
   "petal_width": 0.39912113569309304
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.424434178144514,
   "sepal_width": 3.1816798727824245,
   "petal_length": 1.6898463033117954,
   "petal_width": 0.2898764626193898
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.0362820407705176,
   "sepal_width": 3.3673733881343004,
   "petal_length": 2.8068839308070697,
   "petal_width": 1.3573167480864792
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.311960655841138,
   "sepal_width": 3.369094854952814,
   "petal_length": 6.467277504227836,
   "petal_width": 1.6375613966200702
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.544010546370978,
   "sepal_width": 2.0321894345611544,
   "petal_length": 2.0930921839458225,
   "petal_width": 0.9661258670152142
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.552690603681727,
   "sepal_width": 2.408786491847696,
   "petal_length": 3.891662175700962,
   "petal_width": 2.325210641920525
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.843188082962074,
   "sepal_width": 3.0012748265280464,
   "petal_length": 2.6326604216319662,
   "petal_width": 0.40524324426740477
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.174060035395083,
   "sepal_width": 3.652042941768964,
   "petal_length": 5.64377455044574,
   "petal_width": 1.2171102875747903
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.199455381350323,
   "sepal_width": 2.9758629424302874,
   "petal_length": 1.5762749206167705,
   "petal_width": 1.400302925670996
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 13.9,
   "sepal_width": 2.607249622517622,
   "petal_length": 4.267694959711601,
   "petal_width": 6.5
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.820479256748906,
   "sepal_width": 12.4,
   "petal_length": 5.082846953249857,
   "petal_width": 1.7512111150878213
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.122804861086215,
   "sepal_width": 5.4,
   "petal_length": 14.9,
   "petal_width": 1.6763208234178575
}'
echo -e ""
