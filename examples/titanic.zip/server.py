from fastapi import FastAPI
from loguru import logger
from joblib import load
import pandas as pd
import numpy as np
import uvicorn
import ast
import time
from sklearn.base import is_classifier
from pydantic import BaseModel

# Creating FastAPI instance
app = FastAPI()

# Creating class to define the request body
# and the type hints of each attribute

class request_body(BaseModel):
      pclass: int
      sibsp: int
      embarked: str
      cabin_class: str
      who: str

# read dataframe schema
schema = pd.read_csv('schema.csv')
def K_Class(): 
    keras.backend.clear_session() 
#   neural network architecture: start 
    model = Sequential() 
    model.add(Dense(10 * layer_size, activation='relu')) 
    model.add(BatchNormalization()) 
    model.add(Dropout(0.5)) 
#    model.add(LayerNormalization()) 
    model.add(Dense(layer_size, activation='relu')) 
    model.add(BatchNormalization()) 
    model.add(Dropout(0.5)) 
#    model.add(LayerNormalization()) 
    model.add(Dense(nb_targets, activation='softmax')) 
#   neural network architecture: end   
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

model = load('model.sav')

classes = [0, 1]

@app.get('/ping')
def pong():
    return {'ping': 'pong!'}

@app.post('/predict')
def predict(data : request_body):

    elaps_start_time = time.time()
    cpu_start_time = time.process_time()

    # Making the data in a form suitable for prediction
    test_data = [[
              data.pclass,
              data.sibsp,
              data.embarked,
              data.cabin_class,
              data.who,
    ]]

    # Check input data
    data_err = []
    for ind in range(len(test_data[0])):
        if schema.iloc[ind][1] == 'num':
           interval = ast.literal_eval(schema.iloc[ind][2])
           if (test_data[0][ind] < interval[0]) | (test_data[0][ind] > interval[1]):
              data_err.append(schema.iloc[ind][0])
        if schema.iloc[ind][1] == 'cat':
           domain = ast.literal_eval(schema.iloc[ind][2])
           if not(np.isin(test_data[0][ind], domain)):
              data_err.append(schema.iloc[ind][0])

    # Predicting the Class
    result = model.predict(pd.DataFrame(test_data,
                                        columns=[
                                                  'pclass',
                                                  'sibsp',
                                                  'embarked',
                                                  'cabin_class',
                                                  'who',
                          ]))[0].item()

    elaps_end_time = time.time()
    cpu_end_time = time.process_time()
    elapsed_time = np.round((elaps_end_time - elaps_start_time) * 1000)
    elaps = str(elapsed_time) + 'ms'
    cpu_time = np.round((cpu_end_time - cpu_start_time) * 1000)
    cpu = str(cpu_time) + 'ms'

    # Return the Result
    return { 'class' : classes[result], 'error' : data_err, 'elapsed time' : elaps, 'cpu time' : cpu}

from pyngrok import ngrok
ngrok_tunnel = ngrok.connect(8000)
ngrok_tunnel

import nest_asyncio

nest_asyncio.apply()
uvicorn.run(app, port=8000)
