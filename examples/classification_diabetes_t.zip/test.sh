echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 168.96956120120353,
   "BloodPressure": 50.23446322794669,
   "BMI": 24.877572140154097,
   "DiabetesPedigreeFunction": 0.8223965630223485,
   "Age": 75.1439692904005
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 59.135734584950384,
   "BloodPressure": 93.47578080476654,
   "BMI": 49.65978815658942,
   "DiabetesPedigreeFunction": 1.7477057467974733,
   "Age": 23.29477539124392
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 85.74630388148671,
   "BloodPressure": 109.82469851066939,
   "BMI": 60.642100289470655,
   "DiabetesPedigreeFunction": 2.3818691758675863,
   "Age": 46.690360630678825
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 115.6251051161363,
   "BloodPressure": 55.15079921428953,
   "BMI": 3.4431010676336893,
   "DiabetesPedigreeFunction": 0.10072685037132742,
   "Age": 22.105074188306162
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 16.238549139580684,
   "BloodPressure": 22.98524327483989,
   "BMI": 28.355408225343865,
   "DiabetesPedigreeFunction": 2.2925333817519076,
   "Age": 31.832519667031733
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 5.2256892372829515,
   "BloodPressure": 111.37183102065347,
   "BMI": 62.18468261969248,
   "DiabetesPedigreeFunction": 0.7021597644737184,
   "Age": 69.08995979578124
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 67.73120886694426,
   "BloodPressure": 108.11101128406374,
   "BMI": 14.095560821366261,
   "DiabetesPedigreeFunction": 1.1664328195464222,
   "Age": 25.341488314727915
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 121.58373407561236,
   "BloodPressure": 112.56535548215172,
   "BMI": 52.352046689981414,
   "DiabetesPedigreeFunction": 1.7417293480874065,
   "Age": 44.10741977060727
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 35.93034202445898,
   "BloodPressure": 36.16960399711905,
   "BMI": 7.759816133271787,
   "DiabetesPedigreeFunction": 0.9367369698014816,
   "Age": 34.44104351659909
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 62.94157277063401,
   "BloodPressure": 3.210481815904924,
   "BMI": 40.9806321382866,
   "DiabetesPedigreeFunction": 1.3778372911270422,
   "Age": 74.54425494081259
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 115.43534485963141,
   "BloodPressure": 59.365568439916174,
   "BMI": 1.481723908185083,
   "DiabetesPedigreeFunction": 1.7861060812672633,
   "Age": 45.88768270299294
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 20.812600560088917,
   "BloodPressure": 2.5645937130221035,
   "BMI": 26.3965623957482,
   "DiabetesPedigreeFunction": 1.3088009177375337,
   "Age": 54.494743726168664
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 100.14643655754972,
   "BloodPressure": 14.292361024048116,
   "BMI": 60.725992030494915,
   "DiabetesPedigreeFunction": 1.1061095486719135,
   "Age": 55.106290300059065
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 141.65783506455344,
   "BloodPressure": 12.154182657149802,
   "BMI": 53.80903220234706,
   "DiabetesPedigreeFunction": 2.0860652421266184,
   "Age": 35.09914880500813
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 47.36064649045472,
   "BloodPressure": 56.08615787755861,
   "BMI": 37.50864467208766,
   "DiabetesPedigreeFunction": 1.0105136540948758,
   "Age": 65.73886759450194
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 184.0586909850823,
   "BloodPressure": 60.30187899870607,
   "BMI": 18.953571374840926,
   "DiabetesPedigreeFunction": 1.8515375908908926,
   "Age": 49.641963924207445
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 64.02936063486749,
   "BloodPressure": 53.70537053258712,
   "BMI": 0.2327001702748728,
   "DiabetesPedigreeFunction": 0.16180108782064156,
   "Age": 69.85798575449981
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 172.56881930791815,
   "BloodPressure": 17.72157945506131,
   "BMI": 46.25059628435137,
   "DiabetesPedigreeFunction": 1.3143245267581802,
   "Age": 32.72894182249938
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 77.48621700540032,
   "BloodPressure": 9.755340719850242,
   "BMI": 3.4371732296812065,
   "DiabetesPedigreeFunction": 0.7878065217771647,
   "Age": 69.17513868540537
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 25.066174214112387,
   "BloodPressure": 9.61335814089449,
   "BMI": 51.05737349690602,
   "DiabetesPedigreeFunction": 0.708885238703222,
   "Age": 70.48417801878949
}'
echo -e ""
echo -e "Test OK: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 121.81129383685243,
   "BloodPressure": 97.35171973126005,
   "BMI": 11.801109976639935,
   "DiabetesPedigreeFunction": 1.662245877736891,
   "Age": 56.151676647416934
}'
echo -e ""
echo -e "Test OK: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 127.65320061030332,
   "BloodPressure": 72.06058915521139,
   "BMI": 10.531157779564802,
   "DiabetesPedigreeFunction": 2.3745187273837107,
   "Age": 74.86694457504029
}'
echo -e ""
echo -e "Test OK: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 77.47269616615148,
   "BloodPressure": 16.963731823001766,
   "BMI": 65.70534557232737,
   "DiabetesPedigreeFunction": 0.9580545338823226,
   "Age": 64.95982510054658
}'
echo -e ""
echo -e "Test OK: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 37.093844419894474,
   "BloodPressure": 46.65917907649843,
   "BMI": 12.688558897915733,
   "DiabetesPedigreeFunction": 1.8612813577693366,
   "Age": 33.135605062117165
}'
echo -e ""
echo -e "Test OK: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 98.04344628847969,
   "BloodPressure": 37.74715431329872,
   "BMI": 29.52000312896765,
   "DiabetesPedigreeFunction": 1.6129477391328484,
   "Age": 56.405332107719595
}'
echo -e ""
echo -e "Test OK: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 55.19651944483057,
   "BloodPressure": 60.67838709435153,
   "BMI": 63.58755015931616,
   "DiabetesPedigreeFunction": 1.7665166375955474,
   "Age": 78.77432839862189
}'
echo -e ""
echo -e "Test OK: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 39.56647387637774,
   "BloodPressure": 98.24840847525076,
   "BMI": 40.47568731480859,
   "DiabetesPedigreeFunction": 0.788501612590957,
   "Age": 36.44005210479549
}'
echo -e ""
echo -e "Test OK: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 169.4627240390005,
   "BloodPressure": 87.06687521763409,
   "BMI": 55.2386642730053,
   "DiabetesPedigreeFunction": 1.8916334351309803,
   "Age": 50.87375225299688
}'
echo -e ""
echo -e "Test OK: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 156.67973681906022,
   "BloodPressure": 107.52536612698272,
   "BMI": 42.07528577366803,
   "DiabetesPedigreeFunction": 0.6820411362252491,
   "Age": 45.846662680628555
}'
echo -e ""
echo -e "Test OK: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 71.07610218926807,
   "BloodPressure": 110.47261706424906,
   "BMI": 63.58268715330006,
   "DiabetesPedigreeFunction": 1.3898498288305128,
   "Age": 41.30323983518258
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 14.039786137010577,
   "BloodPressure": 63.220617493965904,
   "BMI": 69.1,
   "DiabetesPedigreeFunction": 3.42,
   "Age": 63.88068054343115
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 41.801962871623154,
   "BloodPressure": 123,
   "BMI": 37.565686360434654,
   "DiabetesPedigreeFunction": 12.42,
   "Age": 41.626777174740376
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Glucose": 206,
   "BloodPressure": 128,
   "BMI": 18.250664077166796,
   "DiabetesPedigreeFunction": 3.42,
   "Age": 27.743893572601817
}'
echo -e ""
