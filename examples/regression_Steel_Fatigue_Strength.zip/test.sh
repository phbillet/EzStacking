echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 252.4809624615316,
   "TT": 387.975057582183,
   "C": 0.22062652537519845,
   "Cr": 0.7134813653566963
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 452.6997750477799,
   "TT": 89.45483150523216,
   "C": 0.46756683005618616,
   "Cr": 1.1342627306764235
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 445.7429371478299,
   "TT": 495.62907476533064,
   "C": 0.26276550515462804,
   "Cr": 1.0386728390722495
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 343.12917471643084,
   "TT": 454.1464677719988,
   "C": 0.48122391195694847,
   "Cr": 0.05037146940847963
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 32.72034503400699,
   "TT": 123.13261252023382,
   "C": 0.6194932496035074,
   "Cr": 0.4503962699185158
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 383.26590424808813,
   "TT": 416.1897432136369,
   "C": 0.29799628045391524,
   "Cr": 0.29806695592947047
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 56.646338912494585,
   "TT": 650.9324236077551,
   "C": 0.2747395304957954,
   "Cr": 0.5618161161601537
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 224.44249787497674,
   "TT": 245.73556329058616,
   "C": 0.6114245231419655,
   "Cr": 0.21013224096218816
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 247.6729822413113,
   "TT": 236.22674167090312,
   "C": 0.5189083842784553,
   "Cr": 0.5821542180104216
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 59.50569740804969,
   "TT": 435.8142046127385,
   "C": 0.5490904546946898,
   "Cr": 0.8425276730879524
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 211.6016837318963,
   "TT": 517.8593969770743,
   "C": 0.23940769308959176,
   "Cr": 0.6534339799130985
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 227.27574585723096,
   "TT": 90.76842145475943,
   "C": 0.6192403175156339,
   "Cr": 0.589801258594357
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 123.93631604080355,
   "TT": 353.8413908550993,
   "C": 0.18710070128323933,
   "Cr": 1.138897013259125
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 493.2051302140563,
   "TT": 427.3761328811064,
   "C": 0.46288383651720033,
   "Cr": 0.04597861573520911
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 212.40891309574118,
   "TT": 587.2364311951687,
   "C": 0.32951343119491994,
   "Cr": 0.6996154069060069
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 411.65804992363815,
   "TT": 449.0965115002039,
   "C": 0.38456661750248056,
   "Cr": 0.37339606448461343
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 326.3199418625786,
   "TT": 233.27115947228415,
   "C": 0.5224583900907969,
   "Cr": 0.42932491862250827
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 61.79785708794645,
   "TT": 615.1607646061391,
   "C": 0.4394941840389728,
   "Cr": 0.7278898187619127
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 280.57433444592976,
   "TT": 440.08009604945863,
   "C": 0.287641323701056,
   "Cr": 0.9146245458351883
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 205.97078636276495,
   "TT": 636.7422448998827,
   "C": 0.46189475575168226,
   "Cr": 0.9941312433312027
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 402.7769259431475,
   "TT": 689,
   "C": 0.6176930098461457,
   "Cr": 6.17
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 147.8095114669993,
   "TT": 335.1672392727164,
   "C": 7.63,
   "Cr": 0.962769709405344
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Ct": 13.048710172821938,
   "TT": 171.17728196706327,
   "C": 7.63,
   "Cr": 11.17
}'
echo -e ""
