echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 488.2038427116596,
   "Blast_Furnace_Slag": 22.210743491005218,
   "Water": 199.9301351260168,
   "Superplasticizer": 28.12664680132597,
   "Age": 97.8510272861742
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 405.34956533674364,
   "Blast_Furnace_Slag": 212.38944729273894,
   "Water": 137.58382708870016,
   "Superplasticizer": 15.983648651414008,
   "Age": 239.31949480862323
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 521.7617000478093,
   "Blast_Furnace_Slag": 191.08328351463274,
   "Water": 135.8305905014196,
   "Superplasticizer": 0.03960715032852751,
   "Age": 75.4910588123166
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 340.83406433248797,
   "Blast_Furnace_Slag": 99.79077675774518,
   "Water": 213.46654440718623,
   "Superplasticizer": 6.993865597215863,
   "Age": 182.1824266687625
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 508.70683389273574,
   "Blast_Furnace_Slag": 19.796412341607954,
   "Water": 216.35903157142164,
   "Superplasticizer": 5.024447629187097,
   "Age": 62.87702995482024
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 298.396891475445,
   "Blast_Furnace_Slag": 327.4969464103413,
   "Water": 170.85627495914449,
   "Superplasticizer": 30.644168063276314,
   "Age": 26.325979947276334
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 456.69987259364103,
   "Blast_Furnace_Slag": 201.08833484871175,
   "Water": 136.91309758070247,
   "Superplasticizer": 17.634000680832216,
   "Age": 167.52121303628988
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 197.3735794032907,
   "Blast_Furnace_Slag": 53.53190586436048,
   "Water": 236.87736518902648,
   "Superplasticizer": 16.24477431283537,
   "Age": 25.145189831699675
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 146.55280043648548,
   "Blast_Furnace_Slag": 241.60456428582884,
   "Water": 187.89214331525486,
   "Superplasticizer": 5.465318946232847,
   "Age": 151.53116981169487
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 367.5800191186406,
   "Blast_Furnace_Slag": 277.66583702421246,
   "Water": 210.24123997467666,
   "Superplasticizer": 29.616487989750645,
   "Age": 256.8339543018334
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 312.55152412514644,
   "Blast_Furnace_Slag": 366.4,
   "Water": 256.0,
   "Superplasticizer": 7.2292569778879106,
   "Age": 371
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 546.0,
   "Blast_Furnace_Slag": 32.83810878352961,
   "Water": 248.0,
   "Superplasticizer": 31.770244534093948,
   "Age": 373
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 549.0,
   "Blast_Furnace_Slag": 363.4,
   "Water": 140.1058764985055,
   "Superplasticizer": 38.2,
   "Age": 172.2312299775774
}'
echo -e ""
