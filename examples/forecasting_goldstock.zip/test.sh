echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1417.7739109665881,
   "Low_t_3": 1416.5862596157453,
   "Close_t_1": 1371.8750067177841,
   "High_t_1": 1732.6437443039706,
   "Low_t_1": 2040.881360523392
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1554.4217582461442,
   "Low_t_3": 1989.3350100455914,
   "Close_t_1": 1551.5701314028252,
   "High_t_1": 1279.2976681966804,
   "Low_t_1": 1426.885403039212
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 2003.8290435313227,
   "Low_t_3": 1771.6979439521251,
   "Close_t_1": 1079.3210101772113,
   "High_t_1": 2047.64763139547,
   "Low_t_1": 1428.910033949076
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1214.6863359994209,
   "Low_t_3": 1350.558195482108,
   "Close_t_1": 1318.5437983010095,
   "High_t_1": 1532.5464812188711,
   "Low_t_1": 1145.9991941604578
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1582.6890227584001,
   "Low_t_3": 1586.1002415134926,
   "Close_t_1": 1278.8389791054597,
   "High_t_1": 1753.7773505521686,
   "Low_t_1": 1448.218053228561
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1918.773609160137,
   "Low_t_3": 1102.2813040909418,
   "Close_t_1": 1138.9522285701842,
   "High_t_1": 1940.3817522148652,
   "Low_t_1": 1164.348350353051
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1086.8480188883093,
   "Low_t_3": 1460.7349765882404,
   "Close_t_1": 1652.4785436080635,
   "High_t_1": 1309.0967583465388,
   "Low_t_1": 2008.3935218248726
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1766.300023791321,
   "Low_t_3": 1423.2777772403497,
   "Close_t_1": 1452.6048942882296,
   "High_t_1": 1350.1846862659706,
   "Low_t_1": 1496.8620134443756
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1611.8362531543444,
   "Low_t_3": 1572.377119116919,
   "Close_t_1": 1984.3131309626747,
   "High_t_1": 1403.2356489962249,
   "Low_t_1": 1230.6154994462552
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1120.6977766853902,
   "Low_t_3": 1596.4696166673766,
   "Close_t_1": 1165.742673902608,
   "High_t_1": 1892.7237617175765,
   "Low_t_1": 1326.4074765939217
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1287.709824731247,
   "Low_t_3": 1682.1465843819715,
   "Close_t_1": 1432.4415339188176,
   "High_t_1": 2032.9090869843608,
   "Low_t_1": 1647.6069562664718
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1298.6719003035669,
   "Low_t_3": 1240.1972781777285,
   "Close_t_1": 1450.1642259970292,
   "High_t_1": 1549.006221476515,
   "Low_t_1": 1244.8602914673243
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 2029.718514992245,
   "Low_t_3": 1484.4106657897514,
   "Close_t_1": 1137.2313058168759,
   "High_t_1": 1219.8267728502924,
   "Low_t_1": 1603.7934785663347
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1289.0512225107475,
   "Low_t_3": 1549.9644481310354,
   "Close_t_1": 1905.3767900989365,
   "High_t_1": 1496.239950528011,
   "Low_t_1": 1571.544372168321
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1196.2244256716203,
   "Low_t_3": 1716.4175937809807,
   "Close_t_1": 1477.5937746724312,
   "High_t_1": 2041.0331535213008,
   "Low_t_1": 2017.7812348717823
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1563.7697428034503,
   "Low_t_3": 1671.9405506499475,
   "Close_t_1": 1640.1565010535232,
   "High_t_1": 1288.2989599814416,
   "Low_t_1": 1134.1169894555546
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1363.8342842623704,
   "Low_t_3": 1599.041011269995,
   "Close_t_1": 1684.7745500036126,
   "High_t_1": 1212.5378040812777,
   "Low_t_1": 1596.8937947068612
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1176.144134726373,
   "Low_t_3": 1853.7455088395438,
   "Close_t_1": 1684.704072362042,
   "High_t_1": 1801.0837129877755,
   "Low_t_1": 1188.999964491898
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1195.4471554567783,
   "Low_t_3": 1453.237387322159,
   "Close_t_1": 1393.3043492068227,
   "High_t_1": 1378.0347771442305,
   "Low_t_1": 1337.9250308620212
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1121.6962839669457,
   "Low_t_3": 1718.7969410389708,
   "Close_t_1": 1934.8977402551923,
   "High_t_1": 1346.338118545442,
   "Low_t_1": 1551.7464719492955
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 1425.3722975137325,
   "Low_t_3": 2076.6,
   "Close_t_1": 1983.430291183045,
   "High_t_1": 2104.2,
   "Low_t_1": 2082.6
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 2104.2,
   "Low_t_3": 1635.3821195056366,
   "Close_t_1": 2102.1,
   "High_t_1": 1402.3010794410313,
   "Low_t_1": 1316.9813097836425
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_4": 2101.2,
   "Low_t_3": 1653.4151091431766,
   "Close_t_1": 2096.1,
   "High_t_1": 2107.2,
   "Low_t_1": 1084.9264674904991
}'
echo -e ""
