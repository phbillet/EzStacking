echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1172.2591529513143,
   "Close_t_1": 1510.8208449267663,
   "Open_t_1": 1968.0469252639855,
   "High_t_1": 1566.545766330419,
   "Low_t_1": 1762.5843845445017
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 2049.2113114912704,
   "Close_t_1": 1536.4958077440458,
   "Open_t_1": 1234.2375873895417,
   "High_t_1": 1845.9273509678526,
   "Low_t_1": 1677.5627181038833
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1191.3764861395393,
   "Close_t_1": 1975.2213195456097,
   "Open_t_1": 1242.917478272017,
   "High_t_1": 1354.27919327366,
   "Low_t_1": 1452.5972352880685
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1145.3488263004988,
   "Close_t_1": 1100.879129957471,
   "Open_t_1": 1968.2570884680435,
   "High_t_1": 1941.6631699242764,
   "Low_t_1": 1200.2255767125653
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1373.053597364073,
   "Close_t_1": 1135.5771211207266,
   "Open_t_1": 1869.481044220081,
   "High_t_1": 1599.3823864427304,
   "Low_t_1": 1813.3079102600732
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1236.7345532106433,
   "Close_t_1": 1806.024756640154,
   "Open_t_1": 1710.8723091259078,
   "High_t_1": 1257.973862560234,
   "Low_t_1": 1529.0082258397438
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1428.928292495937,
   "Close_t_1": 1799.8522347867993,
   "Open_t_1": 1654.02858430666,
   "High_t_1": 1212.9728700240628,
   "Low_t_1": 1999.2847980156573
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1796.2238608803468,
   "Close_t_1": 1422.9598102554064,
   "Open_t_1": 2036.9025607673493,
   "High_t_1": 1995.6958313608707,
   "Low_t_1": 1878.9435454307986
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 2042.227146948444,
   "Close_t_1": 1066.8649081390683,
   "Open_t_1": 1300.5521536766153,
   "High_t_1": 1795.3442387931257,
   "Low_t_1": 2051.6453885800656
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1206.6674536209769,
   "Close_t_1": 1131.4048769837143,
   "Open_t_1": 1435.9698802383218,
   "High_t_1": 2041.5201691983407,
   "Low_t_1": 1280.6048983945027
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 2105.2,
   "Close_t_1": 1845.6197069797831,
   "Open_t_1": 2096.4,
   "High_t_1": 1275.5231533147648,
   "Low_t_1": 2081.6
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1131.5919038120653,
   "Close_t_1": 2100.1,
   "Open_t_1": 1324.4987746722231,
   "High_t_1": 2101.2,
   "Low_t_1": 2076.6
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "High_t_3": 1222.9826063612063,
   "Close_t_1": 2097.1,
   "Open_t_1": 2100.4,
   "High_t_1": 1397.8512842265736,
   "Low_t_1": 2084.6
}'
echo -e ""
