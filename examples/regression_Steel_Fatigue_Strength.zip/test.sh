echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 421.4019972156089,
   "Dt": 61.28952199611269,
   "TT": 42.82484738602638,
   "C": 0.2640201422047059,
   "Cr": 1.1438695467078015
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 764.3601084358801,
   "Dt": 51.95753699209186,
   "TT": 98.45294101933423,
   "C": 0.565099796714116,
   "Cr": 0.8649621223974091
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 201.60454506850354,
   "Dt": 0.6221053764958123,
   "TT": 202.5906475569803,
   "C": 0.3699345006700019,
   "Cr": 0.5319251303223915
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 372.84935469993496,
   "Dt": 5.465562960080277,
   "TT": 587.0051287192923,
   "C": 0.22403949883683255,
   "Cr": 0.3915002304144814
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 789.221704323872,
   "Dt": 8.418677060682015,
   "TT": 106.00574951570641,
   "C": 0.420058093715714,
   "Cr": 0.19665510992050464
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 82.86778301535247,
   "Dt": 41.011538463990675,
   "TT": 577.6476674348124,
   "C": 0.5248713035556168,
   "Cr": 0.24991394882181814
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 286.6027605391695,
   "Dt": 55.465976563522325,
   "TT": 84.98611915156462,
   "C": 0.39874045357419297,
   "Cr": 0.04927068709161532
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 442.3626809523473,
   "Dt": 11.34042894778927,
   "TT": 97.1018242422685,
   "C": 0.44492597415673496,
   "Cr": 0.7366307331994739
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 626.121672197404,
   "Dt": 52.750758486574085,
   "TT": 427.1926206279127,
   "C": 0.43079916703403387,
   "Cr": 0.2977556002621943
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 395.08174197175015,
   "Dt": 19.89186595438817,
   "TT": 583.1040374991179,
   "C": 0.40658593179084584,
   "Cr": 0.2590280923629703
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 913.333,
   "Dt": 71.2,
   "TT": 517.0955493596455,
   "C": 2.63,
   "Cr": 3.17
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 913.333,
   "Dt": 74.2,
   "TT": 677.9622474730328,
   "C": 0.5110316760042426,
   "Cr": 5.17
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "DT": 733.1019463091768,
   "Dt": 78.2,
   "TT": 678.3050553404366,
   "C": 9.63,
   "Cr": 3.17
}'
echo -e ""
