echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 0.4083795428020428,
   "phonon_cutoff_frequency": 7.485594435292272,
   "mean_phonon_frequency": 24.29478577852396,
   "electronic_contribution_of_dielectric_constant": 10.934035215331633,
   "total_dielectric_constant": 15.050502196957275,
   "nearest_neighbor_distance": 1.6632892309322072,
   "density": 9.816768317748064,
   "bulk_modulus": 441.1467389919121,
   "structure": "CC",
   "category": "Group_II-VI_semiconductor"
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 12.07618373193483,
   "phonon_cutoff_frequency": 27.64860411504205,
   "mean_phonon_frequency": 22.658503344961247,
   "electronic_contribution_of_dielectric_constant": 19.17755026976644,
   "total_dielectric_constant": 33.70909597778251,
   "nearest_neighbor_distance": 3.4457952175213227,
   "density": 5.06377464349524,
   "bulk_modulus": 230.8260821640595,
   "structure": "CC",
   "category": "Group_IV_semiconductor"
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 6.847871324089179,
   "phonon_cutoff_frequency": 11.145517540914366,
   "mean_phonon_frequency": 15.979942842278373,
   "electronic_contribution_of_dielectric_constant": 19.107118219226148,
   "total_dielectric_constant": 56.00099001224797,
   "nearest_neighbor_distance": 2.5210941878689486,
   "density": 6.861555202578155,
   "bulk_modulus": 369.99172176701245,
   "structure": "CC",
   "category": "Group_II-VI_semiconductor"
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 12.599057501170263,
   "phonon_cutoff_frequency": 20.437146005211545,
   "mean_phonon_frequency": 24.32993223043779,
   "electronic_contribution_of_dielectric_constant": 16.7729715390228,
   "total_dielectric_constant": 4.477311078897853,
   "nearest_neighbor_distance": 2.6968369543324995,
   "density": 5.646577030831569,
   "bulk_modulus": 32.28919355554041,
   "structure": "ZB",
   "category": "Group_III-V_semiconductor"
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 7.0730243021123576,
   "phonon_cutoff_frequency": 33.876898223263815,
   "mean_phonon_frequency": 21.935920106942923,
   "electronic_contribution_of_dielectric_constant": 10.681008154686962,
   "total_dielectric_constant": 9.926690064137329,
   "nearest_neighbor_distance": 3.265115419768696,
   "density": 9.066142046556006,
   "bulk_modulus": 175.15377532678184,
   "structure": "CC",
   "category": "Alkaline_earth_metal_chalcogenides"
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 0.3320921118319851,
   "phonon_cutoff_frequency": 26.501872038176412,
   "mean_phonon_frequency": 27.058790723884538,
   "electronic_contribution_of_dielectric_constant": 11.803572438235271,
   "total_dielectric_constant": 33.517843230403926,
   "nearest_neighbor_distance": 2.586898867926629,
   "density": 3.774796037913101,
   "bulk_modulus": 37.10526142369309,
   "structure": "RS",
   "category": "Post-_transition_metal_halides"
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 7.8111565194477475,
   "phonon_cutoff_frequency": 21.161049001135673,
   "mean_phonon_frequency": 25.166146117488307,
   "electronic_contribution_of_dielectric_constant": 8.244103087318754,
   "total_dielectric_constant": 6.873971818483664,
   "nearest_neighbor_distance": 2.1873593560723243,
   "density": 2.541368851425888,
   "bulk_modulus": 406.1887923062204,
   "structure": "ZB",
   "category": "Group_IV_semiconductor"
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 7.710880840390089,
   "phonon_cutoff_frequency": 7.105688298010415,
   "mean_phonon_frequency": 15.752499149920098,
   "electronic_contribution_of_dielectric_constant": 19.000736010671467,
   "total_dielectric_constant": 7.731261802916593,
   "nearest_neighbor_distance": 2.536575178102759,
   "density": 6.948095550327815,
   "bulk_modulus": 151.3047508998357,
   "structure": "ZB",
   "category": "Alkali_metal_halides"
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 6.225540852914144,
   "phonon_cutoff_frequency": 19.912763366200018,
   "mean_phonon_frequency": 15.602463401528578,
   "electronic_contribution_of_dielectric_constant": 18.03761051027852,
   "total_dielectric_constant": 28.13160024833784,
   "nearest_neighbor_distance": 3.300607378257964,
   "density": 4.860570886153775,
   "bulk_modulus": 241.41923930028833,
   "structure": "CC",
   "category": "Post-_transition_metal_halides"
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 12.713652334119848,
   "phonon_cutoff_frequency": 11.020807685922215,
   "mean_phonon_frequency": 18.413172079424506,
   "electronic_contribution_of_dielectric_constant": 17.357891595837188,
   "total_dielectric_constant": 36.79476760588105,
   "nearest_neighbor_distance": 3.336048443497026,
   "density": 6.877868356091848,
   "bulk_modulus": 63.96399991428676,
   "structure": "RS",
   "category": "Alkaline_earth_metal_chalcogenides"
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 7.764041598909137,
   "phonon_cutoff_frequency": 46.513,
   "mean_phonon_frequency": 8.147108364623627,
   "electronic_contribution_of_dielectric_constant": 2.6451438853267883,
   "total_dielectric_constant": 13.383216863559719,
   "nearest_neighbor_distance": 2.1889842228735614,
   "density": 13.251,
   "bulk_modulus": 220.78205562781457,
   "structure": "tyty",
   "category": "Group_III-V_semiconductor"
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 2.2317460667370996,
   "phonon_cutoff_frequency": 42.513,
   "mean_phonon_frequency": 26.531435655931393,
   "electronic_contribution_of_dielectric_constant": 29.29,
   "total_dielectric_constant": 31.12474361883568,
   "nearest_neighbor_distance": 13.604,
   "density": 7.320143903454969,
   "bulk_modulus": 470.524,
   "structure": "ZB",
   "category": "tete"
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 6.019039049814739,
   "phonon_cutoff_frequency": 50.513,
   "mean_phonon_frequency": 34.674,
   "electronic_contribution_of_dielectric_constant": 25.408751935683036,
   "total_dielectric_constant": 63.213,
   "nearest_neighbor_distance": 2.2112209083820087,
   "density": 17.250999999999998,
   "bulk_modulus": 91.43885582047685,
   "structure": "tata",
   "category": "Group_IV_semiconductor"
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 12.585498561063838,
   "phonon_cutoff_frequency": 48.513,
   "mean_phonon_frequency": 22.630303269937034,
   "electronic_contribution_of_dielectric_constant": 19.15015250250723,
   "total_dielectric_constant": 66.213,
   "nearest_neighbor_distance": 2.2480853826707605,
   "density": 17.250999999999998,
   "bulk_modulus": 40.64359531961752,
   "structure": "tata",
   "category": "Transition_metal_oxide"
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 17.6,
   "phonon_cutoff_frequency": 30.003529075689908,
   "mean_phonon_frequency": 37.674,
   "electronic_contribution_of_dielectric_constant": 34.29,
   "total_dielectric_constant": 49.18453529770215,
   "nearest_neighbor_distance": 7.604,
   "density": 9.898267164752117,
   "bulk_modulus": 469.524,
   "structure": "CC",
   "category": "toto"
}'
echo -e ""
echo -e "Test KO: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 1.8221053183213984,
   "phonon_cutoff_frequency": 14.917893432986528,
   "mean_phonon_frequency": 38.674,
   "electronic_contribution_of_dielectric_constant": 14.532427043765603,
   "total_dielectric_constant": 63.213,
   "nearest_neighbor_distance": 2.216892286341789,
   "density": 16.250999999999998,
   "bulk_modulus": 345.0205135490186,
   "structure": "toto",
   "category": "Group_IV_semiconductor"
}'
echo -e ""
echo -e "Test KO: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 18.6,
   "phonon_cutoff_frequency": 26.182000645679345,
   "mean_phonon_frequency": 32.674,
   "electronic_contribution_of_dielectric_constant": 31.29,
   "total_dielectric_constant": 66.213,
   "nearest_neighbor_distance": 9.604,
   "density": 9.502946183563967,
   "bulk_modulus": 25.82191896084675,
   "structure": "tata",
   "category": "tata"
}'
echo -e ""
echo -e "Test KO: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 7.022817965311469,
   "phonon_cutoff_frequency": 47.513,
   "mean_phonon_frequency": 9.728508594066867,
   "electronic_contribution_of_dielectric_constant": 19.04657941949391,
   "total_dielectric_constant": 64.213,
   "nearest_neighbor_distance": 3.4483021391646846,
   "density": 4.141435467988925,
   "bulk_modulus": 83.33444262014106,
   "structure": "tyty",
   "category": "Transition_metal_halides"
}'
echo -e ""
echo -e "Test KO: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 21.6,
   "phonon_cutoff_frequency": 49.513,
   "mean_phonon_frequency": 14.808434226910602,
   "electronic_contribution_of_dielectric_constant": 7.260207246876294,
   "total_dielectric_constant": 67.213,
   "nearest_neighbor_distance": 2.293511789075776,
   "density": 5.9807594634814,
   "bulk_modulus": 242.0353173918512,
   "structure": "ZB",
   "category": "titi"
}'
echo -e ""
echo -e "Test KO: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "experimental_band_gap": 5.05817329963882,
   "phonon_cutoff_frequency": 42.513,
   "mean_phonon_frequency": 7.835179516032586,
   "electronic_contribution_of_dielectric_constant": 29.29,
   "total_dielectric_constant": 15.329163047814932,
   "nearest_neighbor_distance": 12.604,
   "density": 13.251,
   "bulk_modulus": 466.524,
   "structure": "tutu",
   "category": "tutu"
}'
echo -e ""
