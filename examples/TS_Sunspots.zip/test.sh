echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 203.85095035887517,
   "Total_Sunspot_Number_t_3": 286.85150257437215,
   "Total_Sunspot_Number_t_2": 53.50531294609414,
   "Total_Sunspot_Number_t_1": 87.27701592028947
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 200.77020411998205,
   "Total_Sunspot_Number_t_3": 315.1573847408673,
   "Total_Sunspot_Number_t_2": 219.29089019069116,
   "Total_Sunspot_Number_t_1": 133.07176497567517
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 223.95821841130413,
   "Total_Sunspot_Number_t_3": 114.17323272899222,
   "Total_Sunspot_Number_t_2": 77.46958380726288,
   "Total_Sunspot_Number_t_1": 396.256916546421
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 236.0598226939516,
   "Total_Sunspot_Number_t_3": 384.42915155416216,
   "Total_Sunspot_Number_t_2": 69.16807182143914,
   "Total_Sunspot_Number_t_1": 240.51899989152253
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 327.7804829327894,
   "Total_Sunspot_Number_t_3": 229.19451669939,
   "Total_Sunspot_Number_t_2": 236.21150493373162,
   "Total_Sunspot_Number_t_1": 313.2667020870983
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 325.94461911442676,
   "Total_Sunspot_Number_t_3": 315.37770779642983,
   "Total_Sunspot_Number_t_2": 219.2862545048296,
   "Total_Sunspot_Number_t_1": 157.5790275339369
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 230.94412694074757,
   "Total_Sunspot_Number_t_3": 155.04357819155246,
   "Total_Sunspot_Number_t_2": 159.35576360811888,
   "Total_Sunspot_Number_t_1": 341.2096213111235
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 150.8029844559585,
   "Total_Sunspot_Number_t_3": 354.46829688986276,
   "Total_Sunspot_Number_t_2": 46.784891833131184,
   "Total_Sunspot_Number_t_1": 14.001759997974736
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 342.4615896824729,
   "Total_Sunspot_Number_t_3": 344.768389981048,
   "Total_Sunspot_Number_t_2": 113.69670804139311,
   "Total_Sunspot_Number_t_1": 391.600942331081
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 263.0576677508232,
   "Total_Sunspot_Number_t_3": 12.673682947231576,
   "Total_Sunspot_Number_t_2": 200.38425568468688,
   "Total_Sunspot_Number_t_1": 282.63811481071434
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 401.2,
   "Total_Sunspot_Number_t_3": 275.7455559241272,
   "Total_Sunspot_Number_t_2": 403.2,
   "Total_Sunspot_Number_t_1": 342.49663979267007
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 408.2,
   "Total_Sunspot_Number_t_3": 405.2,
   "Total_Sunspot_Number_t_2": 355.98448873545016,
   "Total_Sunspot_Number_t_1": 406.2
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Total_Sunspot_Number_t_4": 405.2,
   "Total_Sunspot_Number_t_3": 154.471794972914,
   "Total_Sunspot_Number_t_2": 403.2,
   "Total_Sunspot_Number_t_1": 145.07664883737618
}'
echo -e ""
