echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 116394.5713045461,
   "MGR_ID": 304789.5503352045,
   "ROLE_ROLLUP_1": 260653.774144305,
   "ROLE_ROLLUP_2": 143753.61601471115,
   "ROLE_DEPTNAME": 75251.63427478625,
   "ROLE_TITLE": 148533.71861365382,
   "ROLE_FAMILY_DESC": 160877.2152750113,
   "ROLE_FAMILY": 114457.06801336767,
   "ROLE_CODE": 249394.02019612087
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 128261.25256762184,
   "MGR_ID": 37510.57782546603,
   "ROLE_ROLLUP_1": 158871.53796979753,
   "ROLE_ROLLUP_2": 101578.25969941195,
   "ROLE_DEPTNAME": 139419.36523635322,
   "ROLE_TITLE": 190261.40629635757,
   "ROLE_FAMILY_DESC": 205823.27329488075,
   "ROLE_FAMILY": 154782.45476081033,
   "ROLE_CODE": 239603.96784212883
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 240591.56488210827,
   "MGR_ID": 258364.56956913535,
   "ROLE_ROLLUP_1": 213792.5810991955,
   "ROLE_ROLLUP_2": 236941.9920103931,
   "ROLE_DEPTNAME": 108300.71667859069,
   "ROLE_TITLE": 190930.2442282226,
   "ROLE_FAMILY_DESC": 269769.71852497006,
   "ROLE_FAMILY": 86393.16855282587,
   "ROLE_CODE": 157576.5299489533
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 224007.43759343747,
   "MGR_ID": 47253.178735916095,
   "ROLE_ROLLUP_1": 304860.50178440864,
   "ROLE_ROLLUP_2": 286791,
   "ROLE_DEPTNAME": 206936.53727086898,
   "ROLE_TITLE": 311868,
   "ROLE_FAMILY_DESC": 173299.98133335795,
   "ROLE_FAMILY": 308578,
   "ROLE_CODE": 181493.7169981748
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 188138.50614285585,
   "MGR_ID": 311696,
   "ROLE_ROLLUP_1": 311188,
   "ROLE_ROLLUP_2": 161607.09580399294,
   "ROLE_DEPTNAME": 239629.34128368853,
   "ROLE_TITLE": 273550.1889495343,
   "ROLE_FAMILY_DESC": 311877,
   "ROLE_FAMILY": 298039.7816319425,
   "ROLE_CODE": 270695
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 82699.94436573067,
   "MGR_ID": 311706,
   "ROLE_ROLLUP_1": 88517.57938115907,
   "ROLE_ROLLUP_2": 160156.02688920195,
   "ROLE_DEPTNAME": 286793,
   "ROLE_TITLE": 311869,
   "ROLE_FAMILY_DESC": 311867,
   "ROLE_FAMILY": 216210.70681795324,
   "ROLE_CODE": 270696
}'
echo -e ""
