echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 399.49057581959823,
   "Blast_Furnace_Slag": 233.84374384095446,
   "Water": 193.9605144687816,
   "Superplasticizer": 2.579557048761659,
   "Age": 54.034533902009635
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 531.1865421135174,
   "Blast_Furnace_Slag": 7.448077877844094,
   "Water": 161.41533985857242,
   "Superplasticizer": 18.073579414424444,
   "Age": 163.0365529546844
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 208.40676596021558,
   "Blast_Furnace_Slag": 217.22406531127106,
   "Water": 144.60259368425505,
   "Superplasticizer": 30.631215266397604,
   "Age": 89.12045019435281
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 138.90400493140143,
   "Blast_Furnace_Slag": 15.233824752007004,
   "Water": 179.49214307266067,
   "Superplasticizer": 24.221992188323494,
   "Age": 291.1111270897279
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 118.47792668673618,
   "Blast_Furnace_Slag": 133.61527208194454,
   "Water": 128.51327410660195,
   "Superplasticizer": 16.1297733768866,
   "Age": 197.32114275982755
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 181.25442008949915,
   "Blast_Furnace_Slag": 140.11181252675186,
   "Water": 153.4363337885244,
   "Superplasticizer": 5.379783544753611,
   "Age": 350.0615161989755
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 171.17484427261158,
   "Blast_Furnace_Slag": 185.560896599711,
   "Water": 143.45355374687458,
   "Superplasticizer": 21.850079995033674,
   "Age": 8.130548608021503
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 173.30041802644894,
   "Blast_Furnace_Slag": 336.1778253396724,
   "Water": 239.9840876908539,
   "Superplasticizer": 27.26936048809729,
   "Age": 186.17185640204576
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 161.37294958016824,
   "Blast_Furnace_Slag": 336.8896602894554,
   "Water": 183.84642922509647,
   "Superplasticizer": 11.15561571009993,
   "Age": 63.09413563950598
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 484.6115565482193,
   "Blast_Furnace_Slag": 28.926142344187927,
   "Water": 182.5501488935331,
   "Superplasticizer": 18.94157257069538,
   "Age": 285.22915301235764
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 547.0,
   "Blast_Furnace_Slag": 331.52932589547083,
   "Water": 183.20120233615435,
   "Superplasticizer": 35.2,
   "Age": 168.62383515376612
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 429.2937173074961,
   "Blast_Furnace_Slag": 369.4,
   "Water": 251.0,
   "Superplasticizer": 35.2,
   "Age": 305.59108411485977
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Cement": 182.96464077970745,
   "Blast_Furnace_Slag": 127.27952615467862,
   "Water": 250.0,
   "Superplasticizer": 28.976436591845175,
   "Age": 374
}'
echo -e ""
