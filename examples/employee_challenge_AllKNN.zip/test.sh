echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 71189.1208191619,
   "MGR_ID": 74443.5783241453,
   "ROLE_ROLLUP_1": 190750.4016519491,
   "ROLE_ROLLUP_2": 259026.4289857535,
   "ROLE_DEPTNAME": 255476.3502900643,
   "ROLE_TITLE": 235177.09413220006,
   "ROLE_FAMILY_DESC": 35173.594413468425,
   "ROLE_FAMILY": 179359.87820314904,
   "ROLE_CODE": 155812.78866390768
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 42531.856583966786,
   "MGR_ID": 9757.017766774106,
   "ROLE_ROLLUP_1": 55749.85801631995,
   "ROLE_ROLLUP_2": 103152.41537561077,
   "ROLE_DEPTNAME": 261891.76288460783,
   "ROLE_TITLE": 197475.65457718307,
   "ROLE_FAMILY_DESC": 65599.49645309342,
   "ROLE_FAMILY": 102384.98964911023,
   "ROLE_CODE": 180088.53269459342
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 247123.59241709462,
   "MGR_ID": 222161.9139811355,
   "ROLE_ROLLUP_1": 235773.06361323214,
   "ROLE_ROLLUP_2": 286711.7876923206,
   "ROLE_DEPTNAME": 267215.1628457542,
   "ROLE_TITLE": 280979.2116531874,
   "ROLE_FAMILY_DESC": 143580.91993781144,
   "ROLE_FAMILY": 34214.38989566766,
   "ROLE_CODE": 180228.59939602774
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 241350.60660854052,
   "MGR_ID": 241217.94300118406,
   "ROLE_ROLLUP_1": 125398.67271562878,
   "ROLE_ROLLUP_2": 37108.189045411236,
   "ROLE_DEPTNAME": 230946.0574247603,
   "ROLE_TITLE": 156479.69889207138,
   "ROLE_FAMILY_DESC": 178743.17670876416,
   "ROLE_FAMILY": 266003.0270452216,
   "ROLE_CODE": 201208.25642581345
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 299097.8855448316,
   "MGR_ID": 5746.215148316139,
   "ROLE_ROLLUP_1": 222909.76754681647,
   "ROLE_ROLLUP_2": 134046.54628969106,
   "ROLE_DEPTNAME": 244140.31755148142,
   "ROLE_TITLE": 265161.60242705967,
   "ROLE_FAMILY_DESC": 45295.410911700565,
   "ROLE_FAMILY": 294792.6751233672,
   "ROLE_CODE": 262950.4981306253
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 37031.90392490415,
   "MGR_ID": 281759.7611407327,
   "ROLE_ROLLUP_1": 10654.236056014026,
   "ROLE_ROLLUP_2": 90165.07094111682,
   "ROLE_DEPTNAME": 193431.02832295743,
   "ROLE_TITLE": 249508.37094582574,
   "ROLE_FAMILY_DESC": 197660.68282115608,
   "ROLE_FAMILY": 192017.2071110005,
   "ROLE_CODE": 252131.40789262395
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 104013.275625987,
   "MGR_ID": 64134.709856643814,
   "ROLE_ROLLUP_1": 84531.85634077525,
   "ROLE_ROLLUP_2": 201485.94939330695,
   "ROLE_DEPTNAME": 276823.82418094436,
   "ROLE_TITLE": 236451.80707280827,
   "ROLE_FAMILY_DESC": 146191.40322626385,
   "ROLE_FAMILY": 153129.46826484613,
   "ROLE_CODE": 214561.79704367265
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 234807.08077637118,
   "MGR_ID": 188272.32234710638,
   "ROLE_ROLLUP_1": 253296.13952400687,
   "ROLE_ROLLUP_2": 24405.286600807016,
   "ROLE_DEPTNAME": 78981.6888296888,
   "ROLE_TITLE": 276622.58683262265,
   "ROLE_FAMILY_DESC": 43111.01854713105,
   "ROLE_FAMILY": 248003.57974268586,
   "ROLE_CODE": 226810.18407481257
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 20595.762981032134,
   "MGR_ID": 194125.80555144575,
   "ROLE_ROLLUP_1": 66768.66996729907,
   "ROLE_ROLLUP_2": 103767.08751705363,
   "ROLE_DEPTNAME": 220773.2078135969,
   "ROLE_TITLE": 242430.64830407407,
   "ROLE_FAMILY_DESC": 281776.6660862809,
   "ROLE_FAMILY": 212612.06353841713,
   "ROLE_CODE": 203207.9292572954
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 16162.814287978033,
   "MGR_ID": 78203.02093737815,
   "ROLE_ROLLUP_1": 25866.69313366147,
   "ROLE_ROLLUP_2": 79119.256372062,
   "ROLE_DEPTNAME": 128104.56991686803,
   "ROLE_TITLE": 259023.77044330313,
   "ROLE_FAMILY_DESC": 127379.6925820479,
   "ROLE_FAMILY": 236696.7106677677,
   "ROLE_CODE": 236399.99733783398
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 312154,
   "MGR_ID": 280835.1696460084,
   "ROLE_ROLLUP_1": 311187,
   "ROLE_ROLLUP_2": 31622.248847045685,
   "ROLE_DEPTNAME": 286795,
   "ROLE_TITLE": 311867,
   "ROLE_FAMILY_DESC": 190645.02025179288,
   "ROLE_FAMILY": 73400.43802610744,
   "ROLE_CODE": 186145.77293176946
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 5985.257965542392,
   "MGR_ID": 311698,
   "ROLE_ROLLUP_1": 141537.37590304782,
   "ROLE_ROLLUP_2": 286795,
   "ROLE_DEPTNAME": 33744.12308449839,
   "ROLE_TITLE": 311867,
   "ROLE_FAMILY_DESC": 123355.39423278152,
   "ROLE_FAMILY": 308580,
   "ROLE_CODE": 270697
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 16536.56414356386,
   "MGR_ID": 311705,
   "ROLE_ROLLUP_1": 81078.10801434201,
   "ROLE_ROLLUP_2": 286801,
   "ROLE_DEPTNAME": 148185.81739206697,
   "ROLE_TITLE": 278508.9176868287,
   "ROLE_FAMILY_DESC": 311868,
   "ROLE_FAMILY": 179725.52593688545,
   "ROLE_CODE": 169944.48429772106
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 181897.00941767855,
   "MGR_ID": 311704,
   "ROLE_ROLLUP_1": 17673.630513218603,
   "ROLE_ROLLUP_2": 286796,
   "ROLE_DEPTNAME": 220309.30137034785,
   "ROLE_TITLE": 311867,
   "ROLE_FAMILY_DESC": 311875,
   "ROLE_FAMILY": 308581,
   "ROLE_CODE": 226236.45096392484
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 146665.08532292946,
   "MGR_ID": 311699,
   "ROLE_ROLLUP_1": 170061.0912266173,
   "ROLE_ROLLUP_2": 286799,
   "ROLE_DEPTNAME": 110339.57685754941,
   "ROLE_TITLE": 311870,
   "ROLE_FAMILY_DESC": 143195.1474519922,
   "ROLE_FAMILY": 28174.684246585664,
   "ROLE_CODE": 270691
}'
echo -e ""
echo -e "Test KO: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 312159,
   "MGR_ID": 58269.68927840701,
   "ROLE_ROLLUP_1": 311184,
   "ROLE_ROLLUP_2": 242680.04646797985,
   "ROLE_DEPTNAME": 11400.776389463615,
   "ROLE_TITLE": 311871,
   "ROLE_FAMILY_DESC": 311869,
   "ROLE_FAMILY": 101385.53790033085,
   "ROLE_CODE": 270698
}'
echo -e ""
echo -e "Test KO: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 312160,
   "MGR_ID": 96747.49762475904,
   "ROLE_ROLLUP_1": 311181,
   "ROLE_ROLLUP_2": 59173.31268806051,
   "ROLE_DEPTNAME": 286801,
   "ROLE_TITLE": 168894.69307957764,
   "ROLE_FAMILY_DESC": 311872,
   "ROLE_FAMILY": 186877.55909340517,
   "ROLE_CODE": 270692
}'
echo -e ""
echo -e "Test KO: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 312162,
   "MGR_ID": 200265.85812121592,
   "ROLE_ROLLUP_1": 311181,
   "ROLE_ROLLUP_2": 151409.70865959884,
   "ROLE_DEPTNAME": 286798,
   "ROLE_TITLE": 197406.35280678142,
   "ROLE_FAMILY_DESC": 311874,
   "ROLE_FAMILY": 61459.31855947299,
   "ROLE_CODE": 270691
}'
echo -e ""
echo -e "Test KO: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 305636.53924547014,
   "MGR_ID": 77793.52219576469,
   "ROLE_ROLLUP_1": 15278.776694728833,
   "ROLE_ROLLUP_2": 286794,
   "ROLE_DEPTNAME": 286801,
   "ROLE_TITLE": 261536.66987076856,
   "ROLE_FAMILY_DESC": 229314.12596529373,
   "ROLE_FAMILY": 186519.70977914493,
   "ROLE_CODE": 270693
}'
echo -e ""
echo -e "Test KO: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "RESOURCE": 123976.63499562758,
   "MGR_ID": 256719.37816538676,
   "ROLE_ROLLUP_1": 311182,
   "ROLE_ROLLUP_2": 189812.3513111519,
   "ROLE_DEPTNAME": 286801,
   "ROLE_TITLE": 165090.77645302948,
   "ROLE_FAMILY_DESC": 311874,
   "ROLE_FAMILY": 184306.76635338934,
   "ROLE_CODE": 270701
}'
echo -e ""
