echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.426479777337526,
   "sepal_width": 4.020967358074785,
   "petal_length": 6.3195722519412865,
   "petal_width": 0.5632310078961181
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.678180633504522,
   "sepal_width": 3.799844518686048,
   "petal_length": 2.069985471153064,
   "petal_width": 0.28963670755190946
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.949422510427786,
   "sepal_width": 3.473145109134486,
   "petal_length": 4.603866962211117,
   "petal_width": 1.587435124934471
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.926189656617988,
   "sepal_width": 3.269883724008702,
   "petal_length": 5.1502546324222385,
   "petal_width": 1.7447233878625594
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.308631273190649,
   "sepal_width": 2.038937410624274,
   "petal_length": 5.392496913648986,
   "petal_width": 1.8769398710593743
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 4.326042099140095,
   "sepal_width": 2.5215734540845545,
   "petal_length": 3.2871194082846285,
   "petal_width": 0.5875845568558921
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 7.540641394017895,
   "sepal_width": 3.3992172240977903,
   "petal_length": 2.619151437525338,
   "petal_width": 1.8558982537321935
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.137840305796144,
   "sepal_width": 4.280557837577536,
   "petal_length": 4.6369581125369805,
   "petal_width": 2.1894137701685854
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.704011160736198,
   "sepal_width": 3.6146448572803753,
   "petal_length": 6.431210059457137,
   "petal_width": 1.326179512909438
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.670908502239252,
   "sepal_width": 4.286917082689117,
   "petal_length": 4.581125480452069,
   "petal_width": 1.8979170609328
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 9.9,
   "sepal_width": 2.0206819300849936,
   "petal_length": 13.9,
   "petal_width": 0.35268989973211184
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 12.9,
   "sepal_width": 2.739534595072649,
   "petal_length": 15.9,
   "petal_width": 1.8262381560524734
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 15.9,
   "sepal_width": 2.2923307263708663,
   "petal_length": 3.6359668073628275,
   "petal_width": 6.5
}'
echo -e ""
