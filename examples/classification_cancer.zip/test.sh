echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "8",
   "Passive_Smoker": "3",
   "Wheezing": "7",
   "Clubbing_of_Finger_Nails": "4",
   "Snoring": "7"
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "2",
   "Passive_Smoker": "3",
   "Wheezing": "8",
   "Clubbing_of_Finger_Nails": "6",
   "Snoring": "5"
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "7",
   "Passive_Smoker": "4",
   "Wheezing": "7",
   "Clubbing_of_Finger_Nails": "3",
   "Snoring": "3"
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "4",
   "Passive_Smoker": "2",
   "Wheezing": "5",
   "Clubbing_of_Finger_Nails": "1",
   "Snoring": "3"
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "5",
   "Passive_Smoker": "4",
   "Wheezing": "6",
   "Clubbing_of_Finger_Nails": "2",
   "Snoring": "7"
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "6",
   "Passive_Smoker": "7",
   "Wheezing": "2",
   "Clubbing_of_Finger_Nails": "4",
   "Snoring": "7"
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "2",
   "Passive_Smoker": "2",
   "Wheezing": "8",
   "Clubbing_of_Finger_Nails": "5",
   "Snoring": "5"
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "1",
   "Passive_Smoker": "7",
   "Wheezing": "5",
   "Clubbing_of_Finger_Nails": "4",
   "Snoring": "2"
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "7",
   "Passive_Smoker": "7",
   "Wheezing": "8",
   "Clubbing_of_Finger_Nails": "1",
   "Snoring": "7"
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "8",
   "Passive_Smoker": "3",
   "Wheezing": "8",
   "Clubbing_of_Finger_Nails": "4",
   "Snoring": "1"
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "8",
   "Passive_Smoker": "toto",
   "Wheezing": "tutu",
   "Clubbing_of_Finger_Nails": "5",
   "Snoring": "tyty"
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "8",
   "Passive_Smoker": "toto",
   "Wheezing": "3",
   "Clubbing_of_Finger_Nails": "tyty",
   "Snoring": "toto"
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Smoking": "8",
   "Passive_Smoker": "titi",
   "Wheezing": "tutu",
   "Clubbing_of_Finger_Nails": "7",
   "Snoring": "tata"
}'
echo -e ""
