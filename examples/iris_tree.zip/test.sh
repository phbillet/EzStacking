echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.687028816201645,
   "sepal_width": 3.43875246938768,
   "petal_length": 6.316356364704831,
   "petal_width": 0.4440332796069648
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.0257952936166355,
   "sepal_width": 3.7531000454785604,
   "petal_length": 4.602010170949088,
   "petal_width": 0.8745975384310722
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.506521988183257,
   "sepal_width": 3.245612842135845,
   "petal_length": 1.1000223617858036,
   "petal_width": 0.7830686267748561
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 11.9,
   "sepal_width": 3.515387022643761,
   "petal_length": 9.9,
   "petal_width": 3.5
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.51098135380669,
   "sepal_width": 12.4,
   "petal_length": 9.9,
   "petal_width": 1.2281462957333191
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.227810590835939,
   "sepal_width": 13.4,
   "petal_length": 3.419701201281059,
   "petal_width": 2.5
}'
echo -e ""
