echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "2",
   "sibsp": 5.928433903910603,
   "embarked": "S",
   "cabin_class": "First",
   "who": "woman"
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "3",
   "sibsp": 3.8766605804333736,
   "embarked": "Q",
   "cabin_class": "Second",
   "who": "woman"
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "1",
   "sibsp": 0.15020458902399536,
   "embarked": "Q",
   "cabin_class": "Third",
   "who": "man"
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "2",
   "sibsp": 3.460882278894994,
   "embarked": "Q",
   "cabin_class": "Third",
   "who": "child"
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "3",
   "sibsp": 2.503646675686058,
   "embarked": "S",
   "cabin_class": "Third",
   "who": "man"
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "2",
   "sibsp": 4.017888175163239,
   "embarked": "S",
   "cabin_class": "Third",
   "who": "woman"
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "1",
   "sibsp": 1.7159686711501987,
   "embarked": "C",
   "cabin_class": "Second",
   "who": "woman"
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "1",
   "sibsp": 3.9923573482312165,
   "embarked": "C",
   "cabin_class": "Second",
   "who": "woman"
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "3",
   "sibsp": 0.8243425001079396,
   "embarked": "S",
   "cabin_class": "Second",
   "who": "man"
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "3",
   "sibsp": 5.589092862005745,
   "embarked": "Q",
   "cabin_class": "Third",
   "who": "man"
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "2",
   "sibsp": 6.757677036076324,
   "embarked": "Q",
   "cabin_class": "Third",
   "who": "man"
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "2",
   "sibsp": 6.423967450208456,
   "embarked": "C",
   "cabin_class": "Third",
   "who": "child"
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "2",
   "sibsp": 6.146024825919839,
   "embarked": "S",
   "cabin_class": "First",
   "who": "man"
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "1",
   "sibsp": 5.005603449510796,
   "embarked": "C",
   "cabin_class": "Second",
   "who": "man"
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "1",
   "sibsp": 7.934809791249725,
   "embarked": "C",
   "cabin_class": "Third",
   "who": "woman"
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "3",
   "sibsp": 3.6619711648269586,
   "embarked": "tyty",
   "cabin_class": "Third",
   "who": "toto"
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "2",
   "sibsp": 14,
   "embarked": "Q",
   "cabin_class": "Second",
   "who": "tete"
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "1",
   "sibsp": 0.9769563319882044,
   "embarked": "tutu",
   "cabin_class": "First",
   "who": "tyty"
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "3",
   "sibsp": 15,
   "embarked": "Q",
   "cabin_class": "toto",
   "who": "titi"
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "pclass": "2",
   "sibsp": 15,
   "embarked": "titi",
   "cabin_class": "Second",
   "who": "tutu"
}'
echo -e ""
