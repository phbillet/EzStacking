echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 112945.4157127021,
   "AspectRation": 2.0812015267446187,
   "Eccentricity": 0.6753324065966061,
   "ShapeFactor2": 0.001658608916081776
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 67347.70754940619,
   "AspectRation": 1.5541504952038887,
   "Eccentricity": 0.6688771034346525,
   "ShapeFactor2": 0.0032808493020037343
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 190264.21287524584,
   "AspectRation": 1.1399974694669541,
   "Eccentricity": 0.2525253637086783,
   "ShapeFactor2": 0.0026048858946239395
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 48957.547172113176,
   "AspectRation": 1.1373550342971521,
   "Eccentricity": 0.5372532542361023,
   "ShapeFactor2": 0.0026080213101187417
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 124186.3781502535,
   "AspectRation": 1.4193256476181184,
   "Eccentricity": 0.7732866114608983,
   "ShapeFactor2": 0.0015594594469183684
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 140912.57018224156,
   "AspectRation": 1.7887158425185217,
   "Eccentricity": 0.5309410337750025,
   "ShapeFactor2": 0.0015723830995956038
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 45080.672921335354,
   "AspectRation": 1.8940543566773573,
   "Eccentricity": 0.39357206943761325,
   "ShapeFactor2": 0.00198461694102555
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 208570.00048926825,
   "AspectRation": 1.3909375764861291,
   "Eccentricity": 0.46848771915803067,
   "ShapeFactor2": 0.002566886047311808
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 234744.9433985977,
   "AspectRation": 1.324966320283714,
   "Eccentricity": 0.3270976284162319,
   "ShapeFactor2": 0.003442895879497419
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 127112.30954043102,
   "AspectRation": 2.0752212129212744,
   "Eccentricity": 0.254295386475443,
   "ShapeFactor2": 0.0011019437932315759
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 153068.2576234083,
   "AspectRation": 1.3744214227787446,
   "Eccentricity": 0.639223407463438,
   "ShapeFactor2": 0.002793680875058193
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 121196.57553399361,
   "AspectRation": 4.43030644683663,
   "Eccentricity": 3.911422968468005,
   "ShapeFactor2": 0.0030781410344026747
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 231901.7572536377,
   "AspectRation": 1.4203294897169774,
   "Eccentricity": 0.911422968468005,
   "ShapeFactor2": 7.003664971964452
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Area": 74864.54332226294,
   "AspectRation": 1.6408069470001225,
   "Eccentricity": 10.911422968468004,
   "ShapeFactor2": 0.0018312270501025549
}'
echo -e ""
