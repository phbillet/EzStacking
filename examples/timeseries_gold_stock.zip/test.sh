echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Close_t_3": 1899.7685422815412,
   "Low_t_3": 1190.5909825897938,
   "Close_t_1": 1089.1034830488175,
   "High_t_1": 1364.2840250572985,
   "Low_t_1": 1080.7432039864702
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Close_t_3": 1679.2976264988888,
   "Low_t_3": 1899.262931121142,
   "Close_t_1": 1392.025173042275,
   "High_t_1": 1242.312376256275,
   "Low_t_1": 1869.4591884810595
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Close_t_3": 1840.8177749323154,
   "Low_t_3": 1476.2385326521198,
   "Close_t_1": 1493.2169863469462,
   "High_t_1": 1642.3956436178944,
   "Low_t_1": 1410.011657791404
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Close_t_3": 2100.1,
   "Low_t_3": 2081.6,
   "Close_t_1": 2101.1,
   "High_t_1": 1561.510702673434,
   "Low_t_1": 2077.6
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Close_t_3": 2099.1,
   "Low_t_3": 1428.7135868789435,
   "Close_t_1": 2095.1,
   "High_t_1": 2046.8149947797906,
   "Low_t_1": 2081.6
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Close_t_3": 2100.1,
   "Low_t_3": 1885.6533547592362,
   "Close_t_1": 2099.1,
   "High_t_1": 1636.2407901786512,
   "Low_t_1": 2076.6
}'
echo -e ""
