echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 15.36159294367872,
   "BioChemical_Oxygen_Demand": 79.14605508765788,
   "Nitrate": 6.413525366767393,
   "Total_Coliform": 400538.99786282843,
   "Conductivity": 7611.824735305891
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 17.59596355513641,
   "BioChemical_Oxygen_Demand": 101.81625660670514,
   "Nitrate": 10.102039792238823,
   "Total_Coliform": 217128.28756286853,
   "Conductivity": 9202.132265240803
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 26.872666437336935,
   "BioChemical_Oxygen_Demand": 23.805784427167048,
   "Nitrate": 6.332963068076344,
   "Total_Coliform": 68139.77439987086,
   "Conductivity": 7606.484392023772
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 7.782672662119119,
   "BioChemical_Oxygen_Demand": 93.61418794301215,
   "Nitrate": 6.455435328990993,
   "Total_Coliform": 128334.44232763504,
   "Conductivity": 2455.3206863748555
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 18.35604129150451,
   "BioChemical_Oxygen_Demand": 85.1149646262566,
   "Nitrate": 4.689240150749823,
   "Total_Coliform": 65077.25415342773,
   "Conductivity": 4295.323283795541
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 22.449283406366913,
   "BioChemical_Oxygen_Demand": 57.79553178909413,
   "Nitrate": 9.570954948422933,
   "Total_Coliform": 40612.937904746716,
   "Conductivity": 5928.301769283521
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 2.782292873696627,
   "BioChemical_Oxygen_Demand": 95.98846667013457,
   "Nitrate": 5.812782653511021,
   "Total_Coliform": 191609.43628580953,
   "Conductivity": 1957.5222684251464
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 9.882765935360034,
   "BioChemical_Oxygen_Demand": 68.94918309232649,
   "Nitrate": 6.0034292551956145,
   "Total_Coliform": 79252.0681028,
   "Conductivity": 3571.32357359044
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 8.533524986359502,
   "BioChemical_Oxygen_Demand": 107.43295875946104,
   "Nitrate": 3.5574714475961207,
   "Total_Coliform": 95302.40160959472,
   "Conductivity": 2304.521093174905
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 12.425898570851013,
   "BioChemical_Oxygen_Demand": 83.49726912190455,
   "Nitrate": 6.20815297487707,
   "Total_Coliform": 280047.95109336183,
   "Conductivity": 2245.5274371565824
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 21.843047031395727,
   "BioChemical_Oxygen_Demand": 109.06861152049707,
   "Nitrate": 10.096399637601587,
   "Total_Coliform": 24598.536910091003,
   "Conductivity": 8701.665880557346
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 19.76813060256042,
   "BioChemical_Oxygen_Demand": 122.81565315707559,
   "Nitrate": 0.47771350227963133,
   "Total_Coliform": 14613.107489501617,
   "Conductivity": 7682.005949698866
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 5.476696745027426,
   "BioChemical_Oxygen_Demand": 49.611522657393955,
   "Nitrate": 3.0722595698103223,
   "Total_Coliform": 344402.0158972803,
   "Conductivity": 8420.973058619738
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 9.750978460143164,
   "BioChemical_Oxygen_Demand": 109.96308572457319,
   "Nitrate": 4.904947943018003,
   "Total_Coliform": 328772.8933465064,
   "Conductivity": 5962.858999426526
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 25.769240461990563,
   "BioChemical_Oxygen_Demand": 60.96935559024837,
   "Nitrate": 11.586271908663623,
   "Total_Coliform": 3260.834814970566,
   "Conductivity": 3845.1040346369023
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 4.365804341043511,
   "BioChemical_Oxygen_Demand": 80.9618789644608,
   "Nitrate": 11.245603123470026,
   "Total_Coliform": 422790.3538641771,
   "Conductivity": 125.72950926080621
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 6.308459904001498,
   "BioChemical_Oxygen_Demand": 49.52064786843742,
   "Nitrate": 9.524267250115694,
   "Total_Coliform": 305719.9031596137,
   "Conductivity": 9004.506223664865
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 22.809922469043908,
   "BioChemical_Oxygen_Demand": 121.44566677966449,
   "Nitrate": 3.5557729559885654,
   "Total_Coliform": 137946.4196119587,
   "Conductivity": 1174.4875977637985
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 3.691808896388672,
   "BioChemical_Oxygen_Demand": 94.45886940252907,
   "Nitrate": 2.1830520093641748,
   "Total_Coliform": 268575.50874336227,
   "Conductivity": 2786.647069306426
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 16.817982098397145,
   "BioChemical_Oxygen_Demand": 118.73981196490466,
   "Nitrate": 2.732977864642646,
   "Total_Coliform": 433743.5690598852,
   "Conductivity": 7408.260071807914
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 33.5,
   "BioChemical_Oxygen_Demand": 29.89377309367591,
   "Nitrate": 4.73630227238618,
   "Total_Coliform": 458002.0,
   "Conductivity": 3887.3876092888263
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 36.5,
   "BioChemical_Oxygen_Demand": 129.5,
   "Nitrate": 9.613703999455582,
   "Total_Coliform": 458008.0,
   "Conductivity": 7927.630580400256
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 36.5,
   "BioChemical_Oxygen_Demand": 46.384490690673324,
   "Nitrate": 19.05,
   "Total_Coliform": 151055.59928098772,
   "Conductivity": 9277.0
}'
echo -e ""
