echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "N",
   "Credibility": "A",
   "Competitiveness": "N",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "N",
   "Credibility": "N",
   "Competitiveness": "P",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "P",
   "Credibility": "P",
   "Competitiveness": "A",
   "Operating_Risk": "A"
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "P",
   "Credibility": "A",
   "Competitiveness": "A",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "P",
   "Credibility": "N",
   "Competitiveness": "A",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "N",
   "Credibility": "A",
   "Competitiveness": "A",
   "Operating_Risk": "A"
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "A",
   "Credibility": "A",
   "Competitiveness": "P",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "N",
   "Credibility": "P",
   "Competitiveness": "N",
   "Operating_Risk": "N"
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "N",
   "Financial_Flexibility": "N",
   "Credibility": "N",
   "Competitiveness": "P",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "P",
   "Credibility": "A",
   "Competitiveness": "P",
   "Operating_Risk": "A"
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "N",
   "Credibility": "A",
   "Competitiveness": "A",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "P",
   "Credibility": "A",
   "Competitiveness": "P",
   "Operating_Risk": "N"
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "A",
   "Credibility": "P",
   "Competitiveness": "A",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "N",
   "Credibility": "A",
   "Competitiveness": "N",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "P",
   "Credibility": "N",
   "Competitiveness": "A",
   "Operating_Risk": "A"
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "P",
   "Credibility": "P",
   "Competitiveness": "A",
   "Operating_Risk": "N"
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "N",
   "Financial_Flexibility": "P",
   "Credibility": "P",
   "Competitiveness": "A",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "A",
   "Credibility": "P",
   "Competitiveness": "N",
   "Operating_Risk": "N"
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "P",
   "Credibility": "N",
   "Competitiveness": "N",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "N",
   "Financial_Flexibility": "P",
   "Credibility": "A",
   "Competitiveness": "N",
   "Operating_Risk": "N"
}'
echo -e ""
echo -e "Test OK: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "N",
   "Credibility": "P",
   "Competitiveness": "P",
   "Operating_Risk": "A"
}'
echo -e ""
echo -e "Test OK: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "N",
   "Credibility": "A",
   "Competitiveness": "P",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "N",
   "Financial_Flexibility": "P",
   "Credibility": "N",
   "Competitiveness": "P",
   "Operating_Risk": "N"
}'
echo -e ""
echo -e "Test OK: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "A",
   "Credibility": "N",
   "Competitiveness": "N",
   "Operating_Risk": "A"
}'
echo -e ""
echo -e "Test OK: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "N",
   "Credibility": "A",
   "Competitiveness": "A",
   "Operating_Risk": "N"
}'
echo -e ""
echo -e "Test OK: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "A",
   "Credibility": "N",
   "Competitiveness": "A",
   "Operating_Risk": "A"
}'
echo -e ""
echo -e "Test OK: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "N",
   "Financial_Flexibility": "P",
   "Credibility": "P",
   "Competitiveness": "P",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "A",
   "Credibility": "N",
   "Competitiveness": "A",
   "Operating_Risk": "N"
}'
echo -e ""
echo -e "Test OK: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "P",
   "Credibility": "P",
   "Competitiveness": "P",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test OK: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "N",
   "Financial_Flexibility": "A",
   "Credibility": "N",
   "Competitiveness": "P",
   "Operating_Risk": "A"
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "A",
   "Financial_Flexibility": "tete",
   "Credibility": "P",
   "Competitiveness": "toto",
   "Operating_Risk": "P"
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "P",
   "Financial_Flexibility": "tata",
   "Credibility": "A",
   "Competitiveness": "P",
   "Operating_Risk": "tutu"
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Management_Risk": "N",
   "Financial_Flexibility": "tyty",
   "Credibility": "A",
   "Competitiveness": "N",
   "Operating_Risk": "titi"
}'
echo -e ""
