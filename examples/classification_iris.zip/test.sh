echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.551849873368431,
   "sepal_width": 3.462801753091968,
   "petal_length": 2.9778095043791217,
   "petal_width": 0.15222445149685937
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.869989602889782,
   "sepal_width": 3.4054594647909315,
   "petal_length": 1.6477417278890245,
   "petal_width": 1.1700824805382528
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.13467520329519,
   "sepal_width": 3.211631490121336,
   "petal_length": 3.0729659766998734,
   "petal_width": 0.2878856457128885
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 5.473130234622132,
   "sepal_width": 8.4,
   "petal_length": 6.529871136303127,
   "petal_width": 9.5
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 6.025846391525329,
   "sepal_width": 14.4,
   "petal_length": 1.375928675704047,
   "petal_width": 9.5
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "sepal_length": 10.9,
   "sepal_width": 11.4,
   "petal_length": 4.835499013683533,
   "petal_width": 3.5
}'
echo -e ""
