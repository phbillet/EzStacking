from fastapi import FastAPI
from joblib import load
import pandas as pd
import numpy as np
import nest_asyncio
import uvicorn
import ast
import time
from sklearn.base import is_classifier
from pydantic import BaseModel

# Creating FastAPI instance
app = FastAPI()

# Creating class to define the request body
# and the type hints of each attribute

class request_body(BaseModel):
      experimental_band_gap: float
      phonon_cutoff_frequency: float
      mean_phonon_frequency: float
      electronic_contribution_of_dielectric_constant: float
      total_dielectric_constant: float
      nearest_neighbor_distance: float
      density: float
      bulk_modulus: float
      structure: str
      category: str

# read dataframe schema
schema = pd.read_csv('schema.csv')

model = load('model.sav')


@app.get('/ping')
def pong():
    return {'ping': 'pong!'}

@app.post('/predict')
def predict(data : request_body):

    elaps_start_time = time.time()
    cpu_start_time = time.process_time()

    # Making the data in a form suitable for prediction
    test_data = [[
              data.experimental_band_gap,
              data.phonon_cutoff_frequency,
              data.mean_phonon_frequency,
              data.electronic_contribution_of_dielectric_constant,
              data.total_dielectric_constant,
              data.nearest_neighbor_distance,
              data.density,
              data.bulk_modulus,
              data.structure,
              data.category,
    ]]

    # Check input data
    data_err = []
    for ind in range(len(test_data[0])):
        if schema.iloc[ind][1] == 'num':
           interval = ast.literal_eval(schema.iloc[ind][2])
           if (test_data[0][ind] < interval[0]) | (test_data[0][ind] > interval[1]):
              data_err.append(schema.iloc[ind][0])
        if schema.iloc[ind][1] == 'cat':
           domain = ast.literal_eval(schema.iloc[ind][2])
           if not(np.isin(test_data[0][ind], domain)):
              data_err.append(schema.iloc[ind][0])

    # Predicting the regression value
    result = model.predict(pd.DataFrame(test_data,
                                        columns=[
                                                 'experimental_band_gap',
                                                 'phonon_cutoff_frequency',
                                                 'mean_phonon_frequency',
                                                 'electronic_contribution_of_dielectric_constant',
                                                 'total_dielectric_constant',
                                                 'nearest_neighbor_distance',
                                                 'density',
                                                 'bulk_modulus',
                                                 'structure',
                                                 'category',
                          ]))[0].item()

    elaps_end_time = time.time()
    cpu_end_time = time.process_time()
    elapsed_time = np.round((elaps_end_time - elaps_start_time) * 1000)
    elaps = str(elapsed_time) + 'ms'
    cpu_time = np.round((cpu_end_time - cpu_start_time) * 1000)
    cpu = str(cpu_time) + 'ms'

    # Return the Result
    return { 'regression_value' : result, 'error' : data_err, 'elapsed time' : elaps, 'cpu time' : cpu}

nest_asyncio.apply()
uvicorn.run(app, port=8000)
