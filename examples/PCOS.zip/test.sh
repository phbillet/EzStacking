echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "0",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 10.156465304219546,
   "Follicle_No_R": 7.337736633274233
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "0",
   "Pimples_Y_N": "1",
   "Follicle_No_L": 18.900851951575568,
   "Follicle_No_R": 4.210871646792002
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "1",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "1",
   "Follicle_No_L": 1.9321560452375812,
   "Follicle_No_R": 17.896447941517827
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "0",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 18.270651966134476,
   "Follicle_No_R": 8.733990197921095
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "1",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 17.764072516037043,
   "Follicle_No_R": 9.198585895550346
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "1",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "1",
   "Follicle_No_L": 4.996633227361232,
   "Follicle_No_R": 17.838116823323084
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "1",
   "Follicle_No_L": 20.95065950940115,
   "Follicle_No_R": 10.609744812483722
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 21.24072808592711,
   "Follicle_No_R": 18.975850744696082
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "1",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 10.303711371837553,
   "Follicle_No_R": 18.109821509264094
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 14.101472098574103,
   "Follicle_No_R": 9.453243723435449
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "1",
   "Follicle_No_L": 7.659864255779942,
   "Follicle_No_R": 13.133001482162081
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 3.0065410278717746,
   "Follicle_No_R": 9.28865674107177
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "1",
   "Hair_loss_Y_N": "0",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 2.8944859192111645,
   "Follicle_No_R": 16.760502447385846
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "1",
   "Follicle_No_L": 2.0966604760395526,
   "Follicle_No_R": 12.608986864227978
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "0",
   "Pimples_Y_N": "1",
   "Follicle_No_L": 6.004732421944522,
   "Follicle_No_R": 15.632879497913683
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "tata",
   "Follicle_No_L": 19.7870724294629,
   "Follicle_No_R": 24
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "tyty",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 29,
   "Follicle_No_R": 30
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "0",
   "Hair_loss_Y_N": "toto",
   "Pimples_Y_N": "tyty",
   "Follicle_No_L": 9.342429804376382,
   "Follicle_No_R": 26
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "titi",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "0",
   "Follicle_No_L": 27,
   "Follicle_No_R": 2.3040334822695874
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Skin_darkening_Y_N": "tata",
   "Hair_loss_Y_N": "1",
   "Pimples_Y_N": "tutu",
   "Follicle_No_L": 11.557045084758176,
   "Follicle_No_R": 21
}'
echo -e ""
