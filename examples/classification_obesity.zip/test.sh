echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.9715978405594836,
   "Weight": 48.14703723564605,
   "FCVC": 2.351066819520229,
   "CH2O": 2.4372861400219494
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.4776443282644791,
   "Weight": 89.38327947069729,
   "FCVC": 1.193285138572487,
   "CH2O": 2.5625362117236676
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.7670278375344781,
   "Weight": 59.03798002912751,
   "FCVC": 1.7919604956033208,
   "CH2O": 1.4259525402459834
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.7016820479947814,
   "Weight": 92.502034079574,
   "FCVC": 2.710035549951321,
   "CH2O": 2.9350885369564033
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.9675274131873945,
   "Weight": 134.59635989240476,
   "FCVC": 1.2480106445302452,
   "CH2O": 1.1474443474033638
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.9308782898239496,
   "Weight": 113.82180611496676,
   "FCVC": 1.4302268319220717,
   "CH2O": 1.2525227675323527
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.707556882427399,
   "Weight": 155.28732016858265,
   "FCVC": 1.1004700293849348,
   "CH2O": 2.5398189817882475
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.4928829889507198,
   "Weight": 41.478729489868975,
   "FCVC": 1.840719987053016,
   "CH2O": 1.9203185244603072
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.5515953525686672,
   "Weight": 149.00081077126566,
   "FCVC": 1.9219417938711783,
   "CH2O": 1.0385156121019574
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.8390217497623806,
   "Weight": 70.24364522185806,
   "FCVC": 1.061539242007887,
   "CH2O": 1.75802219041854
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.8245518039240187,
   "Weight": 140.86095341516108,
   "FCVC": 1.564610549630178,
   "CH2O": 1.4515535032432132
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.856645603480441,
   "Weight": 163.43910661890143,
   "FCVC": 2.4618982868605666,
   "CH2O": 1.3397618041486283
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.8202425848203987,
   "Weight": 107.07518394340833,
   "FCVC": 2.69097144632579,
   "CH2O": 1.1776352917773762
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.5364396194654752,
   "Weight": 63.6916259864885,
   "FCVC": 2.8996330475574172,
   "CH2O": 1.5108127060851342
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.7759054713544618,
   "Weight": 133.4593855271304,
   "FCVC": 1.462782928150445,
   "CH2O": 1.478712521280099
}'
echo -e ""
echo -e "Test OK: 15"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.8044856398556648,
   "Weight": 138.35688972945252,
   "FCVC": 2.4971940101480583,
   "CH2O": 1.8579144873521172
}'
echo -e ""
echo -e "Test OK: 16"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.8795253935669003,
   "Weight": 158.41157675146755,
   "FCVC": 1.7996897029922125,
   "CH2O": 2.7203844499773773
}'
echo -e ""
echo -e "Test OK: 17"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.7971596938426986,
   "Weight": 66.83685231140824,
   "FCVC": 2.733411142992719,
   "CH2O": 1.280808746342436
}'
echo -e ""
echo -e "Test OK: 18"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.5369029880382603,
   "Weight": 128.64067857634166,
   "FCVC": 2.182400948565224,
   "CH2O": 2.093370394356768
}'
echo -e ""
echo -e "Test OK: 19"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.7594838200525222,
   "Weight": 89.90731322914357,
   "FCVC": 2.413108037210381,
   "CH2O": 1.3906500062483036
}'
echo -e ""
echo -e "Test OK: 20"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.4864450120791144,
   "Weight": 51.45452584630344,
   "FCVC": 1.2411976960743447,
   "CH2O": 2.5651017434042176
}'
echo -e ""
echo -e "Test OK: 21"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.5007935692349506,
   "Weight": 74.18700277742687,
   "FCVC": 2.776358015994907,
   "CH2O": 1.436541097087568
}'
echo -e ""
echo -e "Test OK: 22"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.5705155670728352,
   "Weight": 42.861440702187565,
   "FCVC": 1.2963166368882784,
   "CH2O": 1.0135499467286975
}'
echo -e ""
echo -e "Test OK: 23"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.4953472623081163,
   "Weight": 161.8097031195668,
   "FCVC": 2.26431104263488,
   "CH2O": 2.5158148486968486
}'
echo -e ""
echo -e "Test OK: 24"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.8843697209280383,
   "Weight": 123.8785450664055,
   "FCVC": 2.2982614826100582,
   "CH2O": 2.5281693972942962
}'
echo -e ""
echo -e "Test OK: 25"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 1.853295030110227,
   "Weight": 58.600576494905745,
   "FCVC": 1.0094579998624615,
   "CH2O": 2.37254512298835
}'
echo -e ""
echo -e "Test OK: 26"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.537836998638523,
   "Weight": 40.98944509824944,
   "FCVC": 1.1523134078302157,
   "CH2O": 2.3571542903095315
}'
echo -e ""
echo -e "Test OK: 27"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.8648179271864866,
   "Weight": 137.45526129791284,
   "FCVC": 1.6505063157933026,
   "CH2O": 1.260472616546189
}'
echo -e ""
echo -e "Test OK: 28"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.859967597339843,
   "Weight": 97.6558995082531,
   "FCVC": 1.3797203116713206,
   "CH2O": 1.657086156490588
}'
echo -e ""
echo -e "Test OK: 29"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Male",
   "Height": 1.4577130806970349,
   "Weight": 138.40324867217748,
   "FCVC": 2.183544971616497,
   "CH2O": 1.4995541356566324
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "Female",
   "Height": 11.975663,
   "Weight": 52.78360992697906,
   "FCVC": 12.0,
   "CH2O": 1.683878544843275
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "toto",
   "Height": 1.8344134238791956,
   "Weight": 174.057269,
   "FCVC": 2.8943906922665885,
   "CH2O": 1.888494238884382
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Gender": "tyty",
   "Height": 4.975663,
   "Weight": 64.78776595925765,
   "FCVC": 13.0,
   "CH2O": 2.948850475382078
}'
echo -e ""
