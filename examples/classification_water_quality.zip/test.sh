echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 18.41937225867315,
   "Dissolved_Oxygen": 0.5410659642425233,
   "BioChemical_Oxygen_Demand": 64.60905205117965,
   "Fecal_Streptococci": 219677.59565111075,
   "Conductivity": 866.033259648623
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 29.01021449607498,
   "Dissolved_Oxygen": 9.307830958472142,
   "BioChemical_Oxygen_Demand": 91.51892195799219,
   "Fecal_Streptococci": 155186.97048030788,
   "Conductivity": 3018.4920451481657
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 18.873557061841346,
   "Dissolved_Oxygen": 6.450697121821538,
   "BioChemical_Oxygen_Demand": 29.855083117724835,
   "Fecal_Streptococci": 82696.61455837941,
   "Conductivity": 8373.856423721847
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 27.675995580509365,
   "Dissolved_Oxygen": 8.702746509234236,
   "BioChemical_Oxygen_Demand": 81.56012353290339,
   "Fecal_Streptococci": 133154.97008838304,
   "Conductivity": 8392.0913163887
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 8.423517466089132,
   "Dissolved_Oxygen": 4.946923524409465,
   "BioChemical_Oxygen_Demand": 35.22611239703852,
   "Fecal_Streptococci": 46590.246925437554,
   "Conductivity": 3618.902382707438
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 23.18503026300082,
   "Dissolved_Oxygen": 1.677296968602478,
   "BioChemical_Oxygen_Demand": 2.730584218019874,
   "Fecal_Streptococci": 223428.12864995367,
   "Conductivity": 4292.035465211679
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 24.46466760093062,
   "Dissolved_Oxygen": 9.063481288090955,
   "BioChemical_Oxygen_Demand": 11.4649291623438,
   "Fecal_Streptococci": 17832.2113289058,
   "Conductivity": 8077.973373562957
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 12.245781004912548,
   "Dissolved_Oxygen": 4.720426140190368,
   "BioChemical_Oxygen_Demand": 33.93561372835747,
   "Fecal_Streptococci": 43570.63337323626,
   "Conductivity": 1928.5069823797965
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 22.89859880951447,
   "Dissolved_Oxygen": 3.092642891326496,
   "BioChemical_Oxygen_Demand": 118.5119540648112,
   "Fecal_Streptococci": 174567.16664323892,
   "Conductivity": 275.7936775617232
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 16.86581946403739,
   "Dissolved_Oxygen": 5.8367635756680265,
   "BioChemical_Oxygen_Demand": 17.766194564735272,
   "Fecal_Streptococci": 14743.257779541023,
   "Conductivity": 6669.509920123226
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 10.99989882043594,
   "Dissolved_Oxygen": 20.25,
   "BioChemical_Oxygen_Demand": 66.81105475671835,
   "Fecal_Streptococci": 229008.0,
   "Conductivity": 8933.75813522769
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 23.772598738534136,
   "Dissolved_Oxygen": 2.1583621740607293,
   "BioChemical_Oxygen_Demand": 130.5,
   "Fecal_Streptococci": 229001.0,
   "Conductivity": 9273.0
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Temperature": 39.5,
   "Dissolved_Oxygen": 3.2275238148432677,
   "BioChemical_Oxygen_Demand": 131.5,
   "Fecal_Streptococci": 6184.395015881809,
   "Conductivity": 9277.0
}'
echo -e ""
