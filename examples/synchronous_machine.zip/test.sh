echo -e "Test OK: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 5.170857996934737,
   "PF": 0.9049807534191938,
   "dIf": 0.48899610360598805
}'
echo -e ""
echo -e "Test OK: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 5.498446438248207,
   "PF": 0.740330783968164,
   "dIf": 0.7174940840858086
}'
echo -e ""
echo -e "Test OK: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 5.480926669916814,
   "PF": 0.8367980649681901,
   "dIf": 0.48209756772453544
}'
echo -e ""
echo -e "Test OK: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 4.394219094896462,
   "PF": 0.73417500198506,
   "dIf": 0.23974530484904283
}'
echo -e ""
echo -e "Test OK: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 5.818390675542782,
   "PF": 0.9807015056421484,
   "dIf": 0.048883965545802446
}'
echo -e ""
echo -e "Test OK: 5"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 3.9507521347657946,
   "PF": 0.7502704532980523,
   "dIf": 0.06580726292025472
}'
echo -e ""
echo -e "Test OK: 6"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 4.674814036698981,
   "PF": 0.7088075398620961,
   "dIf": 0.41215014285299356
}'
echo -e ""
echo -e "Test OK: 7"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 5.160888920748274,
   "PF": 0.8594507160111368,
   "dIf": 0.3767966609758892
}'
echo -e ""
echo -e "Test OK: 8"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 5.846369321541303,
   "PF": 0.976639999160857,
   "dIf": 0.28108855640830327
}'
echo -e ""
echo -e "Test OK: 9"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 5.137135199881392,
   "PF": 0.8441361275722703,
   "dIf": 0.5268533729210965
}'
echo -e ""
echo -e "Test OK: 10"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 4.219243686921881,
   "PF": 0.8466369498862084,
   "dIf": 0.7382839439947674
}'
echo -e ""
echo -e "Test OK: 11"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 3.8541471198122212,
   "PF": 0.8610607570071488,
   "dIf": 0.5224386392841112
}'
echo -e ""
echo -e "Test OK: 12"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 4.176283383427112,
   "PF": 0.97601474732703,
   "dIf": 0.5704040486794059
}'
echo -e ""
echo -e "Test OK: 13"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 4.58198888346228,
   "PF": 0.906750076767755,
   "dIf": 0.15313998625813588
}'
echo -e ""
echo -e "Test OK: 14"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 5.385523956092371,
   "PF": 0.7709140199883606,
   "dIf": 0.6970267017310723
}'
echo -e ""
echo -e "Test KO: 0"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 9.0,
   "PF": 0.9485856772806969,
   "dIf": 8.769
}'
echo -e ""
echo -e "Test KO: 1"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 3.584579461168336,
   "PF": 2.0,
   "dIf": 0.769
}'
echo -e ""
echo -e "Test KO: 2"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 3.37901645325302,
   "PF": 4.0,
   "dIf": 0.5212161837390913
}'
echo -e ""
echo -e "Test KO: 3"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 4.354530577710792,
   "PF": 10.0,
   "dIf": 0.4726155256001234
}'
echo -e ""
echo -e "Test KO: 4"
curl -X 'POST' \
   'http://127.0.0.1:8000/predict' \
   -H 'accept: application/json' \
   -H 'Content-Type: application/json' \
   -d '{
   "Iy": 6.0,
   "PF": 0.9918313458572829,
   "dIf": 10.769
}'
echo -e ""
